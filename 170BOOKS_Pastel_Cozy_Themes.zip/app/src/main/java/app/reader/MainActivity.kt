package app.reader

import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        Store.init(this)
        NotesStore.init(this)
        ReaderSettings.init(this)
        val book = font("fonts/newspaper.ttf", "fonts/newspaper.otf", "fonts/Newspaper.ttf", "fonts/Newspaper.otf") ?: FontFamily.Serif
        val ui = font("fonts/newspaper.ttf", "fonts/newspaper.otf", "fonts/Newspaper.ttf", "fonts/Newspaper.otf") ?: FontFamily.Serif
        val mono = ui
        applyPreferredRefreshRate()
        setContent { AppTheme(book, ui, mono) { Surface(Modifier.fillMaxSize(), color = BG) { App() } } }
    }

    fun applyPreferredRefreshRate() {
        window.attributes = window.attributes.apply { preferredRefreshRate = ReaderSettings.refreshRate.toFloat() }
    }

    private fun font(vararg names: String): FontFamily? {
        for (n in names) {
            try { return FontFamily(Typeface.createFromAsset(assets, n)) } catch (_: Exception) {}
        }
        return null
    }
}

// ---------- Пользовательские настройки ----------
object ReaderSettings {
    private lateinit var prefs: android.content.SharedPreferences
    var themeId by mutableIntStateOf(0)
        private set
    var accentId by mutableIntStateOf(1)
        private set
    var refreshRate by mutableIntStateOf(60)
        private set
    var eyeProtection by mutableStateOf(false)
        private set
    var pageMode by mutableStateOf(false)
        private set
    val themes = listOf("Обсидиан", "Графит", "Полночь", "Пастельный зелёный", "Пастельная лаванда", "Айвори", "Тёплый бежевый")
    val themeBackgrounds = listOf(
        Color(0xFF050505), Color(0xFF111318), Color(0xFF090D1B),
        Color(0xFFE8F0E7), Color(0xFFEDE8F5), Color(0xFFF7F3E9), Color(0xFFEDE1D1)
    )
    val themeForegrounds = listOf(
        Color(0xFFF4F0E9), Color(0xFFEDEFF4), Color(0xFFF0F0FA),
        Color(0xFF34463A), Color(0xFF443B55), Color(0xFF51483B), Color(0xFF514237)
    )
    val themeSurfaces = listOf(
        Color(0xFF151515), Color(0xFF20232A), Color(0xFF171B2B),
        Color(0xFFF4F7F0), Color(0xFFF6F2FA), Color(0xFFFFFCF4), Color(0xFFF5EBDD)
    )
    val themeAccents = listOf(
        Color(0xFF54D6C8), Color(0xFF8BA7C8), Color(0xFF9B8CFF),
        Color(0xFF78977A), Color(0xFF9886B8), Color(0xFFB49A70), Color(0xFFAA8667)
    )
    val accents = listOf(Color(0xFF54D6C8), Color(0xFFFF5A6E), Color(0xFF9B8CFF), Color(0xFFFFB454), Color(0xFF79A8FF), Color(0xFFE58BC5))
    val accentNames = listOf("Мята", "Коралл", "Лаванда", "Янтарь", "Сапфир", "Розовый")

    fun init(context: android.content.Context) {
        prefs = context.getSharedPreferences("reader_settings", 0)
        themeId = prefs.getInt("theme", 0).coerceIn(themes.indices)
        accentId = prefs.getInt("accent", 1).coerceIn(accents.indices)
        refreshRate = prefs.getInt("refresh", 60).let { if (it in listOf(60, 90, 120, 144)) it else 60 }
        eyeProtection = prefs.getBoolean("eye", false)
        pageMode = prefs.getBoolean("page_mode", false)
        applyColors()
    }
    private fun applyColors() {
        BG = themeBackgrounds[themeId]
        ACCENT = if (themeId >= 3) themeAccents[themeId] else accents[accentId]
        FG = themeForegrounds[themeId]
        PANEL = themeSurfaces[themeId]
        MUTED = FG.copy(alpha = 0.62f)
        BORDER = FG.copy(alpha = if (themeId >= 3) 0.13f else 0.16f)
    }
    fun setTheme(id: Int) { themeId = id.coerceIn(themes.indices); prefs.edit().putInt("theme", themeId).apply(); applyColors() }
    fun setAccent(id: Int) { accentId = id.coerceIn(accents.indices); prefs.edit().putInt("accent", accentId).apply(); applyColors() }
    fun setRefresh(rate: Int) { refreshRate = rate; prefs.edit().putInt("refresh", rate).apply() }
    fun updateEyeProtection(enabled: Boolean) { eyeProtection = enabled; prefs.edit().putBoolean("eye", enabled).apply() }
    fun setPageMode(enabled: Boolean) { pageMode = enabled; prefs.edit().putBoolean("page_mode", enabled).apply() }
}

// ---------- Палитра и шрифты ----------
var ACCENT by mutableStateOf(Color(0xFFFF5A6E))
var BG by mutableStateOf(Color(0xFF050505))
var FG by mutableStateOf(Color(0xFFF4F0E9))
var PANEL by mutableStateOf(Color(0xFF151515))
var MUTED by mutableStateOf(Color(0xFFAAA69F))
var BORDER by mutableStateOf(Color.White.copy(alpha = 0.16f))
val Line get() = BORDER
val SUN = listOf(Color(0xFFE5456F), Color(0xFFFFA95C), Color(0xFFE5456F))
val PALETTE = listOf(Color(0xFFF3D9BC), Color(0xFFFF8068), Color(0xFF8E8CE0), Color(0xFFD9647F),
    Color(0xFF45D2BA), Color(0xFFEA8A2C), Color(0xFF5273FF), Color(0xFFB556D6))
fun tint(s: String) = PALETTE[(s.hashCode() and 0x7fffffff) % PALETTE.size]

val LocalMono = staticCompositionLocalOf<FontFamily> { FontFamily.Monospace }
val LocalBookFont = staticCompositionLocalOf<FontFamily> { FontFamily.Serif }

@Composable
fun mono(size: Int = 12, alpha: Float = 1f, spacing: Float = 0.8f) =
    TextStyle(fontFamily = LocalMono.current, fontSize = size.sp, letterSpacing = spacing.sp, color = FG.copy(alpha = alpha))

@Composable
fun AppTheme(book: FontFamily, ui: FontFamily, mono: FontFamily, content: @Composable () -> Unit) {
    val cs = if (ReaderSettings.themeId >= 3) lightColorScheme(
        primary = ACCENT, onPrimary = Color.White, background = BG, surface = PANEL,
        onBackground = FG, onSurface = FG, surfaceVariant = PANEL,
        onSurfaceVariant = MUTED, secondaryContainer = ACCENT.copy(alpha = 0.16f), onSecondaryContainer = FG
    ) else darkColorScheme(
        primary = ACCENT, onPrimary = Color.White, background = BG, surface = PANEL,
        onBackground = FG, onSurface = FG, surfaceVariant = PANEL,
        onSurfaceVariant = MUTED, secondaryContainer = ACCENT.copy(alpha = 0.18f), onSecondaryContainer = FG
    )
    val t = Typography()
    val light = FontWeight.Light
    val typo = t.copy(
        displayLarge = t.displayLarge.copy(fontFamily = ui, fontWeight = light),
        displayMedium = t.displayMedium.copy(fontFamily = ui, fontWeight = light),
        displaySmall = t.displaySmall.copy(fontFamily = ui, fontWeight = light, letterSpacing = (-0.5).sp),
        headlineLarge = t.headlineLarge.copy(fontFamily = ui, fontWeight = light),
        headlineMedium = t.headlineMedium.copy(fontFamily = ui, fontWeight = light),
        headlineSmall = t.headlineSmall.copy(fontFamily = ui, fontWeight = light),
        titleLarge = t.titleLarge.copy(fontFamily = ui, fontWeight = light),
        titleMedium = t.titleMedium.copy(fontFamily = mono),
        titleSmall = t.titleSmall.copy(fontFamily = mono),
        bodyLarge = t.bodyLarge.copy(fontFamily = ui),
        bodyMedium = t.bodyMedium.copy(fontFamily = ui),
        bodySmall = t.bodySmall.copy(fontFamily = ui),
        labelLarge = t.labelLarge.copy(fontFamily = mono),
        labelMedium = t.labelMedium.copy(fontFamily = mono),
        labelSmall = t.labelSmall.copy(fontFamily = mono)
    )
    CompositionLocalProvider(LocalMono provides mono, LocalBookFont provides book) {
        MaterialTheme(colorScheme = cs, typography = typo, content = content)
    }
}

// ---------- Тонкие линейные иконки ----------
val IconCol get() = FG.copy(alpha = 0.82f)

fun DrawScope.icInfo() {
    drawCircle(IconCol)
    val cx = size.width / 2
    drawLine(BG, Offset(cx, size.height * 0.27f), Offset(cx, size.height * 0.57f), size.width * 0.13f, StrokeCap.Round)
    drawCircle(BG, size.width * 0.075f, Offset(cx, size.height * 0.74f))
}

fun DrawScope.icPlus() {
    val w = 2.2.dp.toPx(); val m = size.width * 0.1f
    drawLine(IconCol, Offset(m, size.height / 2), Offset(size.width - m, size.height / 2), w, StrokeCap.Round)
    drawLine(IconCol, Offset(size.width / 2, m), Offset(size.width / 2, size.height - m), w, StrokeCap.Round)
}

fun DrawScope.icBack() {
    val w = 2.2.dp.toPx()
    drawLine(IconCol, Offset(size.width * 0.66f, size.height * 0.1f), Offset(size.width * 0.28f, size.height * 0.5f), w, StrokeCap.Round)
    drawLine(IconCol, Offset(size.width * 0.28f, size.height * 0.5f), Offset(size.width * 0.66f, size.height * 0.9f), w, StrokeCap.Round)
}

fun DrawScope.icDots(c: Color) {
    val r = size.width * 0.1f
    for (x in listOf(0.3f, 0.7f)) for (y in listOf(0.3f, 0.7f)) drawCircle(c, r, Offset(size.width * x, size.height * y))
}

@Composable
fun IconBtn(onClick: () -> Unit, draw: DrawScope.() -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.size(22.dp), onDraw = draw)
    }
}

// ---------- Кнопки, заголовок ----------
@Composable
fun Pill(t: String, sel: Boolean, c: Color, onClick: () -> Unit) {
    val m = if (sel) Modifier.background(Brush.horizontalGradient(listOf(ACCENT, ACCENT.copy(alpha = 0.78f))))
    else Modifier.background(PANEL).border(1.dp, Brush.horizontalGradient(listOf(c, c.copy(alpha = 0.3f))), CircleShape)
    Box(Modifier.clip(CircleShape).then(m).clickable(onClick = onClick), Alignment.Center) {
        Text(t.uppercase(), Modifier.padding(horizontal = 16.dp, vertical = 10.dp), style = mono(12, if (sel) 1f else 0.8f))
    }
}

@Composable
fun GhostBtn(text: String, enabled: Boolean, c: Color, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).border(1.dp, if (enabled) c.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.14f), CircleShape)
        .clickable(enabled = enabled, onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), style = mono(11, if (enabled) 1f else 0.4f))
    }
}

@Composable
fun Header(title: String, left: @Composable () -> Unit = { Spacer(Modifier.size(40.dp)) }, right: @Composable () -> Unit = { Spacer(Modifier.size(40.dp)) }) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        left()
        Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, maxLines = 1, style = MaterialTheme.typography.displaySmall)
        right()
    }
}

// ---------- Светящиеся плитки ----------
fun DrawScope.drawLit(c: Color, e: Float, r: Float) {
    drawRect(Brush.verticalGradient(
        0f to c, 0.25f * e to c.copy(alpha = 0.95f), e to c.copy(alpha = 0.32f), (e + (1f - e) * 0.65f) to Color.Transparent))
    drawRect(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
        center = Offset(size.width * 0.5f, 0f), radius = size.width * 0.9f))
    val cr = CornerRadius(r, r)
    for (i in 1..14) drawRoundRect(c.copy(alpha = 0.05f), cornerRadius = cr, style = Stroke(width = i * 3f * density))
    drawRoundRect(c.copy(alpha = 0.4f), cornerRadius = cr, style = Stroke(width = density))
}

fun DrawScope.drawOff(r: Float) {
    drawRect(Brush.verticalGradient(0f to Color(0xFF0A0A0A), 0.35f to Color(0xFF121212), 1f to Color(0xFF6E6E6E)))
    val cr = CornerRadius(r, r)
    for (i in 1..8) drawRoundRect(Color.White.copy(alpha = 0.03f), cornerRadius = cr, style = Stroke(width = i * 3f * density))
    drawRoundRect(Color.White.copy(alpha = 0.16f), cornerRadius = cr, style = Stroke(width = density))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Tile(title: String, sub: String, tag: String, c: Color, lit: Boolean, modifier: Modifier, onClick: () -> Unit, onMenu: () -> Unit) {
    val sh = RoundedCornerShape(30.dp)
    val e = 0.5f + ((title.hashCode() and 0x7fffffff) % 22) / 100f
    Box(modifier.clip(sh).background(BG)
        .drawBehind { if (lit) drawLit(c, e, 30.dp.toPx()) else drawOff(30.dp.toPx()) }
        .combinedClickable(onClick = onClick, onLongClick = onMenu)) {
        val dim = if (lit) Color.Black.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.4f)
        Text(tag, Modifier.align(Alignment.TopStart).padding(start = 20.dp, top = 20.dp), style = mono(10).copy(color = dim))
        Box(Modifier.align(Alignment.TopEnd).size(48.dp).clickable(onClick = onMenu), Alignment.Center) {
            Canvas(Modifier.size(16.dp)) { icDots(dim) }
        }
        Column(Modifier.align(if (lit) Alignment.BottomCenter else Alignment.Center).padding(horizontal = 16.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title.uppercase(), textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
                style = mono(13, 0.95f).copy(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset.Zero, 10f)))
            if (sub.isNotEmpty()) Text(sub.uppercase(), Modifier.padding(top = 4.dp), textAlign = TextAlign.Center, maxLines = 1,
                overflow = TextOverflow.Ellipsis, style = mono(10, 0.5f))
        }
    }
}

@Composable
fun ResultRow(title: String, sub: String, c: Color, end: @Composable () -> Unit) {
    val sh = RoundedCornerShape(26.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(PANEL)
        .drawBehind {
            drawRect(Brush.radialGradient(listOf(c.copy(alpha = 0.30f), Color.Transparent),
                center = Offset(0f, size.height / 2), radius = size.width * 0.7f))
        }
        .border(1.dp, Brush.horizontalGradient(listOf(c.copy(alpha = 0.85f), c.copy(alpha = 0.2f))), sh)
        .padding(start = 20.dp, end = 14.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title.uppercase(), style = mono(12, 0.95f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub.uppercase(), Modifier.padding(top = 4.dp), style = mono(10, 0.5f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(10.dp))
        end()
    }
}

// Панель с градиентом и сеткой точек (пустое состояние)
@Composable
fun EmptyPanel(modifier: Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(32.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF6B84FF), Color(0xFFEC4E80), Color(0xFFFFA03A))))) {
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(0f to Color.Transparent, 0.5f to Color.Transparent, 0.95f to BG)))
        Canvas(Modifier.matchParentSize()) {
            val cols = 6; val rows = 8
            for (r in 0 until rows) for (k in 0 until cols) {
                val x = (k + 0.5f) * size.width / cols
                val y = (r + 0.5f) * size.height * 0.8f / rows
                drawCircle(Color.White.copy(alpha = 0.6f * (1f - r / rows.toFloat() * 0.7f)), 2.dp.toPx(), Offset(x, y))
            }
            drawCircle(Color.White, 6.dp.toPx(), Offset(size.width * 3.5f / cols, size.height * 0.8f * 1.5f / rows))
            drawCircle(Color.White, 8.dp.toPx(), Offset(size.width * 1.5f / cols, size.height * 0.8f * 4.5f / rows), style = Stroke(width = 2.dp.toPx()))
        }
        content()
    }
}

fun importUri(ctx: android.content.Context, uri: Uri) {
    var name = "book"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) name = c.getString(i)
    }
    val ext = extOf(name)
    if (ext !in SUPPORTED) { Toast.makeText(ctx, "Формат не поддерживается: .$ext", Toast.LENGTH_LONG).show(); return }
    val id = UUID.randomUUID().toString()
    val f = File(ctx.filesDir, "books/$id.$ext"); f.parentFile?.mkdirs()
    ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
    val title = name.removeSuffix(".zip").substringBeforeLast('.')
    Store.add(Book(id, title, "", f.path, ext))
}

@Composable
fun App() {
    var open by remember { mutableStateOf<Book?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) try { importUri(ctx, u) } catch (e: Exception) { Toast.makeText(ctx, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    val b = open
    if (b != null) {
        BackHandler { open = null }
        Reader(b) { open = null }
    } else {
        Box(Modifier.fillMaxSize()) {
            when (tab) {
                0 -> LibraryScreen({ open = it }, { picker.launch(arrayOf("*/*")) })
                1 -> ReadingStatsScreen()
                2 -> CatalogScreen()
                3 -> NotesScreen()
                else -> SettingsScreen()
            }
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)) {
                Row(Modifier.clip(CircleShape).background(PANEL.copy(alpha = 0.96f)).border(1.dp, Line, CircleShape).padding(5.dp)) {
                    listOf("Библиотека", "Полка", "Каталог", "Заметки", "Настройки").forEachIndexed { i, t ->
                        val sel = i == tab
                        Box(Modifier.clip(CircleShape).then(if (sel) Modifier.background(Brush.horizontalGradient(listOf(ACCENT, ACCENT.copy(alpha = 0.78f)))) else Modifier).clickable { tab = i }) {
                            Text(t.uppercase(), Modifier.padding(horizontal = 10.dp, vertical = 13.dp), style = mono(10, if (sel) 1f else 0.72f), color = if (sel) Color.White else FG)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val activity = ctx as? MainActivity
    val rates = listOf(60, 90, 120, 144)
    Column(Modifier.fillMaxSize()) {
        Header("Настройки")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(PANEL, ACCENT.copy(alpha = 0.13f)))).border(1.dp, Line, RoundedCornerShape(24.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ТВОЁ ТИХОЕ МЕСТО", style = mono(9, 0.7f), color = MUTED)
                Text("Настрой атмосферу чтения", Modifier.padding(top = 6.dp), style = MaterialTheme.typography.titleLarge, color = FG)
                Text("Мягкие оттенки, спокойный ритм и любимые истории", Modifier.padding(top = 4.dp), style = mono(9, 0.62f), color = MUTED)
            }
            Text("✿", color = ACCENT, fontSize = 34.sp)
        }
        LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            item {
                Text("ТЕМА ОФОРМЛЕНИЯ", style = mono(11, 0.65f), color = MUTED)
                Text("Выбери оттенок своего читательского пространства", Modifier.padding(top = 6.dp), style = mono(9, 0.58f), color = MUTED)
                Spacer(Modifier.height(10.dp))
                ReaderSettings.themes.forEachIndexed { i, name ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (ReaderSettings.themeId == i) ACCENT.copy(alpha = 0.13f) else Color.Transparent)
                        .clickable { ReaderSettings.setTheme(i) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(ReaderSettings.themeBackgrounds[i]).border(1.dp, ReaderSettings.themeForegrounds[i].copy(alpha = 0.25f), CircleShape))
                        Text(name, Modifier.weight(1f).padding(start = 12.dp), style = mono(12), color = FG)
                        if (ReaderSettings.themeId == i) Text("ВЫБРАНА", color = ACCENT, style = mono(9))
                    }
                }
            }
            item {
                Text("ЦВЕТ АКЦЕНТА", style = mono(11, 0.55f))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ReaderSettings.accents.forEachIndexed { i, color ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { ReaderSettings.setAccent(i) }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(34.dp).clip(CircleShape).background(color).then(if (ReaderSettings.accentId == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier))
                            Text(ReaderSettings.accentNames[i], Modifier.padding(top = 6.dp), style = mono(8, if (ReaderSettings.accentId == i) 1f else 0.5f), maxLines = 1)
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("РЕЖИМ ЧТЕНИЯ СТРАНИЦАМИ", style = mono(12))
                        Text("Перелистывание свайпом или стрелками", Modifier.padding(top = 5.dp), style = mono(9, 0.5f))
                    }
                    Switch(checked = ReaderSettings.pageMode, onCheckedChange = { ReaderSettings.setPageMode(it) })
                }
            }
            item {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ЗАЩИТА ГЛАЗ", style = mono(12))
                        Text("Тёплая бумажная палитра в режиме чтения", Modifier.padding(top = 5.dp), style = mono(9, 0.5f))
                    }
                    Switch(checked = ReaderSettings.eyeProtection, onCheckedChange = { ReaderSettings.updateEyeProtection(it) })
                }
            }
            item {
                Text("ЧАСТОТА ОБНОВЛЕНИЯ ЭКРАНА", style = mono(11, 0.55f))
                Text("Предпочтительная частота дисплея", Modifier.padding(top = 6.dp, bottom = 12.dp), style = mono(10, 0.45f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rates.forEach { hz ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (ReaderSettings.refreshRate == hz) ACCENT.copy(alpha = 0.22f) else PANEL)
                            .border(1.dp, if (ReaderSettings.refreshRate == hz) ACCENT else Line, RoundedCornerShape(14.dp))
                            .clickable {
                                ReaderSettings.setRefresh(hz)
                                activity?.applyPreferredRefreshRate()
                            }.padding(vertical = 15.dp), Alignment.Center) {
                            Text("${hz} Гц", style = mono(10, if (ReaderSettings.refreshRate == hz) 1f else 0.65f), color = if (ReaderSettings.refreshRate == hz) ACCENT else FG)
                        }
                    }
                }
                Text("Фактическая частота зависит от возможностей экрана и системных настроек Android. Выбор задаёт предпочтение приложению.", Modifier.padding(top = 12.dp), style = mono(9, 0.4f))
            }
        }
    }
}

fun bookStatus(b: Book): String = when (b.status) {
    "PLANNED" -> "В ПЛАНАХ"
    "READING" -> "В ПРОЦЕССЕ"
    "DONE" -> "ЗАВЕРШЕНО"
    else -> when {
        b.id in Store.completed -> "ЗАВЕРШЕНО"
        b.pos > 0 -> "В ПРОЦЕССЕ"
        else -> "НЕ НАЧАТО"
    }
}

@Composable
fun StatusLabel(status: String) {
    val color = when (status) {
        "ЗАВЕРШЕНО" -> Color(0xFF65C99A)
        "В ПРОЦЕССЕ" -> ACCENT
        "В ПЛАНАХ" -> Color(0xFF9B8CFF)
        else -> MUTED
    }
    Text(status, Modifier.clip(CircleShape).background(color.copy(alpha = 0.13f))
        .border(1.dp, color.copy(alpha = 0.35f), CircleShape).padding(horizontal = 8.dp, vertical = 4.dp),
        color = color, style = mono(8))
}

@Composable
fun StatusPicker(book: Book) {
    var expanded by remember(book.id) { mutableStateOf(false) }
    Box {
        Box(Modifier.clickable { expanded = true }) { StatusLabel(bookStatus(book)) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false },
            modifier = Modifier.background(PANEL)) {
            listOf("" to "Автоматически", "PLANNED" to "В планах", "READING" to "В процессе", "DONE" to "Завершено").forEach { (value, label) ->
                DropdownMenuItem(text = { Text(label, style = mono(11)) }, onClick = {
                    Store.setStatus(book.id, value); expanded = false
                })
            }
        }
    }
}

@Composable
fun LibraryScreen(onOpen: (Book) -> Unit, onAdd: () -> Unit) {
    var del by remember { mutableStateOf<Book?>(null) }
    var info by remember { mutableStateOf(false) }
    val books = Store.books.toList()
    val reading = books.count { it.pos > 0 }
    Column(Modifier.fillMaxSize()) {
        Header("Библиотека", left = { IconBtn({ info = true }) { icInfo() } }, right = { IconBtn(onAdd) { icPlus() } })
        if (books.isEmpty()) {
            EmptyPanel(Modifier.padding(horizontal = 16.dp).fillMaxWidth().aspectRatio(0.9f)) {
                Column(Modifier.align(Alignment.BottomCenter).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ПОКА ПУСТО", style = mono(13))
                    Text("НАЖМИТЕ + ИЛИ СКАЧАЙТЕ КНИГИ В КАТАЛОГЕ", Modifier.padding(top = 6.dp), textAlign = TextAlign.Center, style = mono(10, 0.5f))
                }
            }
        } else LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            gridItemsIndexed(books, key = { _, b -> b.id }, span = { i, _ -> if (i % 5 == 4) GridItemSpan(maxLineSpan) else GridItemSpan(1) }) { i, b ->
                val wide = i % 5 == 4
                Tile(b.title, "${b.author} · ${bookStatus(b)}", b.ext.uppercase(), tint(b.id), b.pos > 0,
                    Modifier.fillMaxWidth().aspectRatio(if (wide) 1.75f else 0.8f), { onOpen(b) }, { del = b })
            }
        }
    }
    if (info) AlertDialog(onDismissRequest = { info = false }, containerColor = PANEL, shape = RoundedCornerShape(28.dp),
        title = { Text("БИБЛИОТЕКА", style = mono(13)) },
        text = { Text("КНИГ: ${books.size}\nЧИТАЮ: $reading\nНОВЫХ: ${books.size - reading}", style = mono(13, 0.8f)) },
        confirmButton = { TextButton({ info = false }) { Text("OK", color = ACCENT) } })
    del?.let { b ->
        AlertDialog(onDismissRequest = { del = null }, containerColor = PANEL, shape = RoundedCornerShape(28.dp),
            title = { Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = mono(13)) },
            text = { Text("Удалить книгу из библиотеки?", style = mono(12, 0.7f)) },
            confirmButton = { TextButton({ Store.remove(b); del = null }) { Text("УДАЛИТЬ", color = ACCENT) } },
            dismissButton = { TextButton({ del = null }) { Text("ОТМЕНА", color = Color.White.copy(alpha = 0.7f)) } })
    }
}


@Composable
fun ReadingStatsScreen() {
    val books = Store.books.toList()
    val done = books.filter { it.id in Store.completed }
    val events = Store.events.toList()
    val now = System.currentTimeMillis()
    val day = 24L * 60 * 60 * 1000
    val recent = events.filter { it.time >= now - 7 * day }
    val maxOpens = recent.count { it.pages == 0 }.coerceAtLeast(1)
    val hours = IntArray(24)
    events.filter { it.pages == 0 }.forEach {
        val h = java.util.Calendar.getInstance().apply { timeInMillis = it.time }.get(java.util.Calendar.HOUR_OF_DAY)
        hours[h]++
    }
    val maxHour = (hours.maxOrNull() ?: 1).coerceAtLeast(1)
    Column(Modifier.fillMaxSize()) {
        Header("Моя полка")
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Text("КНИЖНАЯ ПОЛКА · ${books.size} КНИГ", style = mono(11, 0.55f))
                Spacer(Modifier.height(12.dp))
                if (books.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(22.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(22.dp)), Alignment.Center) {
                        Text("ДОБАВЬТЕ КНИГУ В БИБЛИОТЕКУ\nОНА ПОЯВИТСЯ НА ПОЛКЕ", textAlign = TextAlign.Center, style = mono(11, 0.45f))
                    }
                } else {
                    LazyRow(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF17120F)).padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                        items(books, key = { it.id }) { b ->
                            Column(Modifier.width(48.dp).fillMaxHeight(), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                                    .background(Brush.verticalGradient(listOf(tint(b.id), tint(b.id).copy(alpha = 0.45f))))
                                    .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)), Alignment.Center) {
                                    Text(b.title.take(12).uppercase(), modifier = Modifier.padding(3.dp), style = mono(8, 0.9f), textAlign = TextAlign.Center, maxLines = 4)
                                }
                                Spacer(Modifier.height(4.dp))
                                Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0xFF80614A)))
                            }
                        }
                    }
                }
            }
            item {
                Text("СТАТУС КНИГ", style = mono(11, 0.55f))
                Spacer(Modifier.height(8.dp))
                books.forEach { b ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(PANEL).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(width = 5.dp, height = 38.dp).clip(RoundedCornerShape(4.dp)).background(tint(b.id)))
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(b.title, style = mono(10), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(b.author.ifBlank { b.ext.uppercase() }, style = mono(8, 0.45f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        StatusPicker(b)
                    }
                }
            }
            item {
                Text("АЧИВКИ", style = mono(11, 0.55f))
                Spacer(Modifier.height(10.dp))
                val night = events.any { java.util.Calendar.getInstance().apply { timeInMillis = it.time }.get(java.util.Calendar.HOUR_OF_DAY) >= 2 &&
                    java.util.Calendar.getInstance().apply { timeInMillis = it.time }.get(java.util.Calendar.HOUR_OF_DAY) < 5 }
                val marathon = events.filter { it.time >= now - day }.sumOf { it.pages } >= 100
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Achievement("🌙", "НОЧНОЙ ДОЗОР", night, "Чтение 02:00–04:59")
                    Achievement("⚡", "МАРАФОНЕЦ", marathon, "100 страниц за день")
                    Achievement("📚", "КОЛЛЕКЦИОНЕР", done.size >= 5, "5 завершённых книг")
                }
            }
            item {
                Text("ОТКРЫТИЯ КНИГ · 7 ДНЕЙ", style = mono(11, 0.55f))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(7) { d ->
                        val from = now - (6 - d) * day
                        val count = recent.count { it.time in (from - day + 1)..from && it.pages == 0 }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(7.dp))
                                .background(ACCENT.copy(alpha = (0.12f + 0.88f * count / maxOpens.toFloat()).coerceIn(0.12f, 1f))))
                            Text(listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС")[((java.util.Calendar.getInstance().apply { timeInMillis = from }.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7)],
                                Modifier.padding(top = 5.dp), style = mono(8, 0.5f))
                        }
                    }
                }
                Text("СКОЛЬКО РАЗ ОТКРЫВАЛИ · ПО ЧАСАМ", Modifier.padding(top = 18.dp), style = mono(10, 0.55f))
                Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                    hours.forEachIndexed { i, n ->
                        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height((8 + 62f * n / maxHour).dp).clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                .background(PALETTE[i % PALETTE.size].copy(alpha = if (n == 0) 0.16f else 0.9f)))
                        }
                    }
                }
                Text("00      06      12      18      23", Modifier.fillMaxWidth(), style = mono(8, 0.35f))
            }
            item {
                Text("СТАТИСТИКА", style = mono(11, 0.55f))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("СТРАНИЦ СЕГОДНЯ", Store.dailyPages().toString(), Modifier.weight(1f))
                    StatCard("В СРЕДНЕМ ЗА СЕАНС", Store.averageSessionPages().toString(), Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun RowScope.Achievement(emoji: String, name: String, unlocked: Boolean, desc: String) {
    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (unlocked) Color(0xFF282018) else PANEL)
        .border(1.dp, if (unlocked) Color(0xFFFFB45F).copy(alpha = 0.6f) else Line, RoundedCornerShape(16.dp)).padding(9.dp)) {
        Text(if (unlocked) emoji else "🔒", style = MaterialTheme.typography.titleMedium)
        Text(name, Modifier.padding(top = 6.dp), style = mono(8, if (unlocked) 1f else 0.35f), maxLines = 2)
        Text(desc, Modifier.padding(top = 4.dp), style = mono(7, 0.4f), maxLines = 2)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(14.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium, color = ACCENT)
        Text(label, Modifier.padding(top = 4.dp), style = mono(8, 0.5f))
    }
}

@Composable
fun CatalogScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf("") }
    var res by remember { mutableStateOf(listOf<Remote>()) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(setOf<String>()) }
    var src by remember { mutableIntStateOf(0) }
    var page by remember { mutableIntStateOf(1) }
    var hasMore by remember { mutableStateOf(true) }
    fun go(reset: Boolean = true) = scope.launch {
        if (loading) return@launch
        if (reset) { page = 1; res = emptyList(); hasMore = true }
        loading = true; err = null
        try {
            val nextPage = if (reset) 1 else page + 1
            val found = withContext(Dispatchers.IO) { Net.search(q, lang, src, nextPage) }
            res = if (reset) found else (res + found).distinctBy { it.id }
            page = nextPage
            hasMore = found.size >= when (src) { 0 -> 32; 2 -> 40; else -> 50 }
        } catch (e: Exception) { err = "Нет соединения или источник временно недоступен: ${e.message}" }
        loading = false
    }
    LaunchedEffect(lang, src) { go(true) }
    Column(Modifier.fillMaxSize()) {
        Header("Каталог")
        Column(Modifier.padding(horizontal = 16.dp)) {
            val fsh = RoundedCornerShape(28.dp)
            TextField(q, { q = it }, Modifier.fillMaxWidth().border(1.dp, Line, fsh), singleLine = true, shape = fsh,
                textStyle = mono(14),
                placeholder = { Text("НАЗВАНИЕ ИЛИ АВТОР", style = mono(13, 0.4f)) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = FG, unfocusedTextColor = FG, cursorColor = ACCENT),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { go(true) }))
            LazyRow(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(listOf("Gutenberg", "Archive · RU", "Google · Free", "Open Library")) { n ->
                    val i = listOf("Gutenberg", "Archive · RU", "Google · Free", "Open Library").indexOf(n)
                    Pill(n, src == i, PALETTE[(i * 2) % PALETTE.size]) { src = i }
                }
            }
            if (src == 0 || src == 3) Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("" to "Все", "ru" to "Русский", "en" to "English").forEachIndexed { i, (c, n) ->
                    Pill(n, lang == c, PALETTE[4 + i]) { lang = c }
                }
            }
            Text(when (src) {
                0 -> "Общественное достояние · бесплатные книги Project Gutenberg"
                1 -> "Поиск русскоязычных открытых текстов в Internet Archive"
                2 -> "Только бесплатные электронные книги Google Books"
                else -> "Открытый доступ · Open Library / Internet Archive"
            }, Modifier.padding(top = 8.dp), style = mono(9, 0.42f))
            Spacer(Modifier.height(10.dp))
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = ACCENT, trackColor = Color.White.copy(alpha = 0.08f))
            err?.let { Text(it, color = ACCENT, style = mono(11)) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 120.dp)) {
            items(res, key = { it.id }) { r ->
                val have = Store.books.any { it.id == r.id }
                val c = tint(r.id)
                ResultRow(r.title, r.author.ifEmpty { if (r.ext == "?") "EPUB / FB2 / PDF" else r.ext.uppercase() }, c) {
                    GhostBtn(if (have) "ЕСТЬ" else if (r.id in busy) "…" else "СКАЧАТЬ", !have && r.id !in busy, c) {
                        scope.launch {
                            busy = busy + r.id
                            try {
                                val f = withContext(Dispatchers.IO) { Net.fetch(r, File(ctx.filesDir, "books")) }
                                Store.add(Book(r.id, r.title, r.author, f.path, f.extension))
                                Toast.makeText(ctx, "Книга добавлена", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) { Toast.makeText(ctx, "Не удалось скачать: ${e.message}", Toast.LENGTH_LONG).show() }
                            busy = busy - r.id
                        }
                    }
                }
            }
            item {
                if (hasMore && res.isNotEmpty()) {
                    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), Alignment.Center) {
                        GhostBtn(if (loading) "ЗАГРУЗКА…" else "ПОКАЗАТЬ ЕЩЁ", !loading, ACCENT) { go(false) }
                    }
                } else if (res.isEmpty() && !loading && err == null) {
                    Text("Ничего не найдено. Попробуйте другой запрос или источник.", Modifier.fillMaxWidth().padding(20.dp), textAlign = TextAlign.Center, style = mono(11, .5f))
                }
            }
        }
    }
}

data class ReaderEntry(val book: String, val body: String, val kind: String, val time: Long, val context: String = "")

object NotesStore {
    private lateinit var prefs: android.content.SharedPreferences
    val entries = mutableStateListOf<ReaderEntry>()
    fun init(context: android.content.Context) {
        prefs = context.getSharedPreferences("reader_notes", 0)
        val a = org.json.JSONArray(prefs.getString("entries", "[]"))
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); entries.add(ReaderEntry(o.optString("book"), o.optString("body"), o.optString("kind"), o.optLong("time"), o.optString("context"))) }
    }
    fun add(e: ReaderEntry) { entries.add(0, e); save() }
    fun remove(index: Int) { if (index in entries.indices) { entries.removeAt(index); save() } }
    private fun save() { val a = org.json.JSONArray(); entries.forEach { a.put(org.json.JSONObject().put("book",it.book).put("body",it.body).put("kind",it.kind).put("time",it.time).put("context",it.context)) }; prefs.edit().putString("entries", a.toString()).apply() }
}

@Composable
fun EntryDialog(title: String, hint: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var body by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = PANEL, title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { OutlinedTextField(body, { body = it }, placeholder = { Text(hint) }, minLines = 4, maxLines = 7) },
        confirmButton = { TextButton(onClick = { if (body.isNotBlank()) onSave(body.trim()) }) { Text("СОХРАНИТЬ", color = ACCENT) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ОТМЕНА", color = Color.White.copy(alpha=.55f)) } })
}

@Composable
fun NotesScreen() {
    val entries = NotesStore.entries.toList()
    Column(Modifier.fillMaxSize()) {
        Header("Заметки")
        if (entries.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("ТВОИ ЦИТАТЫ И МЫСЛИ\nБУДУТ ЖИТЬ ЗДЕСЬ", textAlign = TextAlign.Center, style = mono(12, .45f)) }
        else LazyColumn(contentPadding = PaddingValues(start=16.dp,end=16.dp,bottom=120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(entries) { e ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF28202A), Color(0xFF151519)))).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(17.dp)) {
                    Text(e.kind.uppercase(), color=ACCENT, style=mono(9))
                    Text(e.body, Modifier.padding(top=10.dp), style=MaterialTheme.typography.bodyLarge)
                    Text(e.book + if (e.context.isNotBlank()) " · ${e.context}" else "", Modifier.padding(top=12.dp), color=MUTED, style=mono(9))
                    if (e.kind == "Цитата") {
                        val ctx = LocalContext.current
                        Text("ПОДЕЛИТЬСЯ КАРТОЧКОЙ  ↗", Modifier.padding(top=10.dp).clickable {
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_TEXT, "❝ ${e.body} ❞\n— ${e.book}\n170BOOKS")
                            }
                            ctx.startActivity(android.content.Intent.createChooser(send, "Поделиться цитатой"))
                        }, color=ACCENT, style=mono(9))
                    }
                }
            }
        }
    }
}

@Composable
fun Reader(b: Book, onBack: () -> Unit) {
    LaunchedEffect(b.id) { Store.startSession(b.id) }
    var size by remember { mutableIntStateOf(19) }
    var showNote by remember { mutableStateOf(false) }
    var showQuote by remember { mutableStateOf(false) }
    var pageIndex by remember(b.id) { mutableIntStateOf((Store.books.firstOrNull { it.id == b.id }?.pos ?: 0) / 5) }
    Scaffold(containerColor = if (ReaderSettings.eyeProtection) Color(0xFFF0E6D0) else BG, topBar = {
        Row(Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(onBack) { icBack() }
            Text(b.title.uppercase(), Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, style = mono(12, 0.8f))
            if (b.ext != "pdf" && ReaderSettings.pageMode) {
                Text("‹", Modifier.clickable { pageIndex = (pageIndex - 1).coerceAtLeast(0) }.padding(horizontal = 5.dp), color = ACCENT, style = MaterialTheme.typography.headlineMedium)
            }
            Text("❝", Modifier.clickable { showQuote = true }.padding(horizontal = 7.dp), color = ACCENT, style = MaterialTheme.typography.titleLarge)
            if (b.ext != "pdf" && ReaderSettings.pageMode) {
                Text("›", Modifier.clickable { pageIndex++ }.padding(horizontal = 5.dp), color = ACCENT, style = MaterialTheme.typography.headlineMedium)
            }
            Text("✎", Modifier.clickable { showNote = true }.padding(horizontal = 7.dp), color = FG, style = MaterialTheme.typography.titleLarge)
            if (b.ext != "pdf") Row(Modifier.clip(CircleShape).border(1.dp, Line, CircleShape)) {
                Text("A−", Modifier.clickable { if (size > 12) size-- }.padding(horizontal = 14.dp, vertical = 10.dp), style = mono(13))
                Text("A+", Modifier.clickable { if (size < 34) size++ }.padding(horizontal = 14.dp, vertical = 10.dp), style = mono(13))
            } else Spacer(Modifier.size(40.dp))
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(if (ReaderSettings.eyeProtection) Color(0xFFF0E6D0) else BG)) { if (b.ext == "pdf") PdfView(b) else TextView(b, size, pageIndex, { pageIndex = it }) }
    }
    if (showNote) EntryDialog("Новая заметка", "Запиши мысль, настроение или идею…", onDismiss = { showNote = false }) { body -> NotesStore.add(ReaderEntry(b.title, body, "Заметка", System.currentTimeMillis(), "Фрагмент ${Store.books.firstOrNull { it.id == b.id }?.pos?.plus(1) ?: 1}")); showNote = false }
    if (showQuote) EntryDialog("Сохранить цитату", "Вставь или напиши цитату из книги…", onDismiss = { showQuote = false }) { body -> NotesStore.add(ReaderEntry(b.title, body, "Цитата", System.currentTimeMillis(), "Фрагмент ${Store.books.firstOrNull { it.id == b.id }?.pos?.plus(1) ?: 1}")); showQuote = false }
}

@Composable
fun TextView(b: Book, size: Int, externalPage: Int = 0, onExternalPage: (Int) -> Unit = {}) {
    val bookFont = LocalBookFont.current
    val st = produceState<Result<List<String>>?>(null, b.id) {
        value = withContext(Dispatchers.IO) { runCatching { Parsers.load(File(b.path), b.ext) } }
    }
    val r = st.value
    if (r == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = ACCENT, strokeWidth = 2.dp) }; return }
    val l = r.getOrNull()
    if (l.isNullOrEmpty()) {
        Text("Не удалось открыть книгу: ${r.exceptionOrNull()?.message ?: "пустой файл"}", Modifier.padding(24.dp), style = mono(12, 0.7f)); return
    }
    val perPage = 5
    val pageCount = (l.size + perPage - 1) / perPage
    val page = externalPage.coerceIn(0, pageCount - 1)
    LaunchedEffect(externalPage, pageCount) { if (externalPage != page) onExternalPage(page) }
    LaunchedEffect(page) {
        onExternalPage(page)
        Store.setPos(b.id, (page * perPage).coerceIn(0, l.lastIndex))
        if (page >= pageCount - 1) Store.finishBook(b.id)
    }
    val pct = ((page + 1) * 100 / pageCount).coerceIn(1, 100)
    if (ReaderSettings.pageMode) {
        var drag by remember { mutableFloatStateOf(0f) }
        Box(Modifier.fillMaxSize().background(if (ReaderSettings.eyeProtection) Color(0xFFF0E6D0) else BG)
            .pointerInput(page, pageCount) {
                detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                    if (drag < -45f) onExternalPage((page + 1).coerceAtMost(pageCount - 1))
                    if (drag > 45f) onExternalPage((page - 1).coerceAtLeast(0))
                    drag = 0f
                })
            }) {
            LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp)) {
                items(l.subList(page * perPage, minOf((page + 1) * perPage, l.size))) { paragraph ->
                    Text(paragraph, Modifier.padding(bottom = 18.dp), color = if (ReaderSettings.eyeProtection) Color(0xFF40372B) else Color(0xFFE9E5DC),
                        style = MaterialTheme.typography.bodyLarge.copy(fontFamily = bookFont, fontSize = size.sp, lineHeight = (size * 1.55f).sp))
                }
            }
            Text("${page + 1} / $pageCount  ·  $pct%", Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp).clip(CircleShape)
                .background(PANEL).border(1.dp, Line, CircleShape).padding(horizontal = 16.dp, vertical = 8.dp), style = mono(11))
        }
    } else {
        val ls = rememberLazyListState(b.pos.coerceIn(0, l.size - 1))
        LaunchedEffect(ls) { snapshotFlow { ls.firstVisibleItemIndex }.collect {
            Store.setPos(b.id, it)
            onExternalPage(it / perPage)
            if (it >= l.lastIndex) Store.finishBook(b.id)
        } }
        Box(Modifier.fillMaxSize()) {
            LazyColumn(state = ls, modifier = Modifier.fillMaxSize().background(if (ReaderSettings.eyeProtection) Color(0xFFF0E6D0) else BG), contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp)) {
                items(l) { p ->
                    Text(p, Modifier.padding(bottom = 14.dp), color = if (ReaderSettings.eyeProtection) Color(0xFF40372B) else Color(0xFFE9E5DC),
                        style = MaterialTheme.typography.bodyLarge.copy(fontFamily = bookFont, fontSize = size.sp, lineHeight = (size * 1.55f).sp))
                }
            }
            val scrollPct by remember { derivedStateOf { (ls.firstVisibleItemIndex + 1) * 100 / l.size } }
            Text("$scrollPct%", Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp).clip(CircleShape)
                .background(PANEL).border(1.dp, Line, CircleShape).padding(horizontal = 16.dp, vertical = 8.dp), style = mono(11))
        }
    }
}

@Composable
fun PdfView(b: Book) {
    val pfd = remember { ParcelFileDescriptor.open(File(b.path), ParcelFileDescriptor.MODE_READ_ONLY) }
    val r = remember { runCatching { PdfRenderer(pfd) }.getOrNull() }
    val mu = remember { Mutex() }
    DisposableEffect(Unit) { onDispose { runCatching { r?.close() }; runCatching { pfd.close() } } }
    if (r == null || r.pageCount == 0) { Text("Не удалось открыть PDF (возможно, он защищён паролем).", Modifier.padding(24.dp), style = mono(12, 0.7f)); return }
    val ls = rememberLazyListState(b.pos.coerceIn(0, r.pageCount - 1))
    LaunchedEffect(ls) { snapshotFlow { ls.firstVisibleItemIndex }.collect {
        Store.setPos(b.id, it)
        if (it >= r.pageCount - 1) Store.finishBook(b.id)
    } }
    LazyColumn(state = ls, verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(8.dp)) {
        items(r.pageCount) { i ->
            val bmp by produceState<Bitmap?>(null, i) {
                value = mu.withLock {
                    withContext(Dispatchers.IO) {
                        r.openPage(i).use { p ->
                            val w = 1080; val h = w * p.height / p.width
                            val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bm.eraseColor(android.graphics.Color.WHITE)
                            p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); bm
                        }
                    }
                }
            }
            val m = bmp
            if (m != null) Image(m.asImageBitmap(), null, Modifier.fillMaxWidth())
            else Box(Modifier.fillMaxWidth().aspectRatio(0.7f))
        }
    }
}
