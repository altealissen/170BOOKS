package app.reader

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL

/** Local Qwen2.5 GGUF runtime backed by llama.cpp JNI. */
object PukichLlm {
    private const val MODEL = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/$MODEL?download=true"

    @Volatile private var loaded = false
    private val lock = Any()

    private val nativeAvailable: Boolean = runCatching {
        System.loadLibrary("pukich_llama")
        true
    }.getOrDefault(false)

    private external fun nativeLoad(modelPath: String): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int): String
    private external fun nativeClose()

    fun modelFile(context: Context) = File(context.filesDir, MODEL)
    fun installed(context: Context): Boolean = runCatching {
        val file = modelFile(context)
        file.isFile && file.length() > 100L * 1024 * 1024 && hasGgufHeader(file)
    }.getOrDefault(false)
    fun isLoaded() = loaded

    /** Download with safe HTTP Range handling. Hugging Face may redirect to Xet/CDN. */
    fun download(context: Context, progress: (Long, Long) -> Unit) {
        val target = modelFile(context)
        val temp = File(context.filesDir, "$MODEL.part")
        if (installed(context)) {
            progress(target.length(), target.length())
            return
        }
        if (target.exists()) target.delete()

        var offset = temp.length()
        if (offset > 0L && !hasGgufHeader(temp) && offset >= 4L) {
            temp.delete()
            offset = 0L
        }

        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30000
            readTimeout = 180000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "170BOOKS-Pukich/2.3")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("Cache-Control", "no-cache")
            if (offset > 0L) setRequestProperty("Range", "bytes=$offset-")
        }
        try {
            connection.connect()
            val code = connection.responseCode
            if (code == 416 && offset > 0L) {
                val remoteSize = connection.getHeaderField("Content-Range")
                    ?.let { Regex("bytes \\*/(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull() }
                if (remoteSize != null && temp.length() == remoteSize && hasGgufHeader(temp)) {
                    close()
                    if (!temp.renameTo(target)) { temp.copyTo(target, overwrite = true); temp.delete() }
                    progress(target.length(), target.length())
                    return
                }
            }
            if (code !in 200..299) {
                val detail = runCatching { connection.errorStream?.bufferedReader()?.use { it.readText() } }.getOrNull()
                error("Hugging Face вернул HTTP $code${detail?.take(160)?.let { ": $it" } ?: ""}")
            }

            val append = if (offset > 0L && code == HttpURLConnection.HTTP_PARTIAL) {
                val range = connection.getHeaderField("Content-Range")
                    ?: error("Сервер вернул 206 без Content-Range. Повтори загрузку.")
                val match = Regex("bytes (\\d+)-(\\d+)/(\\d+|\\*)", RegexOption.IGNORE_CASE).find(range)
                    ?: error("Некорректный Content-Range от сервера: $range")
                val start = match.groupValues[1].toLong()
                if (start != offset) error("Сервер начал докачку с $start вместо $offset байт. Повтори загрузку.")
                true
            } else {
                // CDN ignored Range or returned a fresh full response: restart, never append twice.
                if (code != HttpURLConnection.HTTP_OK && offset > 0L) error("Неожиданный HTTP $code при докачке")
                false
            }

            val contentRange = connection.getHeaderField("Content-Range")
            val totalFromRange = contentRange?.let {
                Regex("bytes \\d+-\\d+/(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull()
            }
            val contentLength = connection.contentLengthLong.takeIf { it > 0L }
            val total = totalFromRange ?: if (contentLength != null) contentLength + if (append) offset else 0L else -1L
            if (!append) offset = 0L

            connection.inputStream.buffered().use { input ->
                FileOutputStream(temp, append).buffered().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var count = offset
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        count += n
                        progress(count, if (total > 0L) total else count)
                    }
                    output.flush()
                }
            }

            val actual = temp.length()
            if (total > 0L && actual != total) {
                error("Загрузка неполная: получено $actual из $total байт. Нажми «Продолжить» — докачка возобновится.")
            }
            if (actual < 100L * 1024 * 1024 || !hasGgufHeader(temp)) {
                temp.delete()
                error("Скачанный файл не похож на GGUF-модель Qwen. Файл удалён; попробуй ещё раз.")
            }
            close()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            progress(target.length(), target.length())
        } finally {
            connection.disconnect()
        }
    }

    private fun hasGgufHeader(file: File): Boolean = runCatching {
        if (!file.isFile || file.length() < 4L) return@runCatching false
        RandomAccessFile(file, "r").use { raf ->
            val magic = ByteArray(4)
            raf.readFully(magic)
            magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46)) // GGUF
        }
    }.getOrDefault(false)

    @Synchronized fun answer(context: Context, prompt: String): String {
        check(nativeAvailable) { "Нативный движок Qwen не загрузился. Переустанови приложение или проверь сборку для arm64." }
        val file = modelFile(context)
        check(installed(context)) { "Сначала скачай Qwen2.5 в настройках." }
        synchronized(lock) {
            if (!loaded) {
                check(nativeLoad(file.absolutePath)) { "Не удалось запустить Qwen. Проверь свободную память телефона." }
                loaded = true
            }
        }
        return nativeGenerate(prompt, 320).trim().ifBlank { "Я задумался, начальник. Попробуй спросить немного иначе." }
    }

    @Synchronized fun close() {
        if (loaded) nativeClose()
        loaded = false
    }

    fun remove(context: Context) {
        close()
        modelFile(context).delete()
        File(context.filesDir, "$MODEL.part").delete()
    }
}
