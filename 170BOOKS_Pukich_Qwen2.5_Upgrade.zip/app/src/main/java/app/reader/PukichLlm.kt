package app.reader

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Local Qwen2.5 GGUF runtime backed by llama.cpp JNI. */
object PukichLlm {
    private const val MODEL = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/$MODEL?download=true"
    private const val EXPECTED_SIZE = 491_400_032L
    private const val SHA256 = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db"

    @Volatile private var loaded = false
    private val lock = Any()

    init { System.loadLibrary("pukich_llama") }

    private external fun nativeLoad(modelPath: String): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int): String
    private external fun nativeClose()

    fun modelFile(context: Context) = File(context.filesDir, MODEL)
    fun installed(context: Context) = modelFile(context).let { it.isFile && it.length() == EXPECTED_SIZE }
    fun isLoaded() = loaded

    fun download(context: Context, progress: (Long, Long) -> Unit) {
        val target = modelFile(context)
        val temp = File(context.filesDir, "$MODEL.part")
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 25000
            readTimeout = 180000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "170BOOKS-Pukich/2.1")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("Сервер модели ответил: HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong.takeIf { it > 0 } ?: EXPECTED_SIZE
            connection.inputStream.use { input ->
                temp.outputStream().buffered().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var count = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        count += n
                        progress(count, total)
                    }
                }
            }
            if (temp.length() != EXPECTED_SIZE) error("Размер модели не совпал: ${temp.length()} байт вместо $EXPECTED_SIZE. Попробуй скачать ещё раз.")
            val digest = MessageDigest.getInstance("SHA-256")
            temp.inputStream().buffered().use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    digest.update(buffer, 0, n)
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(SHA256, ignoreCase = true)) error("Контрольная сумма модели не совпала. Файл удалён, скачай заново.")
            close()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
        } finally {
            connection.disconnect()
        }
    }

    @Synchronized fun answer(context: Context, prompt: String): String {
        val file = modelFile(context)
        check(installed(context)) { "Сначала скачай Qwen2.5 в настройках." }
        synchronized(lock) {
            if (!loaded) {
                check(nativeLoad(file.absolutePath)) { "Не удалось запустить Qwen. Проверь свободную память телефона." }
                loaded = true
            }
        }
        return nativeGenerate(prompt, 320).trim().ifBlank { "Я задумался, начальник. Попробуй спросить немного иначе." }
    }

    @Synchronized fun close() {
        if (loaded) nativeClose()
        loaded = false
    }

    fun remove(context: Context) {
        close()
        modelFile(context).delete()
        File(context.filesDir, "$MODEL.part").delete()
    }
}
