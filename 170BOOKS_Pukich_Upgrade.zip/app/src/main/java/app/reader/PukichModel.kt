package app.reader

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Small, private on-device linear text classifier. It does not generate prose. */
object PukichModel {
    private const val FILE = "pukich-model.json"
    fun isInstalled(context: Context): Boolean = File(context.filesDir, FILE).isFile

    fun install(context: Context) {
        val target = File(context.filesDir, FILE)
        context.assets.open("pukich_model.json").use { input -> target.outputStream().use { output -> input.copyTo(output) } }
    }

    fun remove(context: Context) { File(context.filesDir, FILE).delete() }

    /** Returns predicted genre and a concise search query. All text processing is local. */
    fun analyze(context: Context, text: String): Pair<String, String> {
        val clean = text.trim().replace(Regex("\\s+"), " ").take(240)
        if (clean.isBlank()) return "Не определён" to ""
        val modelFile = File(context.filesDir, FILE)
        if (!modelFile.isFile) return "Базовый поиск" to clean
        val root = JSONObject(modelFile.readText(Charsets.UTF_8))
        val weights = root.optJSONObject("weights") ?: return "Базовый поиск" to clean
        val normalized = clean.lowercase()
        var best = ""
        var bestScore = 0
        val keys = weights.keys()
        while (keys.hasNext()) {
            val genre = keys.next()
            val terms = weights.optJSONArray(genre) ?: continue
            var score = 0
            for (i in 0 until terms.length()) {
                val token = terms.optString(i)
                if (token.isNotBlank() && normalized.contains(token)) score += 2
            }
            if (score > bestScore) { bestScore = score; best = genre }
        }
        val labels = mapOf("fantasy" to "Фэнтези / фантастика", "detective" to "Детектив / триллер",
            "romance" to "Роман / драма", "science" to "Научная и познавательная литература",
            "adventure" to "Приключения / история", "classic" to "Классическая литература")
        // This is a compact linear classifier: it adds a genre hint only when the model found a signal.
        val query = if (bestScore > 0 && !normalized.contains(best)) "$clean ${labels[best] ?: ""}" else clean
        return (labels[best] ?: "Смешанный запрос") to query.trim()
    }
}
