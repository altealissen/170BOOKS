package app.reader

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Local Qwen2.5 GGUF runtime backed by llama.cpp JNI. */
object PukichLlm {
    private const val MODEL = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/$MODEL?download=true"
    private const val EXPECTED_SIZE = 491_400_032L
    private const val SHA256 = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db"

    @Volatile private var loaded = false
    private val lock = Any()

    private val nativeAvailable: Boolean = runCatching {
        System.loadLibrary("pukich_llama")
        true
    }.getOrDefault(false)

    private external fun nativeLoad(modelPath: String): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int): String
    private external fun nativeClose()

    fun modelFile(context: Context) = File(context.filesDir, MODEL)
    fun installed(context: Context) = modelFile(context).let { it.isFile && it.length() == EXPECTED_SIZE }
    fun isLoaded() = loaded

    fun download(context: Context, progress: (Long, Long) -> Unit) {
        val target = modelFile(context)
        val temp = File(context.filesDir, "$MODEL.part")
        if (target.isFile && target.length() == EXPECTED_SIZE && sha256(target).equals(SHA256, true)) {
            progress(EXPECTED_SIZE, EXPECTED_SIZE)
            return
        }
        if (target.exists()) target.delete()
        var offset = temp.length().coerceAtMost(EXPECTED_SIZE)
        if (offset == EXPECTED_SIZE) {
            if (sha256(temp).equals(SHA256, true)) {
                close()
                if (!temp.renameTo(target)) { temp.copyTo(target, overwrite = true); temp.delete() }
                progress(EXPECTED_SIZE, EXPECTED_SIZE)
                return
            }
            temp.delete()
            offset = 0L
        }
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30000
            readTimeout = 180000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "170BOOKS-Pukich/2.2")
            if (offset > 0) setRequestProperty("Range", "bytes=$offset-")
        }
        try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) error("Сервер модели ответил: HTTP $code")
            // Some mirrors ignore Range. In that case restart instead of appending
            // a second copy of the model to the partial file.
            val append = offset > 0 && code == HttpURLConnection.HTTP_PARTIAL
            if (!append) offset = 0L
            val total = (connection.contentLengthLong.takeIf { it > 0 }?.plus(offset) ?: EXPECTED_SIZE)
            connection.inputStream.buffered().use { input ->
                temp.outputStream(append).buffered().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var count = offset
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        count += n
                        progress(count, total)
                    }
                    output.flush()
                }
            }
            if (temp.length() != EXPECTED_SIZE) {
                error("Загрузка прервалась: ${temp.length()} из $EXPECTED_SIZE байт. Нажми «Продолжить» — докачка начнётся с этого места.")
            }
            if (!sha256(temp).equals(SHA256, true)) {
                temp.delete()
                error("Контрольная сумма модели не совпала. Частичный файл удалён; попробуй ещё раз.")
            }
            close()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            progress(EXPECTED_SIZE, EXPECTED_SIZE)
        } finally {
            connection.disconnect()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    @Synchronized fun answer(context: Context, prompt: String): String {
        check(nativeAvailable) { "Нативный движок Qwen не загрузился. Переустанови приложение или проверь сборку для arm64." }
        val file = modelFile(context)
        check(installed(context)) { "Сначала скачай Qwen2.5 в настройках." }
        synchronized(lock) {
            if (!loaded) {
                check(nativeLoad(file.absolutePath)) { "Не удалось запустить Qwen. Проверь свободную память телефона." }
                loaded = true
            }
        }
        return nativeGenerate(prompt, 320).trim().ifBlank { "Я задумался, начальник. Попробуй спросить немного иначе." }
    }

    @Synchronized fun close() {
        if (loaded) nativeClose()
        loaded = false
    }

    fun remove(context: Context) {
        close()
        modelFile(context).delete()
        File(context.filesDir, "$MODEL.part").delete()
    }
}
