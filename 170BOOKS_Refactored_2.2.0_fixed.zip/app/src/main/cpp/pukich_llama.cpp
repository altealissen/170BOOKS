#include <jni.h>
#include <android/log.h>
#include "llama.h"
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <thread>
#include <cstring>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "PukichLlama", __VA_ARGS__)
static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static std::mutex g_mutex;

extern "C" JNIEXPORT jboolean JNICALL
Java_app_reader_PukichLlm_nativeLoad(JNIEnv *env, jobject /*thiz*/, jstring path_) {
    std::lock_guard<std::mutex> guard(g_mutex);
    const char *path = env->GetStringUTFChars(path_, nullptr);
    if (!path) return JNI_FALSE;
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_free_model(g_model); g_model = nullptr; }
    llama_backend_init();
    llama_model_params model_params = llama_model_default_params();
    model_params.use_mmap = true;
    g_model = llama_model_load_from_file(path, model_params);
    env->ReleaseStringUTFChars(path_, path);
    if (!g_model) { LOGE("llama_load_model_from_file failed"); return JNI_FALSE; }
    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = 2048;
    ctx_params.n_batch = 2048;
    // Avoid spawning dozens of workers on mobile CPUs: it hurts thermals and
    // can starve the UI while the model is generating.
    ctx_params.n_threads = std::clamp((int) std::thread::hardware_concurrency(), 2, 4);
    ctx_params.n_threads_batch = ctx_params.n_threads;
    g_ctx = llama_init_from_model(g_model, ctx_params);
    if (!g_ctx) {
        llama_free_model(g_model); g_model = nullptr;
        LOGE("llama_new_context_with_model failed");
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_app_reader_PukichLlm_nativeGenerate(JNIEnv *env, jobject /*thiz*/, jstring prompt_, jint max_tokens) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (!g_model || !g_ctx) return env->NewStringUTF("Локальная модель ещё не запущена.");
    const char *prompt = env->GetStringUTFChars(prompt_, nullptr);
    if (!prompt) return env->NewStringUTF("");
    const int n_ctx = (int) llama_n_ctx(g_ctx);
    std::vector<llama_token> tokens((size_t)n_ctx);
    const struct llama_vocab * vocab = llama_model_get_vocab(g_model);
    int n_tokens = llama_tokenize(vocab, prompt, (int)strlen(prompt), tokens.data(), (int)tokens.size(), true, true);
    env->ReleaseStringUTFChars(prompt_, prompt);
    if (n_tokens < 0) return env->NewStringUTF("Запрос слишком длинный для локального контекста.");
    tokens.resize((size_t)n_tokens);
    llama_kv_cache_clear(g_ctx);
    llama_batch batch = llama_batch_get_one(tokens.data(), (int)tokens.size());
    if (llama_decode(g_ctx, batch) != 0)
        return env->NewStringUTF("Не удалось обработать запрос локальной моделью.");

    llama_sampler_chain_params sampler_params = llama_sampler_chain_default_params();
    llama_sampler * sampler = llama_sampler_chain_init(sampler_params);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.90f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.70f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string output;
    const int limit = std::min((int)max_tokens, 512);
    for (int i = 0; i < limit; ++i) {
        llama_token token = llama_sampler_sample(sampler, g_ctx, -1);
        llama_sampler_accept(sampler, token);
        if (llama_vocab_is_eog(vocab, token)) break;
        char piece[256];
        int piece_len = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, true);
        if (piece_len > 0) output.append(piece, (size_t)piece_len);
        llama_token next = token;
        llama_batch next_batch = llama_batch_get_one(&next, 1);
        if (llama_decode(g_ctx, next_batch) != 0) break;
    }
    llama_sampler_free(sampler);
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_app_reader_PukichLlm_nativeClose(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_free_model(g_model); g_model = nullptr; }
}
