package app.reader

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.zip.ZipFile
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

val SUPPORTED = setOf("epub", "fb2", "fb2zip", "mobi", "azw", "prc", "txt", "html", "htm", "xhtml", "rtf", "docx", "pdf")

fun extOf(name: String): String {
    val n = name.lowercase()
    return if (n.endsWith(".fb2.zip")) "fb2zip" else n.substringAfterLast('.', "")
}

data class Book(val id: String, val title: String, val author: String, val path: String, val ext: String, val pos: Int = 0, val status: String = "")
data class ReadingEvent(val time: Long, val pages: Int, val bookId: String)
data class Remote(val id: String, val title: String, val author: String, val url: String, val ext: String)

object Store {
    private lateinit var sp: SharedPreferences
    val books = mutableStateListOf<Book>()
    val completed = mutableStateListOf<String>()
    val events = mutableStateListOf<ReadingEvent>()
    private var sessionBook = ""
    private var sessionPages = 0
    private var lastPos = 0
    fun init(c: Context) {
        sp = c.getSharedPreferences("lib", 0)
        // Recover gracefully from a partially written/corrupt preferences payload.
        books.clear(); completed.clear(); events.clear()
        val a = runCatching { JSONArray(sp.getString("b", "[]")) }.getOrDefault(JSONArray())
        val ca = runCatching { JSONArray(sp.getString("completed", "[]")) }.getOrDefault(JSONArray())
        for (i in 0 until ca.length()) runCatching { completed.add(ca.getString(i)) }
        val ea = runCatching { JSONArray(sp.getString("events", "[]")) }.getOrDefault(JSONArray())
        for (i in 0 until ea.length()) runCatching {
            val o = ea.getJSONObject(i)
            events.add(ReadingEvent(o.getLong("time"), o.optInt("pages"), o.optString("bookId")))
        }
        for (i in 0 until a.length()) runCatching {
            val o = a.getJSONObject(i)
            val path = o.getString("path")
            val f = File(path)
            if (f.isFile && f.length() > 0L) books.add(Book(
                o.getString("id"), o.optString("title", "Без названия"), o.optString("author"),
                path, o.optString("ext", extOf(path)), o.optInt("pos").coerceAtLeast(0), o.optString("status", "")
            ))
        }
        // Remove dead file references from persisted library immediately.
        save()
    }
    private fun save() {
        val a = JSONArray()
        books.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("author", it.author).put("path", it.path).put("ext", it.ext).put("pos", it.pos).put("status", it.status)) }
        val ca = JSONArray(); completed.forEach { ca.put(it) }
        val ea = JSONArray(); events.takeLast(5000).forEach { ea.put(JSONObject().put("time", it.time).put("pages", it.pages).put("bookId", it.bookId)) }
        sp.edit().putString("b", a.toString()).putString("completed", ca.toString()).putString("events", ea.toString()).apply()
    }
    fun add(b: Book) {
        val file = File(b.path)
        require(file.isFile && file.length() > 0L) { "Файл книги не сохранён или пустой" }
        require(b.ext.lowercase() in SUPPORTED) { "Формат .${b.ext} не поддерживается" }
        books.removeAll { it.id == b.id }
        books.add(0, b.copy(pos = b.pos.coerceAtLeast(0)))
        save()
    }
    fun startSession(id: String) {
        sessionBook = id; sessionPages = 0
        lastPos = books.firstOrNull { it.id == id }?.pos ?: 0
        events.add(ReadingEvent(System.currentTimeMillis(), 0, id)); save()
    }
    fun finishBook(id: String) {
        if (id !in completed) completed.add(id)
        val i = books.indexOfFirst { it.id == id }
        if (i >= 0) books[i] = books[i].copy(status = "DONE")
        save()
    }
    fun setStatus(id: String, status: String) {
        val i = books.indexOfFirst { it.id == id }
        if (i >= 0) {
            books[i] = books[i].copy(status = status)
            if (status == "DONE") { if (id !in completed) completed.add(id) } else completed.remove(id)
            save()
        }
    }
    fun dailyPages(): Int {
        val start = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        return events.filter { it.time >= start }.sumOf { it.pages }
    }
    fun averageSessionPages(): Int {
        val sessions = events.filter { it.pages == 0 }.size
        val pages = events.sumOf { it.pages }
        return if (sessions == 0) 0 else pages / sessions
    }
    fun setPos(id: String, pos: Int) {
        val i = books.indexOfFirst { it.id == id }
        if (i >= 0 && books[i].pos != pos) {
            val delta = (pos - lastPos).coerceAtLeast(0)
            if (sessionBook == id && delta > 0) {
                sessionPages += delta
                events.add(ReadingEvent(System.currentTimeMillis(), delta, id))
            }
            lastPos = pos
            books[i] = books[i].copy(pos = pos); save()
        }
    }
    fun remove(b: Book) { File(b.path).delete(); books.remove(b); completed.remove(b.id); save() }
}

object Net {
    private fun conn(u: String): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "170BOOKS/2.2 (Android ebook reader)")
        c.setRequestProperty("Accept", "application/json, application/epub+zip, application/pdf, */*")
        c.instanceFollowRedirects = true
        return c
    }
    fun search(q: String, lang: String, src: Int = 0, page: Int = 1): List<Remote> = when (src) {
        0 -> gutenberg(q, lang, page)
        1 -> archive(q, page)
        2 -> googleFree(q, page)
        else -> openLibrary(q, lang, page)
    }

    private fun get(u: String): String {
        val c = conn(u)
        try {
            val code = c.responseCode
            if (code !in 200..299) {
                val detail = runCatching { c.errorStream?.bufferedReader()?.use { it.readText() } }.getOrNull()
                error("HTTP $code${detail?.take(180)?.let { ": $it" } ?: ""}")
            }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun archive(q: String, page: Int): List<Remote> {
        val t = q.trim().replace(Regex("[\\\\\"():]"), " ")
        val query = (if (t.isEmpty()) "" else "($t) AND ") + "language:(rus OR russian) AND mediatype:texts AND (licenseurl:*creativecommons* OR licenseurl:*publicdomain*) AND -collection:(inlibrary OR printdisabled)"
        val d = JSONObject(get("https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(query, "UTF-8") +
            "&fl[]=identifier&fl[]=title&fl[]=creator&rows=50&start=${(page - 1) * 50}&sort[]=downloads+desc&output=json"))
            .getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Remote>()
        for (i in 0 until d.length()) {
            val o = d.getJSONObject(i); val id = o.getString("identifier")
            out.add(Remote("ia_" + id.replace(Regex("[^A-Za-z0-9]"), "_"), o.optString("title", id), o.optString("creator", ""), "ia:$id", "?"))
        }
        return out
    }

    private fun gutenberg(q: String, lang: String, page: Int): List<Remote> {
        var u = "https://gutendex.com/books/?"
        if (q.isNotBlank()) u += "search=" + URLEncoder.encode(q.trim(), "UTF-8") + "&"
        if (lang.isNotEmpty()) u += "languages=$lang&"
        u += "page=$page"
        val res = JSONObject(get(u)).getJSONArray("results")
        val out = ArrayList<Remote>()
        for (i in 0 until res.length()) {
            val o = res.getJSONObject(i)
            val f = o.getJSONObject("formats")
            val keys = f.keys().asSequence().toList()
            val k = keys.firstOrNull { it.startsWith("application/epub+zip") }?.let { it to "epub" }
                ?: keys.firstOrNull { it.startsWith("application/x-mobipocket") }?.let { it to "mobi" }
                ?: keys.firstOrNull { it.startsWith("text/plain") }?.let { it to "txt" }
                ?: continue
            val au = o.getJSONArray("authors")
            out.add(Remote("g" + o.getInt("id"), o.getString("title"), if (au.length() > 0) au.getJSONObject(0).getString("name") else "", f.getString(k.first), k.second))
        }
        return out
    }
    private fun googleFree(q: String, page: Int): List<Remote> {
        val query = if (q.isBlank()) "subject:fiction" else q.trim()
        val u = "https://www.googleapis.com/books/v1/volumes?q=" + URLEncoder.encode(query, "UTF-8") +
            "&filter=free-ebooks&maxResults=40&startIndex=${(page - 1) * 40}&orderBy=relevance"
        val items = JSONObject(get(u)).optJSONArray("items") ?: JSONArray()
        val out = ArrayList<Remote>()
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i); val info = o.optJSONObject("volumeInfo") ?: continue
            val access = o.optJSONObject("accessInfo") ?: continue
            val epub = access.optJSONObject("epub")
            val pdf = access.optJSONObject("pdf")
            val link = epub?.optString("downloadLink").orEmpty().takeIf { it.isNotBlank() && it != "null" }
                ?: pdf?.optString("downloadLink").orEmpty().takeIf { it.isNotBlank() && it != "null" } ?: continue
            val ext = if (link.contains("pdf", true)) "pdf" else "epub"
            val authors = info.optJSONArray("authors")
            out.add(Remote("gb_" + o.optString("id"), info.optString("title", "Без названия"),
                if (authors != null && authors.length() > 0) authors.optString(0) else "", link, ext))
        }
        return out
    }

    private fun openLibrary(q: String, lang: String, page: Int): List<Remote> {
        val query = if (q.isBlank()) "*" else q.trim()
        val u = "https://openlibrary.org/search.json?q=" + URLEncoder.encode(query, "UTF-8") +
            "&ebook_access=public&fields=key,title,author_name,ia&limit=50&page=$page" +
            if (lang == "ru") "&language=rus" else if (lang == "en") "&language=eng" else ""
        val docs = JSONObject(get(u)).optJSONArray("docs") ?: JSONArray()
        val out = ArrayList<Remote>()
        for (i in 0 until docs.length()) {
            val o = docs.getJSONObject(i)
            val ids = o.optJSONArray("ia") ?: continue
            if (ids.length() == 0) continue
            val ia = ids.optString(0)
            val authors = o.optJSONArray("author_name")
            out.add(Remote("ol_" + ia.replace(Regex("[^A-Za-z0-9]"), "_"), o.optString("title", "Без названия"),
                if (authors != null && authors.length() > 0) authors.optString(0) else "", "ia:$ia", "?"))
        }
        return out
    }

    fun searchOpenSources(q: String, lang: String = "ru"): List<Remote> {
        // Query the four independent catalogs concurrently; one slow source must
        // not block the others or consume several minutes of the chat request.
        val executor = Executors.newFixedThreadPool(4)
        val tasks = listOf(
            Callable { gutenberg(q, lang, 1) },
            Callable { archive(q, 1) },
            Callable { googleFree(q, 1) },
            Callable { openLibrary(q, lang, 1) }
        )
        val out = LinkedHashMap<String, Remote>()
        try {
            val futures = executor.invokeAll(tasks, 30, TimeUnit.SECONDS)
            futures.forEach { future ->
                if (!future.isCancelled) runCatching { future.get() }.getOrNull()?.forEach {
                    out.putIfAbsent(it.id, it)
                }
            }
        } finally {
            executor.shutdownNow()
        }
        return out.values.take(40)
    }

    fun fetch(r: Remote, dir: File): File {
        dir.mkdirs()
        var url = r.url; var ext = r.ext
        if (url.startsWith("ia:")) {
            val id = url.drop(3)
            val fs = JSONObject(get("https://archive.org/metadata/$id")).optJSONArray("files") ?: JSONArray()
            val names = (0 until fs.length()).mapNotNull { i ->
                fs.optJSONObject(i)?.takeIf { !it.optBoolean("private", false) }
                    ?.optString("name")?.takeIf { !it.isNullOrBlank() && it != "null" }
            }
            val n = names.firstOrNull { it.endsWith(".epub", true) }
                ?: names.firstOrNull { it.endsWith(".fb2.zip", true) }
                ?: names.firstOrNull { it.endsWith(".fb2", true) }
                ?: names.firstOrNull { it.endsWith(".pdf", true) }
                ?: names.firstOrNull { it.endsWith("_djvu.txt", true) || it.endsWith(".txt", true) }
                ?: error("У этой записи нет открытого EPUB, FB2, PDF или TXT-файла для скачивания")
            ext = extOf(n)
            url = "https://archive.org/download/$id/" + URLEncoder.encode(n, "UTF-8").replace("+", "%20")
        }
        require(ext in SUPPORTED) { "Источник вернул неподдерживаемый формат: .$ext" }
        val safeId = r.id.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val f = File(dir, "$safeId.$ext")
        val part = File(dir, "$safeId.$ext.part")
        val c = conn(url)
        try {
            val code = c.responseCode
            if (code !in 200..299) error("Скачать книгу не удалось: HTTP $code")
            val contentType = c.contentType.orEmpty().lowercase()
            if (contentType.contains("text/html") || contentType.contains("application/json")) {
                error("Источник вместо файла книги вернул веб-страницу. Попробуй другой источник или формат.")
            }
            val expectedLength = c.contentLengthLong
            c.inputStream.buffered().use { input ->
                part.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                    }
                    output.flush()
                }
            }
            if (!part.isFile || part.length() < 128) error("Скачанный файл пустой или повреждённый")
            if (expectedLength > 0 && part.length() != expectedLength) error("Загрузка книги оборвалась: ${part.length()} из $expectedLength байт")
            // Guard against catalog endpoints that return an HTML error page as a file.
            val signature = part.inputStream().use { input -> ByteArray(8).also { input.read(it) } }
            val head = String(signature, Charsets.UTF_8).trimStart('﻿', ' ', '\n', '\r', '\t').lowercase()
            if (head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("{\"")) {
                error("Источник вернул страницу ошибки, а не файл книги")
            }
            if (ext == "pdf" && !head.startsWith("%pdf")) error("Источник вернул файл, который не похож на PDF")
            if (ext == "epub" && !(signature.size >= 2 && signature[0] == 0x50.toByte() && signature[1] == 0x4b.toByte())) {
                error("Скачанный EPUB повреждён: нет ZIP-сигнатуры")
            }
            if (f.exists()) f.delete()
            if (!part.renameTo(f)) { part.copyTo(f, overwrite = true); part.delete() }
            return f
        } catch (e: Exception) {
            part.delete()
            throw e
        } finally { c.disconnect() }
    }
}

// ---------- Парсеры ----------
private fun ent(s: String) = Regex("&(#x?[0-9a-fA-F]+|[a-z]+);").replace(s) { m ->
    val v = m.groupValues[1]
    (when {
        v.startsWith("#x") -> v.drop(2).toIntOrNull(16)?.let { String(Character.toChars(it)) }
        v.startsWith("#") -> v.drop(1).toIntOrNull()?.let { String(Character.toChars(it)) }
        else -> mapOf("amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
            "mdash" to "—", "ndash" to "–", "laquo" to "«", "raquo" to "»", "hellip" to "…")[v]
    }) ?: m.value
}

private fun decode(b: ByteArray): String {
    val s = String(b, Charsets.UTF_8)
    return if ('\uFFFD' in s) String(b, charset("windows-1251")) else s
}

fun html2paras(h: String): List<String> {
    val t = h.replace(Regex("(?is)<(script|style|head)\\b.*?</\\1>"), "")
        .replace(Regex("(?i)</(p|div|h[1-6]|li|tr)>|<br\\s*/?>"), "\n")
        .replace(Regex("<[^>]+>"), "")
    return ent(t).lines().map { it.replace(Regex("\\s+"), " ").trim() }.filter { it.isNotEmpty() }
}

private fun attr(t: String, n: String) = Regex("\\b$n=[\"']([^\"']*)[\"']").find(t)?.groupValues?.get(1)

private fun fb2(ins: InputStream): List<String> {
    val p = XmlPullParserFactory.newInstance().newPullParser(); p.setInput(ins, null)
    val out = ArrayList<String>(); val sb = StringBuilder(); var skip = 0
    fun flush() { val t = sb.toString().replace(Regex("\\s+"), " ").trim(); if (t.isNotEmpty()) out.add(t); sb.clear() }
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        when (ev) {
            XmlPullParser.START_TAG -> if (p.name == "binary" || p.name == "description") skip++
            XmlPullParser.TEXT -> if (skip == 0) sb.append(p.text)
            XmlPullParser.END_TAG -> when (p.name) {
                "binary", "description" -> skip--
                "p", "v", "subtitle", "title", "text-author", "section", "empty-line" -> if (skip == 0) flush()
            }
        }
        ev = p.next()
    }
    flush(); return out
}

private fun epub(f: File): List<String> = ZipFile(f).use { z ->
    fun rd(n: String) = z.getEntry(n)?.let { String(z.getInputStream(it).readBytes(), Charsets.UTF_8) }
    val opf = Regex("full-path=\"([^\"]+)\"").find(rd("META-INF/container.xml")!!)!!.groupValues[1]
    val dir = opf.substringBeforeLast('/', "")
    val x = rd(opf)!!
    val man = HashMap<String, String>()
    Regex("<item\\b[^>]*>").findAll(x).forEach { m ->
        val id = attr(m.value, "id"); val h = attr(m.value, "href"); if (id != null && h != null) man[id] = h
    }
    val out = ArrayList<String>()
    Regex("<itemref\\b[^>]*>").findAll(x).forEach { m ->
        val h = attr(m.value, "idref")?.let { man[it] } ?: return@forEach
        val parts = ArrayList<String>()
        URLDecoder.decode(if (dir.isEmpty()) h else "$dir/$h", "UTF-8").substringBefore('#').split('/').forEach {
            if (it == "..") parts.removeLastOrNull() else if (it != "." && it.isNotEmpty()) parts.add(it)
        }
        rd(parts.joinToString("/"))?.let { out += html2paras(it) }
    }
    out
}

private fun docx(f: File): List<String> = ZipFile(f).use { z ->
    val p = XmlPullParserFactory.newInstance().newPullParser()
    p.setInput(z.getInputStream(z.getEntry("word/document.xml")), null)
    val out = ArrayList<String>(); val sb = StringBuilder(); var inT = false
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        when (ev) {
            XmlPullParser.START_TAG -> if (p.name == "w:t") inT = true
            XmlPullParser.TEXT -> if (inT) sb.append(p.text)
            XmlPullParser.END_TAG -> if (p.name == "w:t") inT = false else if (p.name == "w:p") {
                val t = sb.toString().trim(); if (t.isNotEmpty()) out.add(t); sb.clear()
            }
        }
        ev = p.next()
    }
    out
}

private fun rtf(s: String): List<String> {
    val t = s.replace(Regex("\\\\'([0-9a-fA-F]{2})")) { String(byteArrayOf(it.groupValues[1].toInt(16).toByte()), charset("windows-1251")) }
        .replace(Regex("\\\\u(-?\\d+)\\??")) { String(Character.toChars(it.groupValues[1].toInt().let { n -> if (n < 0) n + 65536 else n })) }
        .replace(Regex("\\\\pard?\\b ?"), "\n")
        .replace(Regex("\\\\[a-zA-Z]+-?\\d* ?"), "").replace(Regex("[{}]"), "")
    return t.lines().map { it.trim() }.filter { it.isNotEmpty() }
}

private fun mobi(f: File): List<String> {
    val b = f.readBytes()
    fun u16(o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    fun u32(o: Int) = (u16(o) shl 16) or u16(o + 2)
    val n = u16(76)
    fun off(i: Int) = u32(78 + i * 8)
    val r0 = off(0)
    val comp = u16(r0)
    val count = u16(r0 + 8)
    if (comp == 17480) error("MOBI/KF8 со сжатием Huffman не поддерживается. Сконвертируйте в EPUB.")
    val utf = u32(r0 + 28) == 65001
    val flags = if (u32(r0 + 20) >= 228) u16(r0 + 242) else 0
    val out = java.io.ByteArrayOutputStream()
    for (i in 1..minOf(count, n - 1)) {
        val end = if (i + 1 < n) off(i + 1) else b.size
        val start = off(i)
        var size = end - start
        var fl = flags shr 1
        while (fl != 0) {
            if (fl and 1 == 1) {
                var v = 0; var sh = 0; var p = start + size - 1
                while (true) { val x = b[p].toInt() and 255; v = v or ((x and 127) shl sh); sh += 7; p--; if (x and 128 != 0) break }
                size -= v
            }
            fl = fl shr 1
        }
        if (flags and 1 == 1) size -= (b[start + size - 1].toInt() and 3) + 1
        if (comp == 1) { out.write(b, start, size); continue }
        var p = start; val lim = start + size
        var buf = ByteArray(size * 6 + 16); var bl = 0
        fun put(x: Int) { if (bl == buf.size) buf = buf.copyOf(bl * 2); buf[bl++] = x.toByte() }
        while (p < lim) {
            val c = b[p++].toInt() and 255
            when {
                c in 1..8 -> { for (k in 0 until c) put(b[p + k].toInt()); p += c }
                c < 128 -> put(c)
                c >= 192 -> { put(32); put(c xor 128) }
                else -> {
                    val c2 = (c shl 8) or (b[p++].toInt() and 255)
                    val d = (c2 shr 3) and 0x7FF; val l = (c2 and 7) + 3
                    for (k in 0 until l) put(buf[bl - d].toInt())
                }
            }
        }
        out.write(buf, 0, bl)
    }
    val bytes = out.toByteArray()
    return html2paras(if (utf) String(bytes, Charsets.UTF_8) else String(bytes, charset("windows-1252")))
}

object Parsers {
    fun load(f: File, ext: String): List<String> = when (ext) {
        "epub" -> epub(f)
        "fb2" -> f.inputStream().use { fb2(it) }
        "fb2zip" -> ZipFile(f).use { z -> fb2(z.getInputStream(z.entries().asSequence().first { it.name.endsWith(".fb2") })) }
        "docx" -> docx(f)
        "mobi", "azw", "prc" -> mobi(f)
        "html", "htm", "xhtml" -> html2paras(decode(f.readBytes()))
        "rtf" -> rtf(decode(f.readBytes()))
        else -> decode(f.readBytes()).lines().map { it.trim() }.filter { it.isNotEmpty() }
    }
}
