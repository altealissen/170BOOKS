#include <jni.h>
#include <android/log.h>
#include "llama.h"
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "PukichLlama", __VA_ARGS__)

static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static llama_sampler *g_sampler = nullptr;
static const llama_vocab *g_vocab = nullptr;
static int g_n_ctx = 0;
static int g_n_cur = 0;
static bool g_done = true;
static std::string g_pending;
static std::mutex g_mutex;

// Длина префикса строки, который состоит только из законченных UTF-8 символов.
static size_t utf8_complete_len(const std::string &s) {
    const size_t n = s.size();
    for (size_t back = 0; back < 4 && back < n; ++back) {
        unsigned char c = (unsigned char) s[n - 1 - back];
        if ((c & 0xC0) != 0x80) {
            size_t need = c < 0x80 ? 1 : (c & 0xE0) == 0xC0 ? 2 : (c & 0xF0) == 0xE0 ? 3 : (c & 0xF8) == 0xF0 ? 4 : 1;
            return (back + 1 >= need) ? n : n - 1 - back;
        }
    }
    return n;
}

static jbyteArray make_bytes(JNIEnv *env, const std::string &s) {
    jbyteArray a = env->NewByteArray((jsize) s.size());
    if (a && !s.empty()) env->SetByteArrayRegion(a, 0, (jsize) s.size(), reinterpret_cast<const jbyte *>(s.data()));
    return a;
}

static void free_sampler() {
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    g_done = true;
    g_pending.clear();
}

static void free_all() {
    free_sampler();
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_free_model(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_app_reader_PukichLlm_nativeLoad(JNIEnv *env, jobject, jstring path_, jint n_threads, jint n_ctx) {
    std::lock_guard<std::mutex> guard(g_mutex);
    const char *path = env->GetStringUTFChars(path_, nullptr);
    if (!path) return JNI_FALSE;
    free_all();
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(path_, path);
    if (!g_model) { LOGE("model load failed"); return JNI_FALSE; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) n_ctx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { LOGE("context init failed"); free_all(); return JNI_FALSE; }
    g_vocab = llama_model_get_vocab(g_model);
    g_n_ctx = (int) llama_n_ctx(g_ctx);
    return JNI_TRUE;
}

// 0 — ок, 1 — модель не загружена, 2 — промпт не влезает в контекст, 3 — ошибка декодирования
extern "C" JNIEXPORT jint JNICALL
Java_app_reader_PukichLlm_nativeBegin(JNIEnv *env, jobject, jbyteArray prompt_) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (!g_model || !g_ctx || !g_vocab) return 1;
    free_sampler();
    const jsize len = env->GetArrayLength(prompt_);
    if (len <= 0) return 3;
    std::string prompt((size_t) len, '\0');
    env->GetByteArrayRegion(prompt_, 0, len, reinterpret_cast<jbyte *>(&prompt[0]));

    std::vector<llama_token> tokens((size_t) g_n_ctx);
    int n = llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), tokens.data(), (int) tokens.size(), true, true);
    if (n < 0 || n >= g_n_ctx - 32) return 2;
    tokens.resize((size_t) n);

    llama_kv_cache_clear(g_ctx);
    // Промпт длиннее n_batch нельзя отдавать за один llama_decode — режем на куски.
    const int n_batch = (int) llama_n_batch(g_ctx);
    for (int i = 0; i < n; i += n_batch) {
        const int c = std::min(n_batch, n - i);
        llama_batch b = llama_batch_get_one(tokens.data() + i, c);
        if (llama_decode(g_ctx, b) != 0) return 3;
    }
    g_n_cur = n;

    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    g_sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_p(0.90f, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.65f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    g_pending.clear();
    g_done = false;
    return 0;
}

// Следующий кусок текста (UTF-8). Пустой массив — «токен был, текста пока нет». null — генерация закончена.
extern "C" JNIEXPORT jbyteArray JNICALL
Java_app_reader_PukichLlm_nativeNext(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (!g_sampler || !g_ctx) return nullptr;
    if (g_done) {
        if (g_pending.empty()) return nullptr;
        std::string out = g_pending.substr(0, utf8_complete_len(g_pending));
        g_pending.clear();
        if (out.empty()) return nullptr;
        return make_bytes(env, out);
    }
    llama_token tok = llama_sampler_sample(g_sampler, g_ctx, -1);
    llama_sampler_accept(g_sampler, tok);
    if (llama_vocab_is_eog(g_vocab, tok) || g_n_cur >= g_n_ctx - 2) {
        g_done = true;
        return make_bytes(env, std::string());
    }
    char buf[256];
    int plen = llama_token_to_piece(g_vocab, tok, buf, (int) sizeof(buf), 0, true);
    if (plen < 0) {
        std::vector<char> big((size_t) -plen);
        plen = llama_token_to_piece(g_vocab, tok, big.data(), (int) big.size(), 0, true);
        if (plen > 0) g_pending.append(big.data(), (size_t) plen);
    } else if (plen > 0) {
        g_pending.append(buf, (size_t) plen);
    }
    llama_batch b = llama_batch_get_one(&tok, 1);
    if (llama_decode(g_ctx, b) != 0) g_done = true; else g_n_cur++;
    const size_t ok = utf8_complete_len(g_pending);
    std::string out = g_pending.substr(0, ok);
    g_pending.erase(0, ok);
    return make_bytes(env, out);
}

extern "C" JNIEXPORT void JNICALL
Java_app_reader_PukichLlm_nativeFinish(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> guard(g_mutex);
    free_sampler();
}

extern "C" JNIEXPORT void JNICALL
Java_app_reader_PukichLlm_nativeClose(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> guard(g_mutex);
    free_all();
}
