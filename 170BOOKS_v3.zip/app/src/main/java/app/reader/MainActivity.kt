package app.reader

import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import android.content.Context
import android.os.SystemClock

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        Store.init(this)
        NotesStore.init(this)
        ReaderSettings.init(this)
        val tf = typeface("fonts/newspaper.ttf", "fonts/newspaper.otf", "fonts/Newspaper.ttf", "fonts/Newspaper.otf")
        if (tf != null) BookTypeface = tf
        val fam = tf?.let { FontFamily(it) } ?: FontFamily.Serif
        applyPreferredRefreshRate()
        setContent { AppTheme(fam, fam, fam) { Surface(Modifier.fillMaxSize(), color = BG) { App() } } }
    }

    override fun onStop() { Store.flush(); super.onStop() }

    fun applyPreferredRefreshRate() {
        window.attributes = window.attributes.apply { preferredRefreshRate = ReaderSettings.refreshRate.toFloat() }
    }

    private fun typeface(vararg names: String): Typeface? {
        for (n in names) {
            try { return Typeface.createFromAsset(assets, n) } catch (_: Exception) {}
        }
        return null
    }
}

// ---------- Пользовательские настройки ----------
object ReaderSettings {
    private lateinit var prefs: android.content.SharedPreferences
    var themeId by mutableIntStateOf(0)
        private set
    var accentId by mutableIntStateOf(1)
        private set
    var refreshRate by mutableIntStateOf(60)
        private set
    var eyeProtection by mutableStateOf(false)
        private set
    /** true — страницы (пейджер), false — непрерывная прокрутка */
    var pageMode by mutableStateOf(true)
        private set
    var fontSize by mutableIntStateOf(19)
        private set
    /** true — свайп вправо листает вперёд, влево — назад (как просили); false — наоборот */
    var swipeNextRight by mutableStateOf(true)
        private set
    /** разворот из двух страниц на большом экране в альбомной ориентации */
    var spread by mutableStateOf(true)
        private set
    val themes = listOf("Обсидиан", "Графит", "Полночь", "Пастельный зелёный", "Пастельная лаванда", "Айвори", "Тёплый бежевый")
    val themeBackgrounds = listOf(
        Color(0xFF050505), Color(0xFF111318), Color(0xFF090D1B),
        Color(0xFFE8F0E7), Color(0xFFEDE8F5), Color(0xFFF7F3E9), Color(0xFFEDE1D1)
    )
    val themeForegrounds = listOf(
        Color(0xFFF4F0E9), Color(0xFFEDEFF4), Color(0xFFF0F0FA),
        Color(0xFF34463A), Color(0xFF443B55), Color(0xFF51483B), Color(0xFF514237)
    )
    val themeSurfaces = listOf(
        Color(0xFF151515), Color(0xFF20232A), Color(0xFF171B2B),
        Color(0xFFF4F7F0), Color(0xFFF6F2FA), Color(0xFFFFFCF4), Color(0xFFF5EBDD)
    )
    val themeAccents = listOf(
        Color(0xFF54D6C8), Color(0xFF8BA7C8), Color(0xFF9B8CFF),
        Color(0xFF78977A), Color(0xFF9886B8), Color(0xFFB49A70), Color(0xFFAA8667)
    )
    val accents = listOf(Color(0xFF54D6C8), Color(0xFFFF5A6E), Color(0xFF9B8CFF), Color(0xFFFFB454), Color(0xFF79A8FF), Color(0xFFE58BC5))
    val accentNames = listOf("Мята", "Коралл", "Лаванда", "Янтарь", "Сапфир", "Розовый")

    fun init(context: android.content.Context) {
        prefs = context.getSharedPreferences("reader_settings", 0)
        themeId = prefs.getInt("theme", 0).coerceIn(themes.indices)
        accentId = prefs.getInt("accent", 1).coerceIn(accents.indices)
        refreshRate = prefs.getInt("refresh", 60).let { if (it in listOf(60, 90, 120, 144)) it else 60 }
        eyeProtection = prefs.getBoolean("eye", false)
        pageMode = prefs.getBoolean("pages_v3", true)
        fontSize = prefs.getInt("font", 19).coerceIn(12, 36)
        swipeNextRight = prefs.getBoolean("swipe_right_next", true)
        spread = prefs.getBoolean("spread", true)
        applyColors()
    }
    private fun applyColors() {
        BG = themeBackgrounds[themeId]
        ACCENT = if (themeId >= 3) themeAccents[themeId] else accents[accentId]
        FG = themeForegrounds[themeId]
        PANEL = themeSurfaces[themeId]
        MUTED = FG.copy(alpha = 0.62f)
        BORDER = FG.copy(alpha = if (themeId >= 3) 0.13f else 0.16f)
    }
    fun setTheme(id: Int) { themeId = id.coerceIn(themes.indices); prefs.edit().putInt("theme", themeId).apply(); applyColors() }
    fun setAccent(id: Int) { accentId = id.coerceIn(accents.indices); prefs.edit().putInt("accent", accentId).apply(); applyColors() }
    fun setRefresh(rate: Int) { refreshRate = rate; prefs.edit().putInt("refresh", rate).apply() }
    fun updateEyeProtection(enabled: Boolean) { eyeProtection = enabled; prefs.edit().putBoolean("eye", enabled).apply() }
    fun updatePageMode(enabled: Boolean) { pageMode = enabled; prefs.edit().putBoolean("pages_v3", enabled).apply() }
    fun setFontSize(v: Int) { fontSize = v.coerceIn(12, 36); prefs.edit().putInt("font", fontSize).apply() }
    fun updateSwipeNextRight(v: Boolean) { swipeNextRight = v; prefs.edit().putBoolean("swipe_right_next", v).apply() }
    fun updateSpread(v: Boolean) { spread = v; prefs.edit().putBoolean("spread", v).apply() }
}

// ---------- Палитра и шрифты ----------
var ACCENT by mutableStateOf(Color(0xFFFF5A6E))
var BG by mutableStateOf(Color(0xFF050505))
var FG by mutableStateOf(Color(0xFFF4F0E9))
var PANEL by mutableStateOf(Color(0xFF151515))
var MUTED by mutableStateOf(Color(0xFFAAA69F))
var BORDER by mutableStateOf(Color.White.copy(alpha = 0.16f))
val Line get() = BORDER
val SUN = listOf(Color(0xFFE5456F), Color(0xFFFFA95C), Color(0xFFE5456F))
val PALETTE = listOf(Color(0xFFF3D9BC), Color(0xFFFF8068), Color(0xFF8E8CE0), Color(0xFFD9647F),
    Color(0xFF45D2BA), Color(0xFFEA8A2C), Color(0xFF5273FF), Color(0xFFB556D6))
fun tint(s: String) = PALETTE[(s.hashCode() and 0x7fffffff) % PALETTE.size]

val LocalMono = staticCompositionLocalOf<FontFamily> { FontFamily.Monospace }
val LocalBookFont = staticCompositionLocalOf<FontFamily> { FontFamily.Serif }

@Composable
fun mono(size: Int = 12, alpha: Float = 1f, spacing: Float = 0.8f) =
    TextStyle(fontFamily = LocalMono.current, fontSize = size.sp, letterSpacing = spacing.sp, color = FG.copy(alpha = alpha))

@Composable
fun AppTheme(book: FontFamily, ui: FontFamily, mono: FontFamily, content: @Composable () -> Unit) {
    val cs = if (ReaderSettings.themeId >= 3) lightColorScheme(
        primary = ACCENT, onPrimary = Color.White, background = BG, surface = PANEL,
        onBackground = FG, onSurface = FG, surfaceVariant = PANEL,
        onSurfaceVariant = MUTED, secondaryContainer = ACCENT.copy(alpha = 0.16f), onSecondaryContainer = FG
    ) else darkColorScheme(
        primary = ACCENT, onPrimary = Color.White, background = BG, surface = PANEL,
        onBackground = FG, onSurface = FG, surfaceVariant = PANEL,
        onSurfaceVariant = MUTED, secondaryContainer = ACCENT.copy(alpha = 0.18f), onSecondaryContainer = FG
    )
    val t = Typography()
    val light = FontWeight.Light
    val typo = t.copy(
        displayLarge = t.displayLarge.copy(fontFamily = ui, fontWeight = light),
        displayMedium = t.displayMedium.copy(fontFamily = ui, fontWeight = light),
        displaySmall = t.displaySmall.copy(fontFamily = ui, fontWeight = light, letterSpacing = (-0.5).sp),
        headlineLarge = t.headlineLarge.copy(fontFamily = ui, fontWeight = light),
        headlineMedium = t.headlineMedium.copy(fontFamily = ui, fontWeight = light),
        headlineSmall = t.headlineSmall.copy(fontFamily = ui, fontWeight = light),
        titleLarge = t.titleLarge.copy(fontFamily = ui, fontWeight = light),
        titleMedium = t.titleMedium.copy(fontFamily = mono),
        titleSmall = t.titleSmall.copy(fontFamily = mono),
        bodyLarge = t.bodyLarge.copy(fontFamily = ui),
        bodyMedium = t.bodyMedium.copy(fontFamily = ui),
        bodySmall = t.bodySmall.copy(fontFamily = ui),
        labelLarge = t.labelLarge.copy(fontFamily = mono),
        labelMedium = t.labelMedium.copy(fontFamily = mono),
        labelSmall = t.labelSmall.copy(fontFamily = mono)
    )
    val view = LocalView.current
    val lightTheme = ReaderSettings.themeId >= 3
    SideEffect {
        (view.context as? android.app.Activity)?.window?.let { w ->
            val c = androidx.core.view.WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = lightTheme
            c.isAppearanceLightNavigationBars = lightTheme
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(BG.toArgb()))
        }
    }
    CompositionLocalProvider(LocalMono provides mono, LocalBookFont provides book) {
        MaterialTheme(colorScheme = cs, typography = typo, content = content)
    }
}

// ---------- Тонкие линейные иконки ----------
val IconCol get() = FG.copy(alpha = 0.82f)

fun DrawScope.icInfo() {
    drawCircle(IconCol)
    val cx = size.width / 2
    drawLine(BG, Offset(cx, size.height * 0.27f), Offset(cx, size.height * 0.57f), size.width * 0.13f, StrokeCap.Round)
    drawCircle(BG, size.width * 0.075f, Offset(cx, size.height * 0.74f))
}

fun DrawScope.icPlus() {
    val w = 2.2.dp.toPx(); val m = size.width * 0.1f
    drawLine(IconCol, Offset(m, size.height / 2), Offset(size.width - m, size.height / 2), w, StrokeCap.Round)
    drawLine(IconCol, Offset(size.width / 2, m), Offset(size.width / 2, size.height - m), w, StrokeCap.Round)
}

fun DrawScope.icBack() {
    val w = 2.2.dp.toPx()
    drawLine(IconCol, Offset(size.width * 0.66f, size.height * 0.1f), Offset(size.width * 0.28f, size.height * 0.5f), w, StrokeCap.Round)
    drawLine(IconCol, Offset(size.width * 0.28f, size.height * 0.5f), Offset(size.width * 0.66f, size.height * 0.9f), w, StrokeCap.Round)
}

fun DrawScope.icDots(c: Color) {
    val r = size.width * 0.1f
    for (x in listOf(0.3f, 0.7f)) for (y in listOf(0.3f, 0.7f)) drawCircle(c, r, Offset(size.width * x, size.height * y))
}

@Composable
fun IconBtn(onClick: () -> Unit, draw: DrawScope.() -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.size(22.dp), onDraw = draw)
    }
}

// ---------- Кнопки, заголовок ----------
@Composable
fun Pill(t: String, sel: Boolean, c: Color, onClick: () -> Unit) {
    val m = if (sel) Modifier.background(Brush.horizontalGradient(listOf(ACCENT, ACCENT.copy(alpha = 0.78f))))
    else Modifier.background(PANEL).border(1.dp, Brush.horizontalGradient(listOf(c, c.copy(alpha = 0.3f))), CircleShape)
    Box(Modifier.clip(CircleShape).then(m).clickable(onClick = onClick), Alignment.Center) {
        Text(t.uppercase(), Modifier.padding(horizontal = 16.dp, vertical = 10.dp), style = mono(12, if (sel) 1f else 0.8f))
    }
}

@Composable
fun GhostBtn(text: String, enabled: Boolean, c: Color, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).border(1.dp, if (enabled) c.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.14f), CircleShape)
        .clickable(enabled = enabled, onClick = onClick)) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), style = mono(11, if (enabled) 1f else 0.4f))
    }
}

@Composable
fun Header(title: String, left: @Composable () -> Unit = { Spacer(Modifier.size(40.dp)) }, right: @Composable () -> Unit = { Spacer(Modifier.size(40.dp)) }) {
    val compact = LocalConfiguration.current.screenHeightDp < 480
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = if (compact) 2.dp else 10.dp, bottom = if (compact) 4.dp else 16.dp), verticalAlignment = Alignment.CenterVertically) {
        left()
        Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, maxLines = 1,
            style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.displaySmall)
        right()
    }
}

// ---------- Светящиеся плитки ----------
fun DrawScope.drawLit(c: Color, e: Float, r: Float) {
    drawRect(Brush.verticalGradient(
        0f to c, 0.25f * e to c.copy(alpha = 0.95f), e to c.copy(alpha = 0.32f), (e + (1f - e) * 0.65f) to Color.Transparent))
    drawRect(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
        center = Offset(size.width * 0.5f, 0f), radius = size.width * 0.9f))
    val cr = CornerRadius(r, r)
    for (i in 1..6) drawRoundRect(c.copy(alpha = 0.09f), cornerRadius = cr, style = Stroke(width = i * 6f * density))
    drawRoundRect(c.copy(alpha = 0.4f), cornerRadius = cr, style = Stroke(width = density))
}

fun DrawScope.drawOff(r: Float) {
    drawRect(Brush.verticalGradient(0f to Color(0xFF0A0A0A), 0.35f to Color(0xFF121212), 1f to Color(0xFF6E6E6E)))
    val cr = CornerRadius(r, r)
    for (i in 1..4) drawRoundRect(Color.White.copy(alpha = 0.05f), cornerRadius = cr, style = Stroke(width = i * 6f * density))
    drawRoundRect(Color.White.copy(alpha = 0.16f), cornerRadius = cr, style = Stroke(width = density))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Tile(title: String, sub: String, tag: String, c: Color, lit: Boolean, modifier: Modifier, onClick: () -> Unit, onMenu: () -> Unit) {
    val sh = RoundedCornerShape(30.dp)
    val e = 0.5f + ((title.hashCode() and 0x7fffffff) % 22) / 100f
    Box(modifier.clip(sh).background(BG)
        .drawBehind { if (lit) drawLit(c, e, 30.dp.toPx()) else drawOff(30.dp.toPx()) }
        .combinedClickable(onClick = onClick, onLongClick = onMenu)) {
        val dim = if (lit) Color.Black.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.4f)
        Text(tag, Modifier.align(Alignment.TopStart).padding(start = 20.dp, top = 20.dp), style = mono(10).copy(color = dim))
        Box(Modifier.align(Alignment.TopEnd).size(48.dp).clickable(onClick = onMenu), Alignment.Center) {
            Canvas(Modifier.size(16.dp)) { icDots(dim) }
        }
        Column(Modifier.align(if (lit) Alignment.BottomCenter else Alignment.Center).padding(horizontal = 16.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title.uppercase(), textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
                style = mono(13, 0.95f).copy(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset.Zero, 10f)))
            if (sub.isNotEmpty()) Text(sub.uppercase(), Modifier.padding(top = 4.dp), textAlign = TextAlign.Center, maxLines = 1,
                overflow = TextOverflow.Ellipsis, style = mono(10, 0.5f))
        }
    }
}

@Composable
fun ResultRow(title: String, sub: String, c: Color, end: @Composable () -> Unit) {
    val sh = RoundedCornerShape(26.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(PANEL)
        .drawBehind {
            drawRect(Brush.radialGradient(listOf(c.copy(alpha = 0.30f), Color.Transparent),
                center = Offset(0f, size.height / 2), radius = size.width * 0.7f))
        }
        .border(1.dp, Brush.horizontalGradient(listOf(c.copy(alpha = 0.85f), c.copy(alpha = 0.2f))), sh)
        .padding(start = 20.dp, end = 14.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title.uppercase(), style = mono(12, 0.95f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub.uppercase(), Modifier.padding(top = 4.dp), style = mono(10, 0.5f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(10.dp))
        end()
    }
}

// Панель с градиентом и сеткой точек (пустое состояние)
@Composable
fun EmptyPanel(modifier: Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(32.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF6B84FF), Color(0xFFEC4E80), Color(0xFFFFA03A))))) {
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(0f to Color.Transparent, 0.5f to Color.Transparent, 0.95f to BG)))
        Canvas(Modifier.matchParentSize()) {
            val cols = 6; val rows = 8
            for (r in 0 until rows) for (k in 0 until cols) {
                val x = (k + 0.5f) * size.width / cols
                val y = (r + 0.5f) * size.height * 0.8f / rows
                drawCircle(Color.White.copy(alpha = 0.6f * (1f - r / rows.toFloat() * 0.7f)), 2.dp.toPx(), Offset(x, y))
            }
            drawCircle(Color.White, 6.dp.toPx(), Offset(size.width * 3.5f / cols, size.height * 0.8f * 1.5f / rows))
            drawCircle(Color.White, 8.dp.toPx(), Offset(size.width * 1.5f / cols, size.height * 0.8f * 4.5f / rows), style = Stroke(width = 2.dp.toPx()))
        }
        content()
    }
}

/** Копирует файл в хранилище приложения (вызывать на IO). Бросает исключение с понятным текстом. */
fun importUri(ctx: android.content.Context, uri: Uri): Book {
    var name = "book"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) name = c.getString(i)
    }
    val ext = extOf(name)
    if (ext !in SUPPORTED) throw IllegalArgumentException("Формат не поддерживается: .$ext")
    val id = UUID.randomUUID().toString()
    val f = File(ctx.filesDir, "books/$id.$ext"); f.parentFile?.mkdirs()
    val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Не удалось открыть файл")
    input.use { i -> f.outputStream().use { i.copyTo(it, 256 * 1024) } }
    val title = name.removeSuffix(".zip").substringBeforeLast('.')
    return Book(id, title, "", f.path, ext)
}

/** Высота, которую занимает плавающая нижняя навигация (экраны с полем ввода поднимаются над ней). */
val LocalBottomBar = compositionLocalOf { 0.dp }

@Composable
fun SideRail(tabs: List<String>, tab: Int, onTab: (Int) -> Unit) {
    Column(Modifier.fillMaxHeight().width(104.dp).statusBarsPadding().navigationBarsPadding().padding(start = 10.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        tabs.forEachIndexed { i, t ->
            val sel = i == tab
            val sh = RoundedCornerShape(16.dp)
            Box(Modifier.fillMaxWidth().clip(sh)
                .then(if (sel) Modifier.background(Brush.horizontalGradient(listOf(ACCENT, ACCENT.copy(alpha = 0.78f)))) else Modifier.border(1.dp, Line, sh))
                .clickable { onTab(i) }.padding(vertical = 14.dp), Alignment.Center) {
                Text(t.uppercase(), style = mono(9, if (sel) 1f else 0.75f), color = if (sel) Color.White else FG, textAlign = TextAlign.Center, maxLines = 1)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun App() {
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) AppScope.launch {
            val app = ctx.applicationContext
            var ok = 0
            for (u in uris) {
                try { val bk = withContext(Dispatchers.IO) { importUri(app, u) }; Store.add(bk); ok++ }
                catch (e: Exception) { Toast.makeText(app, e.message ?: "Не удалось добавить файл", Toast.LENGTH_LONG).show() }
            }
            if (ok > 0) Toast.makeText(app, if (ok == 1) "Книга добавлена" else "Добавлено книг: $ok", Toast.LENGTH_SHORT).show()
        }
    }
    val opened = openId?.let { id -> Store.books.firstOrNull { it.id == id } }
    if (opened != null) {
        BackHandler { openId = null }
        Reader(opened) { openId = null }
        return
    }
    val tabs = listOf("Библиотека", "Полка", "Каталог", "Заметки", "Пукич", "Настройки")
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 720.dp
        val imeUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0
        val bottomBar = if (!wide && !imeUp) 60.dp else 0.dp
        CompositionLocalProvider(LocalBottomBar provides bottomBar) {
            Row(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal))) {
                if (wide) SideRail(tabs, tab) { tab = it }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth().widthIn(max = 1200.dp)) {
                            when (tab) {
                                0 -> LibraryScreen({ openId = it.id }, { picker.launch(arrayOf("*/*")) })
                                1 -> ReadingStatsScreen()
                                2 -> CatalogScreen()
                                3 -> NotesScreen()
                                4 -> PukichScreen()
                                else -> SettingsScreen()
                            }
                        }
                    }
                    if (!wide && !imeUp) Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)) {
                        Row(Modifier.clip(CircleShape).background(PANEL.copy(alpha = 0.96f)).border(1.dp, Line, CircleShape).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                            tabs.forEachIndexed { i, t ->
                                val sel = i == tab
                                Box(Modifier.clip(CircleShape).then(if (sel) Modifier.background(Brush.horizontalGradient(listOf(ACCENT, ACCENT.copy(alpha = 0.78f)))) else Modifier).clickable { tab = i }) {
                                    Text(t.uppercase(), Modifier.padding(horizontal = 7.dp, vertical = 13.dp), style = mono(9, if (sel) 1f else 0.72f), color = if (sel) Color.White else FG)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, style = mono(12))
            Text(sub, Modifier.padding(top = 5.dp), style = mono(9, 0.5f))
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val activity = ctx as? MainActivity
    val rates = listOf(60, 90, 120, 144)
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Header("Настройки")
        LazyColumn(Modifier.widthIn(max = 760.dp).fillMaxWidth(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            item { PukichModelSettings() }
            item {
                Text("ЧТЕНИЕ", style = mono(11, 0.65f), color = MUTED)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingRow("РЕЖИМ СТРАНИЦ", "Одна страница на экране, листание только свайпом или стрелками ‹ › сверху. Выключи — будет прокрутка.", ReaderSettings.pageMode) { ReaderSettings.updatePageMode(it) }
                    SettingRow("СВАЙП ВПРАВО — ВПЕРЁД", "Вправо — следующая страница, влево — назад. Выключи, чтобы было наоборот.", ReaderSettings.swipeNextRight) { ReaderSettings.updateSwipeNextRight(it) }
                    SettingRow("РАЗВОРОТ НА БОЛЬШОМ ЭКРАНЕ", "Две страницы рядом на планшете в альбомной ориентации.", ReaderSettings.spread) { ReaderSettings.updateSpread(it) }
                    SettingRow("ЗАЩИТА ГЛАЗ", "Тёплая бумажная палитра в режиме чтения", ReaderSettings.eyeProtection) { ReaderSettings.updateEyeProtection(it) }
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("РАЗМЕР ШРИФТА", Modifier.weight(1f), style = mono(12))
                        Text("A−", Modifier.clip(CircleShape).clickable { ReaderSettings.setFontSize(ReaderSettings.fontSize - 1) }.padding(horizontal = 16.dp, vertical = 8.dp), style = mono(15))
                        Text("${ReaderSettings.fontSize}", style = mono(12, 0.7f))
                        Text("A+", Modifier.clip(CircleShape).clickable { ReaderSettings.setFontSize(ReaderSettings.fontSize + 1) }.padding(horizontal = 16.dp, vertical = 8.dp), style = mono(15))
                    }
                }
            }
            item {
                Text("ТЕМА ОФОРМЛЕНИЯ", style = mono(11, 0.65f), color = MUTED)
                Spacer(Modifier.height(10.dp))
                ReaderSettings.themes.forEachIndexed { i, name ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (ReaderSettings.themeId == i) ACCENT.copy(alpha = 0.13f) else Color.Transparent)
                        .clickable { ReaderSettings.setTheme(i) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(ReaderSettings.themeBackgrounds[i]).border(1.dp, ReaderSettings.themeForegrounds[i].copy(alpha = 0.25f), CircleShape))
                        Text(name, Modifier.weight(1f).padding(start = 12.dp), style = mono(12), color = FG)
                        if (ReaderSettings.themeId == i) Text("ВЫБРАНА", color = ACCENT, style = mono(9))
                    }
                }
            }
            item {
                Text("ЦВЕТ АКЦЕНТА", style = mono(11, 0.55f))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ReaderSettings.accents.forEachIndexed { i, color ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { ReaderSettings.setAccent(i) }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(34.dp).clip(CircleShape).background(color).then(if (ReaderSettings.accentId == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier))
                            Text(ReaderSettings.accentNames[i], Modifier.padding(top = 6.dp), style = mono(8, if (ReaderSettings.accentId == i) 1f else 0.5f), maxLines = 1)
                        }
                    }
                }
            }
            item {
                Text("ЧАСТОТА ОБНОВЛЕНИЯ ЭКРАНА", style = mono(11, 0.55f))
                Text("Предпочтительная частота дисплея", Modifier.padding(top = 6.dp, bottom = 12.dp), style = mono(10, 0.45f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rates.forEach { hz ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (ReaderSettings.refreshRate == hz) ACCENT.copy(alpha = 0.22f) else PANEL)
                            .border(1.dp, if (ReaderSettings.refreshRate == hz) ACCENT else Line, RoundedCornerShape(14.dp))
                            .clickable { ReaderSettings.setRefresh(hz); activity?.applyPreferredRefreshRate() }.padding(vertical = 15.dp), Alignment.Center) {
                            Text("${hz} Гц", style = mono(10, if (ReaderSettings.refreshRate == hz) 1f else 0.65f), color = if (ReaderSettings.refreshRate == hz) ACCENT else FG)
                        }
                    }
                }
                Text("Фактическая частота зависит от возможностей экрана и системных настроек Android.", Modifier.padding(top = 12.dp), style = mono(9, 0.4f))
            }
        }
    }
}

@Composable
fun PukichModelSettings() {
    val ctx = LocalContext.current
    val tick = ModelDownloader.tick
    val st = ModelDownloader.state
    var selected by remember { mutableStateOf(PukichLlm.selectedId(ctx)) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val running = st?.running == true

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(PANEL)
        .border(1.dp, ACCENT.copy(alpha = 0.35f), RoundedCornerShape(22.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🤖", fontSize = 27.sp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("МОЗГ ПУКИЧА", style = mono(11, 0.9f), color = FG)
                Text("Локальная нейросеть без интернета (llama.cpp). Скачивание идёт в фоне, обрыв не страшен — докачается с того же места, при проблемах с Hugging Face автоматически берётся зеркало.",
                    Modifier.padding(top = 4.dp), style = mono(9, 0.55f), color = MUTED)
            }
        }
        Models.all.forEach { spec ->
            val installed = remember(tick, spec.id) { PukichLlm.installed(ctx, spec) }
            val mine = st != null && st.modelId == spec.id
            val part = if (mine && st != null) st.done else ModelDownloader.partBytes(ctx, spec)
            val sel = selected == spec.id
            val sh = RoundedCornerShape(16.dp)
            Column(Modifier.fillMaxWidth().clip(sh).border(1.dp, if (sel) ACCENT else Line, sh)
                .clickable { selected = spec.id; PukichLlm.select(ctx, spec.id); ModelDownloader.markChanged() }.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(spec.title.uppercase(), Modifier.weight(1f), style = mono(11), color = if (sel) ACCENT else FG)
                    Text(if (installed) "● УСТАНОВЛЕНА" else if (part > 0) "◐ ${part / 1048576} МБ" else "○", style = mono(9), color = if (installed) Color(0xFF65C99A) else MUTED)
                }
                Text(spec.note, Modifier.padding(top = 4.dp), style = mono(9, 0.55f), color = MUTED)
                if (mine && st != null) {
                    if (st.running || st.done in 1 until st.total) {
                        val frac = if (st.total > 0) (st.done.toFloat() / st.total).coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(progress = frac, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), color = ACCENT)
                        val speed = if (st.bytesPerSec > 0) " · %.1f МБ/с".format(st.bytesPerSec / 1048576f) else ""
                        Text("${(frac * 100).toInt()}% · ${st.done / 1048576} из ${if (st.total > 0) st.total / 1048576 else spec.approxBytes / 1048576} МБ$speed", Modifier.padding(top = 5.dp), style = mono(9), color = MUTED)
                    }
                    Text(st.message, Modifier.padding(top = 4.dp), style = mono(9, 0.6f), color = MUTED)
                    st.error?.let { Text(it, Modifier.padding(top = 4.dp), style = mono(9), color = ACCENT) }
                }
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (installed) {
                        GhostBtn("УДАЛИТЬ", !running, ACCENT) { PukichLlm.remove(ctx, spec); if (mine) ModelDownloader.clearState() }
                    } else if (mine && running) {
                        GhostBtn("ПАУЗА", true, ACCENT) { ModelDownloader.pause() }
                        GhostBtn("ОТМЕНА", true, MUTED) { ModelDownloader.cancelAndDelete(ctx, spec) }
                    } else {
                        GhostBtn(if (part > 0) "ПРОДОЛЖИТЬ" else "СКАЧАТЬ", !running, ACCENT) {
                            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                                ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                                notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            selected = spec.id; PukichLlm.select(ctx, spec.id)
                            ModelDownloader.start(ctx, spec)
                        }
                        if (part > 0 && !running) GhostBtn("СБРОСИТЬ", true, MUTED) { ModelDownloader.cancelAndDelete(ctx, spec) }
                    }
                }
            }
        }
    }
}

class Msg(val user: Boolean, val text: String)

object Chat {
    val messages = mutableStateListOf<Msg>()
    val results = mutableStateListOf<Remote>()
    var generating by mutableStateOf(false)
    var searching by mutableStateOf(false)
    var mood by mutableStateOf("hello")
    var error by mutableStateOf<String?>(null)
    var status by mutableStateOf("")

    private const val SYSTEM = "Ты Пукич — дружелюбный и умный книжный помощник приложения 170BOOKS. Отвечай по-русски, коротко и по делу (2–5 предложений), поддерживай контекст беседы. Помогай выбирать книги: уточняй жанр, настроение, объём. Не выдумывай книги, авторов и ссылки — поиск по каталогам делает приложение отдельно. Если пользователь благодарит — ответь тепло."
    private val thanksRe = Regex("спасибо|благодар", RegexOption.IGNORE_CASE)
    private val intentRe = Regex("книг|почита|прочита|роман|детектив|фэнтези|фентези|фантаст|автор|найди|найти|посоветуй|порекомендуй|скача|повест|рассказ|поэм|стих|классик|сборник|триллер|мистик|ужас|приключен|сказк|биограф|мемуар|пьес|драм", RegexOption.IGNORE_CASE)
    private val stopRe = Regex("(?<![\\p{L}\\p{N}])(хочу|хочется|мне|найди|найти|посоветуй|порекомендуй|подскажи|пожалуйста|почитать|почитай|скачать|книгу|книги|книг|книжку|что-нибудь|что|нибудь|интересное|интересную|какую-нибудь|про|о|об|для|на|по|в|и|или|а|с|от|из|есть|ли|можно|можешь|ты|мой|моя|мою|какой|какую|любую)(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)

    fun clear() { PukichLlm.cancel(); messages.clear(); results.clear(); error = null; status = ""; mood = "hello"; generating = false; searching = false }
    fun stop() { PukichLlm.cancel() }

    private fun buildPrompt(history: List<Msg>): String {
        val parts = ArrayList<String>()
        var budget = 6000
        for (m in history.asReversed()) {
            if (m.text.isBlank()) continue
            val piece = "<|im_start|>${if (m.user) "user" else "assistant"}\n${m.text}<|im_end|>\n"
            if (budget - piece.length < 0 && parts.isNotEmpty()) break
            budget -= piece.length; parts.add(piece)
        }
        return "<|im_start|>system\n$SYSTEM<|im_end|>\n" + parts.asReversed().joinToString("") + "<|im_start|>assistant\n"
    }

    fun send(ctx: Context, userText: String) {
        val text = userText.trim()
        if (text.isEmpty() || generating) return
        val app = ctx.applicationContext
        val thanks = thanksRe.containsMatchIn(text)
        messages.add(Msg(true, text))
        error = null; status = ""; generating = true
        mood = if (thanks) "thanks" else "thinking"
        AppScope.launch {
            try {
                if (PukichLlm.activeSpec(app) != null) {
                    val prompt = buildPrompt(messages.toList())
                    messages.add(Msg(false, ""))
                    val idx = messages.lastIndex
                    var shown = 0L
                    val answer = withContext(Dispatchers.IO) {
                        PukichLlm.generate(app, prompt, 420) { acc ->
                            val now = SystemClock.uptimeMillis()
                            if (now - shown > 80) { shown = now; messages[idx] = Msg(false, acc) }
                        }
                    }
                    messages[idx] = Msg(false, answer.ifBlank { "Я задумался, начальник. Попробуй спросить немного иначе." })
                } else {
                    messages.add(Msg(false, if (thanks) "Всегда пожалуйста, начальник! Хорошие книги должны находить своих читателей 🙂"
                        else "Я тебя понял! Чтобы я мог нормально болтать, скачай модель в «Настройках». А пока могу искать книги в открытых каталогах — скажи, что хочется почитать."))
                }
                if (intentRe.containsMatchIn(text)) {
                    searching = true
                    val q = stopRe.replace(text, " ").replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim().ifBlank { text }.take(120)
                    val found = Net.searchOpenSources(q, "ru")
                    results.clear(); results.addAll(found)
                    if (found.isNotEmpty()) mood = "found"
                    else status = "В открытых каталогах не нашёл совпадений. Попробуй уточнить автора или название."
                }
                if (thanks) mood = "thanks"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Не получилось: ${e.message ?: "неизвестная ошибка"}"
                if (messages.lastOrNull()?.let { !it.user && it.text.isBlank() } == true) messages.removeAt(messages.lastIndex)
                mood = "hello"
            } finally {
                generating = false; searching = false
            }
        }
    }
}

@Composable
fun PukichScreen() {
    val ctx = LocalContext.current
    val tick = ModelDownloader.tick
    val spec = remember(tick) { PukichLlm.activeSpec(ctx) }
    var prompt by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val screenH = LocalConfiguration.current.screenHeightDp
    val imageH = if (screenH < 480) 90.dp else if (screenH < 700) 140.dp else 190.dp
    LaunchedEffect(spec?.id) { if (spec != null) withContext(Dispatchers.IO) { PukichLlm.preload(ctx) } }
    LaunchedEffect(Chat.messages.size) {
        val n = listState.layoutInfo.totalItemsCount
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.fillMaxHeight().widthIn(max = 760.dp).fillMaxWidth()) {
            Header("Пукич", right = {
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { Chat.clear() }, Alignment.Center) { Text("↺", color = FG, style = MaterialTheme.typography.titleLarge) }
            })
            LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(26.dp)).padding(14.dp)) {
                        val imageRes = when (Chat.mood) {
                            "thinking" -> R.drawable.pukich_thinking
                            "found" -> R.drawable.pukich_found
                            "thanks" -> R.drawable.pukich_thanks
                            else -> R.drawable.pukich_hello
                        }
                        Image(painterResource(imageRes), contentDescription = "Пукич", modifier = Modifier.fillMaxWidth().height(imageH), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                        Text("ПУКИЧ · КНИЖНЫЙ ПОМОЩНИК", style = mono(11), color = ACCENT)
                        Text(when (Chat.mood) {
                            "thinking" -> "Так, дай-ка подумать…"
                            "found" -> "О! Кажется, нашёл кое-что интересное!"
                            "thanks" -> "Да брось, начальник! Всегда рад помочь ☕"
                            else -> "Здорово! Давай подберём тебе хорошую книгу."
                        }, Modifier.padding(top = 6.dp), style = MaterialTheme.typography.titleMedium, color = FG)
                        Text(if (spec != null) "${spec.title} · локальный диалог · поиск по открытым каталогам" else "Модель не установлена · доступен поиск по открытым каталогам",
                            Modifier.padding(top = 4.dp), style = mono(8, 0.52f), color = MUTED)
                    }
                }
                if (Chat.messages.isEmpty()) item {
                    Text("Можешь просто поговорить со мной или попросить: «найди детектив про Лондон», «хочу Достоевского».", style = mono(10, 0.65f), color = MUTED)
                }
                items(Chat.messages.size) { index ->
                    val m = Chat.messages[index]
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 520.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.user) ACCENT.copy(alpha = 0.16f) else PANEL)
                            .border(1.dp, if (m.user) ACCENT.copy(alpha = 0.3f) else Line, RoundedCornerShape(18.dp)).padding(12.dp)) {
                            Text(if (m.user) "ТЫ" else "ПУКИЧ", style = mono(8, 0.6f), color = ACCENT)
                            Text(m.text.ifEmpty { "…" }, Modifier.padding(top = 5.dp), style = mono(11), color = FG)
                        }
                    }
                }
                if (Chat.searching) item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(17.dp), color = ACCENT, strokeWidth = 2.dp)
                        Text("Ищу в каталогах…", Modifier.padding(start = 9.dp), style = mono(9, 0.6f), color = MUTED)
                    }
                }
                Chat.error?.let { msg -> item { Text(msg, style = mono(10), color = ACCENT) } }
                if (Chat.status.isNotBlank()) item { Text(Chat.status, style = mono(9, 0.65f), color = MUTED) }
                if (Chat.results.isNotEmpty()) item { Text("НАЙДЕНО В ОТКРЫТЫХ ИСТОЧНИКАХ · ${Chat.results.size}", style = mono(10, 0.7f), color = ACCENT) }
                items(Chat.results.toList(), key = { it.id }) { r ->
                    val have = Store.books.any { it.id == r.id }
                    val p = BookDownloads.progress[r.id]
                    ResultRow(r.title, r.author.ifEmpty { "Открытый доступ · ${r.ext.uppercase()}" }, tint(r.id)) {
                        GhostBtn(if (have) "ЕСТЬ" else if (p != null) (if (p < 0f) "…" else "${(p * 100).toInt()}%") else "ЗАБРАТЬ", !have && p == null, tint(r.id)) { BookDownloads.start(ctx, r) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp + LocalBottomBar.current), verticalAlignment = Alignment.Bottom) {
                TextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp), minLines = 1, maxLines = 4,
                    placeholder = { Text("Напиши Пукичу…", style = mono(10, 0.45f)) },
                    textStyle = mono(11),
                    colors = TextFieldDefaults.colors(focusedContainerColor = PANEL, unfocusedContainerColor = PANEL,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = FG, unfocusedTextColor = FG, cursorColor = ACCENT))
                Spacer(Modifier.width(8.dp))
                if (Chat.generating) GhostBtn("■", true, ACCENT) { Chat.stop() }
                else GhostBtn("➤", prompt.isNotBlank(), ACCENT) { Chat.send(ctx, prompt); prompt = "" }
            }
        }
    }
}

fun bookStatus(b: Book): String = when (b.status) {
    "PLANNED" -> "В ПЛАНАХ"
    "READING" -> "В ПРОЦЕССЕ"
    "DONE" -> "ЗАВЕРШЕНО"
    else -> when {
        b.id in Store.completed -> "ЗАВЕРШЕНО"
        b.pos > 0 -> "В ПРОЦЕССЕ"
        else -> "НЕ НАЧАТО"
    }
}

@Composable
fun StatusLabel(status: String) {
    val color = when (status) {
        "ЗАВЕРШЕНО" -> Color(0xFF65C99A)
        "В ПРОЦЕССЕ" -> ACCENT
        "В ПЛАНАХ" -> Color(0xFF9B8CFF)
        else -> MUTED
    }
    Text(status, Modifier.clip(CircleShape).background(color.copy(alpha = 0.13f))
        .border(1.dp, color.copy(alpha = 0.35f), CircleShape).padding(horizontal = 8.dp, vertical = 4.dp),
        color = color, style = mono(8))
}

@Composable
fun StatusPicker(book: Book) {
    var expanded by remember(book.id) { mutableStateOf(false) }
    Box {
        Box(Modifier.clickable { expanded = true }) { StatusLabel(bookStatus(book)) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false },
            modifier = Modifier.background(PANEL)) {
            listOf("" to "Автоматически", "PLANNED" to "В планах", "READING" to "В процессе", "DONE" to "Завершено").forEach { (value, label) ->
                DropdownMenuItem(text = { Text(label, style = mono(11)) }, onClick = {
                    Store.setStatus(book.id, value); expanded = false
                })
            }
        }
    }
}

@Composable
fun LibraryScreen(onOpen: (Book) -> Unit, onAdd: () -> Unit) {
    var del by remember { mutableStateOf<Book?>(null) }
    var info by remember { mutableStateOf(false) }
    val books = Store.books.toList()
    val reading = books.count { it.pos > 0 || it.poff > 0 }
    val compact = LocalConfiguration.current.screenHeightDp < 480
    Column(Modifier.fillMaxSize()) {
        Header("Библиотека", left = { IconBtn({ info = true }) { icInfo() } }, right = { IconBtn(onAdd) { icPlus() } })
        if (books.isEmpty()) {
            EmptyPanel(Modifier.padding(horizontal = 16.dp).widthIn(max = 480.dp).fillMaxWidth().height(if (compact) 200.dp else 380.dp)) {
                Column(Modifier.align(Alignment.BottomCenter).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ПОКА ПУСТО", style = mono(13))
                    Text("НАЖМИТЕ + ИЛИ СКАЧАЙТЕ КНИГИ В КАТАЛОГЕ", Modifier.padding(top = 6.dp), textAlign = TextAlign.Center, style = mono(10, 0.5f))
                }
            }
        } else BoxWithConstraints(Modifier.fillMaxSize()) {
            val cols = (maxWidth / 170.dp).toInt().coerceIn(2, 8)
            LazyVerticalGrid(GridCells.Fixed(cols), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                gridItemsIndexed(books, key = { _, b -> b.id }, span = { i, _ -> if (cols == 2 && i % 5 == 4) GridItemSpan(maxLineSpan) else GridItemSpan(1) }) { i, b ->
                    val wide = cols == 2 && i % 5 == 4
                    Tile(b.title, "${b.author} · ${bookStatus(b)}", b.ext.uppercase(), tint(b.id), b.pos > 0 || b.poff > 0,
                        Modifier.fillMaxWidth().aspectRatio(if (wide) 1.75f else 0.8f), { onOpen(b) }, { del = b })
                }
            }
        }
    }
    if (info) AlertDialog(onDismissRequest = { info = false }, containerColor = PANEL, shape = RoundedCornerShape(28.dp),
        title = { Text("БИБЛИОТЕКА", style = mono(13)) },
        text = { Text("КНИГ: ${books.size}\nЧИТАЮ: $reading\nНОВЫХ: ${books.size - reading}", style = mono(13, 0.8f)) },
        confirmButton = { TextButton({ info = false }) { Text("OK", color = ACCENT) } })
    del?.let { b ->
        AlertDialog(onDismissRequest = { del = null }, containerColor = PANEL, shape = RoundedCornerShape(28.dp),
            title = { Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = mono(13)) },
            text = { Text("Удалить книгу из библиотеки?", style = mono(12, 0.7f)) },
            confirmButton = { TextButton({ Store.remove(b); del = null }) { Text("УДАЛИТЬ", color = ACCENT) } },
            dismissButton = { TextButton({ del = null }) { Text("ОТМЕНА", color = FG.copy(alpha = 0.7f)) } })
    }
}


@Composable
fun ReadingStatsScreen() {
    val books = Store.books.toList()
    val done = books.filter { it.id in Store.completed }
    val events = Store.events.toList()
    val now = System.currentTimeMillis()
    val day = 24L * 60 * 60 * 1000
    val recent = events.filter { it.time >= now - 7 * day }
    val maxOpens = recent.count { it.pages == 0 }.coerceAtLeast(1)
    val hours = remember(events.size) {
        val arr = IntArray(24)
        val cal = java.util.Calendar.getInstance()
        events.forEach { if (it.pages == 0) { cal.timeInMillis = it.time; arr[cal.get(java.util.Calendar.HOUR_OF_DAY)]++ } }
        arr
    }
    val maxHour = (hours.maxOrNull() ?: 1).coerceAtLeast(1)
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Header("Моя полка")
        LazyColumn(Modifier.widthIn(max = 760.dp).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Text("КНИЖНАЯ ПОЛКА · ${books.size} КНИГ", style = mono(11, 0.55f))
                Spacer(Modifier.height(12.dp))
                if (books.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(22.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(22.dp)), Alignment.Center) {
                        Text("ДОБАВЬТЕ КНИГУ В БИБЛИОТЕКУ\nОНА ПОЯВИТСЯ НА ПОЛКЕ", textAlign = TextAlign.Center, style = mono(11, 0.45f))
                    }
                } else {
                    LazyRow(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF17120F)).padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                        items(books, key = { it.id }) { b ->
                            Column(Modifier.width(48.dp).fillMaxHeight(), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                                    .background(Brush.verticalGradient(listOf(tint(b.id), tint(b.id).copy(alpha = 0.45f))))
                                    .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)), Alignment.Center) {
                                    Text(b.title.take(12).uppercase(), modifier = Modifier.padding(3.dp), style = mono(8, 0.9f), textAlign = TextAlign.Center, maxLines = 4)
                                }
                                Spacer(Modifier.height(4.dp))
                                Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0xFF80614A)))
                            }
                        }
                    }
                }
            }
            item {
                Text("СТАТУС КНИГ", style = mono(11, 0.55f))
                Spacer(Modifier.height(8.dp))
                books.forEach { b ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(PANEL).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(width = 5.dp, height = 38.dp).clip(RoundedCornerShape(4.dp)).background(tint(b.id)))
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(b.title, style = mono(10), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(b.author.ifBlank { b.ext.uppercase() }, style = mono(8, 0.45f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        StatusPicker(b)
                    }
                }
            }
            item {
                Text("АЧИВКИ", style = mono(11, 0.55f))
                Spacer(Modifier.height(10.dp))
                val night = remember(events.size) {
                    val cal = java.util.Calendar.getInstance()
                    events.any { cal.timeInMillis = it.time; cal.get(java.util.Calendar.HOUR_OF_DAY) in 2..4 }
                }
                val marathon = events.filter { it.time >= now - day }.sumOf { it.pages } >= 100
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Achievement("🌙", "НОЧНОЙ ДОЗОР", night, "Чтение 02:00–04:59")
                    Achievement("⚡", "МАРАФОНЕЦ", marathon, "100 страниц за день")
                    Achievement("📚", "КОЛЛЕКЦИОНЕР", done.size >= 5, "5 завершённых книг")
                }
            }
            item {
                Text("ОТКРЫТИЯ КНИГ · 7 ДНЕЙ", style = mono(11, 0.55f))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(7) { d ->
                        val from = now - (6 - d) * day
                        val count = recent.count { it.time in (from - day + 1)..from && it.pages == 0 }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(7.dp))
                                .background(ACCENT.copy(alpha = (0.12f + 0.88f * count / maxOpens.toFloat()).coerceIn(0.12f, 1f))))
                            Text(listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС")[((java.util.Calendar.getInstance().apply { timeInMillis = from }.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7)],
                                Modifier.padding(top = 5.dp), style = mono(8, 0.5f))
                        }
                    }
                }
                Text("СКОЛЬКО РАЗ ОТКРЫВАЛИ · ПО ЧАСАМ", Modifier.padding(top = 18.dp), style = mono(10, 0.55f))
                Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                    hours.forEachIndexed { i, n ->
                        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height((8 + 62f * n / maxHour).dp).clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                .background(PALETTE[i % PALETTE.size].copy(alpha = if (n == 0) 0.16f else 0.9f)))
                        }
                    }
                }
                Text("00      06      12      18      23", Modifier.fillMaxWidth(), style = mono(8, 0.35f))
            }
            item {
                Text("СТАТИСТИКА", style = mono(11, 0.55f))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("СТРАНИЦ СЕГОДНЯ", Store.dailyPages().toString(), Modifier.weight(1f))
                    StatCard("В СРЕДНЕМ ЗА СЕАНС", Store.averageSessionPages().toString(), Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun RowScope.Achievement(emoji: String, name: String, unlocked: Boolean, desc: String) {
    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (unlocked) Color(0xFF282018) else PANEL)
        .border(1.dp, if (unlocked) Color(0xFFFFB45F).copy(alpha = 0.6f) else Line, RoundedCornerShape(16.dp)).padding(9.dp)) {
        Text(if (unlocked) emoji else "🔒", style = MaterialTheme.typography.titleMedium)
        Text(name, Modifier.padding(top = 6.dp), style = mono(8, if (unlocked) 1f else 0.35f), maxLines = 2)
        Text(desc, Modifier.padding(top = 4.dp), style = mono(7, 0.4f), maxLines = 2)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(PANEL).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(14.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium, color = ACCENT)
        Text(label, Modifier.padding(top = 4.dp), style = mono(8, 0.5f))
    }
}

@Composable
fun CatalogScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by rememberSaveable { mutableStateOf("") }
    var lang by rememberSaveable { mutableStateOf("") }
    var src by rememberSaveable { mutableIntStateOf(0) }
    var res by remember { mutableStateOf(listOf<Remote>()) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var page by remember { mutableIntStateOf(1) }
    var hasMore by remember { mutableStateOf(true) }
    val ticket = remember { intArrayOf(0) }

    fun go(reset: Boolean) {
        if (!reset && loading) return
        val my = ++ticket[0]
        if (reset) { page = 1; res = emptyList(); hasMore = true }
        loading = true; err = null
        scope.launch {
            try {
                val next = if (reset) 1 else page + 1
                val found = withContext(Dispatchers.IO) { Net.search(q, lang, src, next) }
                if (my != ticket[0]) return@launch
                res = if (reset) found else (res + found).distinctBy { it.id }
                page = next
                hasMore = found.isNotEmpty()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (my == ticket[0]) err = Http.friendly(e)
            } finally {
                if (my == ticket[0]) loading = false
            }
        }
    }
    LaunchedEffect(lang, src) { go(true) }

    LazyVerticalGrid(GridCells.Adaptive(minSize = 340.dp), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 120.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Header("Каталог")
                val fsh = RoundedCornerShape(28.dp)
                TextField(q, { q = it }, Modifier.fillMaxWidth().border(1.dp, Line, fsh), singleLine = true, shape = fsh,
                    textStyle = mono(14),
                    placeholder = { Text("НАЗВАНИЕ ИЛИ АВТОР", style = mono(13, 0.4f)) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = FG, unfocusedTextColor = FG, cursorColor = ACCENT),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { go(true) }))
                LazyRow(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(Net.sourceNames.size) { i -> Pill(Net.sourceNames[i], src == i, PALETTE[(i * 2) % PALETTE.size]) { src = i } }
                }
                if (Net.hasLang(src)) Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("" to "Все", "ru" to "Русский", "en" to "English").forEachIndexed { i, (c, n) ->
                        Pill(n, lang == c, PALETTE[4 + i]) { lang = c }
                    }
                }
                Text(Net.sourceHints[src], Modifier.padding(top = 8.dp), style = mono(9, 0.42f))
                Spacer(Modifier.height(10.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = ACCENT, trackColor = FG.copy(alpha = 0.08f))
                err?.let {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(it, Modifier.weight(1f), color = ACCENT, style = mono(11))
                        GhostBtn("ПОВТОРИТЬ", !loading, ACCENT) { go(true) }
                    }
                }
            }
        }
        gridItems(res, key = { it.id }) { r ->
            val have = Store.books.any { it.id == r.id }
            val p = BookDownloads.progress[r.id]
            val c = tint(r.id)
            ResultRow(r.title, r.author.ifEmpty { if (r.ext == "?") "EPUB / FB2 / PDF" else r.ext.uppercase() }, c) {
                GhostBtn(if (have) "ЕСТЬ" else if (p != null) (if (p < 0f) "…" else "${(p * 100).toInt()}%") else "СКАЧАТЬ", !have && p == null, c) { BookDownloads.start(ctx, r) }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            if (hasMore && res.isNotEmpty()) {
                Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), Alignment.Center) {
                    GhostBtn(if (loading) "ЗАГРУЗКА…" else "ПОКАЗАТЬ ЕЩЁ", !loading, ACCENT) { go(false) }
                }
            } else if (res.isEmpty() && !loading && err == null) {
                Text("Ничего не найдено. Попробуйте другой запрос или источник.", Modifier.fillMaxWidth().padding(20.dp), textAlign = TextAlign.Center, style = mono(11, .5f))
            }
        }
    }
}

data class ReaderEntry(val book: String, val body: String, val kind: String, val time: Long, val context: String = "")

object NotesStore {
    private lateinit var prefs: android.content.SharedPreferences
    val entries = mutableStateListOf<ReaderEntry>()
    fun init(context: android.content.Context) {
        prefs = context.getSharedPreferences("reader_notes", 0)
        val a = org.json.JSONArray(prefs.getString("entries", "[]"))
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); entries.add(ReaderEntry(o.optString("book"), o.optString("body"), o.optString("kind"), o.optLong("time"), o.optString("context"))) }
    }
    fun add(e: ReaderEntry) { entries.add(0, e); save() }
    fun remove(index: Int) { if (index in entries.indices) { entries.removeAt(index); save() } }
    private fun save() { val a = org.json.JSONArray(); entries.forEach { a.put(org.json.JSONObject().put("book",it.book).put("body",it.body).put("kind",it.kind).put("time",it.time).put("context",it.context)) }; prefs.edit().putString("entries", a.toString()).apply() }
}

@Composable
fun EntryDialog(title: String, hint: String, initial: String = "", onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var body by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = PANEL, title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { OutlinedTextField(body, { body = it }, placeholder = { Text(hint) }, minLines = 4, maxLines = 9) },
        confirmButton = { TextButton(onClick = { if (body.isNotBlank()) onSave(body.trim()) }) { Text("СОХРАНИТЬ", color = ACCENT) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ОТМЕНА", color = Color.White.copy(alpha=.55f)) } })
}

@Composable
fun NotesScreen() {
    val entries = NotesStore.entries.toList()
    var delIdx by remember { mutableStateOf(-1) }
    Column(Modifier.fillMaxSize()) {
        Header("Заметки")
        if (entries.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("ТВОИ ЦИТАТЫ И МЫСЛИ\nБУДУТ ЖИТЬ ЗДЕСЬ", textAlign = TextAlign.Center, style = mono(12, .45f)) }
        else LazyVerticalGrid(GridCells.Adaptive(minSize = 320.dp), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            gridItemsIndexed(entries) { idx, e ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(PANEL, ACCENT.copy(alpha = 0.10f)))).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(17.dp)) {
                    Text(e.kind.uppercase(), color = ACCENT, style = mono(9))
                    Text(e.body, Modifier.padding(top = 10.dp), style = MaterialTheme.typography.bodyLarge)
                    Text(e.book + if (e.context.isNotBlank()) " · ${e.context}" else "", Modifier.padding(top = 12.dp), color = MUTED, style = mono(9))
                    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        if (e.kind == "Цитата") {
                            val ctx = LocalContext.current
                            Text("ПОДЕЛИТЬСЯ ↗", Modifier.clickable {
                                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, "❝ ${e.body} ❞\n— ${e.book}\n170BOOKS")
                                }
                                ctx.startActivity(android.content.Intent.createChooser(send, "Поделиться цитатой"))
                            }, color = ACCENT, style = mono(9))
                        }
                        Text("УДАЛИТЬ", Modifier.clickable { delIdx = idx }, color = MUTED, style = mono(9))
                    }
                }
            }
        }
    }
    if (delIdx >= 0) AlertDialog(onDismissRequest = { delIdx = -1 }, containerColor = PANEL, shape = RoundedCornerShape(28.dp),
        title = { Text("УДАЛИТЬ ЗАПИСЬ?", style = mono(13)) },
        confirmButton = { TextButton({ NotesStore.remove(delIdx); delIdx = -1 }) { Text("УДАЛИТЬ", color = ACCENT) } },
        dismissButton = { TextButton({ delIdx = -1 }) { Text("ОТМЕНА", color = FG.copy(alpha = 0.7f)) } })
}
