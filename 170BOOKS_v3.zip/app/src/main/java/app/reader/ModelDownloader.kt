package app.reader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

data class ModelSpec(
    val id: String,
    val title: String,
    val file: String,
    val approxBytes: Long,
    val note: String,
    val urls: List<String>
)

object Models {
    private const val Q05 = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private const val Q15 = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
    val all = listOf(
        ModelSpec(
            "q05", "Qwen2.5 · 0.5B", Q05, 491_400_032L,
            "Быстрая и лёгкая (≈490 МБ). Русский понимает попроще.",
            listOf(
                "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/$Q05",
                "https://hf-mirror.com/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/$Q05"
            )
        ),
        ModelSpec(
            "q15", "Qwen2.5 · 1.5B", Q15, 1_120_000_000L,
            "Заметно умнее и лучше по-русски (≈1.1 ГБ). Для Pixel 8 подходит.",
            listOf(
                "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/$Q15",
                "https://hf-mirror.com/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/$Q15"
            )
        )
    )
    fun byId(id: String) = all.firstOrNull { it.id == id }
}

class DlState(
    val modelId: String,
    val done: Long,
    val total: Long,
    val bytesPerSec: Long,
    val message: String,
    val running: Boolean,
    val error: String? = null
)

/**
 * Скачивание GGUF: живёт в собственном scope (не умирает при смене экрана), работает в foreground-сервисе,
 * докачивает .part по Range, переключается между зеркалами и повторяет попытки при обрыве связи.
 */
object ModelDownloader {
    var state by mutableStateOf<DlState?>(null)
        private set
    /** Увеличивается, когда набор установленных моделей изменился — UI перечитывает installed(). */
    var tick by mutableIntStateOf(0)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    fun running() = job?.isActive == true
    fun partBytes(ctx: Context, spec: ModelSpec): Long = File(ctx.filesDir, spec.file + ".part").takeIf { it.isFile }?.length() ?: 0L

    fun start(ctx: Context, spec: ModelSpec) {
        if (running()) return
        val app = ctx.applicationContext
        state = DlState(spec.id, partBytes(app, spec), 0, 0, "Подключаюсь…", true)
        try { ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java)) } catch (_: Exception) { }
        job = scope.launch {
            try {
                download(app, spec)
                tick++
                state = DlState(spec.id, 1, 1, 0, "Готово. Модель проверена и установлена.", false)
            } catch (e: CancellationException) {
                state = DlState(spec.id, partBytes(app, spec), state?.total ?: 0, 0, "Пауза. Нажми «Продолжить» — докачаю с того же места.", false)
            } catch (e: Exception) {
                state = DlState(spec.id, partBytes(app, spec), state?.total ?: 0, 0, "Не удалось скачать", false, friendly(e))
            } finally {
                try { app.stopService(Intent(app, DownloadService::class.java)) } catch (_: Exception) { }
                DownloadNotif.cancel(app)
            }
        }
    }

    fun pause() { job?.cancel() }

    fun cancelAndDelete(ctx: Context, spec: ModelSpec) {
        job?.cancel()
        File(ctx.filesDir, spec.file + ".part").delete()
        state = null
    }

    fun clearState() { if (!running()) state = null }

    fun markChanged() { tick++ }

    private fun friendly(e: Throwable): String = when (e) {
        is java.net.UnknownHostException -> "Нет интернета или сервер недоступен. Проверь сеть/VPN — докачка сохранится."
        is java.net.SocketTimeoutException -> "Сервер долго не отвечает. Нажми «Продолжить» — файл докачается."
        else -> (e.message ?: e.javaClass.simpleName) + ". Нажми «Продолжить» — файл докачается."
    }

    private suspend fun download(ctx: Context, spec: ModelSpec) {
        val target = File(ctx.filesDir, spec.file)
        val part = File(ctx.filesDir, spec.file + ".part")
        var urlIdx = 0
        var attempt = 0
        var failsWithoutProgress = 0
        var total = 0L
        var lastErr: Exception? = null

        while (attempt < 60) {
            ensureActive()
            val have = if (part.isFile) part.length() else 0L
            val url = spec.urls[urlIdx % spec.urls.size]
            val host = url.substringAfter("://").substringBefore('/')
            try {
                state = DlState(spec.id, have, total, 0, if (attempt == 0) "Подключаюсь к $host…" else "Повторная попытка ${attempt + 1} · $host", true)
                val c = Http.open(url, range = if (have > 0) "bytes=$have-" else null, connectMs = 15000, readMs = 30000)
                val code = c.responseCode
                if (code == 416 && have > 0) {
                    // Сервер говорит, что диапазон за пределами файла: .part уже полный либо битый.
                    c.disconnect()
                    if (finalize(part, target, total)) return
                    part.delete(); continue
                }
                if (code != 200 && code != 206) { c.disconnect(); throw IOException("Сервер ответил HTTP $code") }
                val resumed = code == 206 && have > 0
                if (!resumed && have > 0) part.delete()
                val base = if (resumed) have else 0L
                total = totalFrom(c.getHeaderField("Content-Range"), c.contentLengthLong, base)
                var written = base
                var lastUi = 0L; var lastBytes = base; var lastT = SystemClock.elapsedRealtime(); var speed = 0L

                c.inputStream.use { input ->
                    RandomAccessFile(part, "rw").use { raf ->
                        raf.seek(base)
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            raf.write(buf, 0, n)
                            written += n
                            val now = SystemClock.elapsedRealtime()
                            if (now - lastUi >= 300) {
                                val dt = now - lastT
                                if (dt >= 900) { speed = (written - lastBytes) * 1000 / dt; lastBytes = written; lastT = now }
                                lastUi = now
                                state = DlState(spec.id, written, total, speed, "Скачиваю с $host", true)
                                DownloadNotif.progress(ctx, spec.title, written, total)
                            }
                        }
                        raf.channel.force(false)
                    }
                }
                c.disconnect()
                if (total > 0 && written < total) throw IOException("Соединение оборвалось на ${written / 1048576} МБ")
                if (finalize(part, target, total)) return
                part.delete()
                throw IOException("Файл повреждён (не GGUF) — скачаю заново")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastErr = e
                attempt++
                val nowHave = if (part.isFile) part.length() else 0L
                if (nowHave > have) failsWithoutProgress = 0 else failsWithoutProgress++
                // Два подряд обрыва без единого нового байта — пробуем следующее зеркало.
                if (failsWithoutProgress >= 2) { urlIdx++; failsWithoutProgress = 0 }
                state = DlState(spec.id, nowHave, total, 0, "Связь прервалась: ${e.message ?: "ошибка"}. Пробую снова…", true)
                delay(minOf(1500L * attempt, 8000L))
            }
        }
        throw lastErr ?: IOException("Не удалось скачать модель")
    }

    private fun totalFrom(contentRange: String?, contentLength: Long, base: Long): Long {
        val fromRange = contentRange?.substringAfter('/', "")?.trim()?.toLongOrNull()
        if (fromRange != null && fromRange > 0) return fromRange
        return if (contentLength > 0) base + contentLength else 0L
    }

    private fun finalize(part: File, target: File, total: Long): Boolean {
        if (!part.isFile || part.length() < 10_000_000L) return false
        if (total > 0 && part.length() != total) return false
        val magic = ByteArray(4)
        val ok = part.inputStream().use { it.read(magic) == 4 } && String(magic, Charsets.ISO_8859_1) == "GGUF"
        if (!ok) return false
        PukichLlm.close()
        target.delete()
        if (!part.renameTo(target)) { part.copyTo(target, overwrite = true); part.delete() }
        return true
    }
}

object DownloadNotif {
    const val ID = 4170
    private const val CH = "model_download"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(NotificationChannel(CH, "Загрузка модели", NotificationManager.IMPORTANCE_LOW))
    }

    fun build(ctx: Context, text: String, done: Long, total: Long): Notification {
        val b = Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("170BOOKS · модель Пукича")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
        if (total > 0) b.setProgress(100, (done * 100 / total).toInt().coerceIn(0, 100), false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private var lastNotify = 0L
    fun progress(ctx: Context, name: String, done: Long, total: Long) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNotify < 1000) return
        lastNotify = now
        try {
            val txt = if (total > 0) "$name · ${done / 1048576} из ${total / 1048576} МБ" else "$name · ${done / 1048576} МБ"
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID, build(ctx, txt, done, total))
        } catch (_: Exception) { }
    }

    fun cancel(ctx: Context) {
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID) } catch (_: Exception) { }
    }
}

class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DownloadNotif.ensureChannel(this)
        val n = DownloadNotif.build(this, "Подготовка…", 0, 0)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(DownloadNotif.ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(DownloadNotif.ID, n)
        } catch (_: Exception) { }
        return START_NOT_STICKY
    }
}
