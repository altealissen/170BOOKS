package app.reader

import android.content.Context
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.runtime.mutableStateMapOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.zip.ZipFile

/** Глобальный scope приложения: загрузки и чат не должны умирать при смене вкладки. */
val AppScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

object Http {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36 170BOOKS/3.0"

    /** Android 9+ запрещает cleartext http, а HttpURLConnection не ходит по редиректам http→https сам. */
    fun secure(u: String) = if (u.startsWith("http://", true)) "https://" + u.substring(7) else u

    /** Открывает соединение и вручную проходит редиректы (до 8), всегда по https. Код ответа уже получен. */
    fun open(url0: String, range: String? = null, connectMs: Int = 15000, readMs: Int = 30000): HttpURLConnection {
        var url = secure(url0)
        for (hop in 0 until 8) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Encoding", "identity")
            c.setRequestProperty("Accept", "*/*")
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location")
                if (loc.isNullOrBlank()) return c
                val next = URL(URL(url), loc).toString()
                c.disconnect()
                url = secure(next)
                continue
            }
            return c
        }
        throw IOException("Слишком много перенаправлений")
    }

    fun getText(url: String, readMs: Int = 25000, retries: Int = 2): String {
        var last: Exception? = null
        for (i in 0..retries) {
            try {
                val c = open(url, connectMs = 12000, readMs = readMs)
                val code = c.responseCode
                if (code == 200) return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                c.disconnect()
                last = IOException("HTTP $code")
                if (code != 429 && code < 500) break
            } catch (e: IOException) { last = e }
            try { Thread.sleep(700L * (i + 1)) } catch (_: InterruptedException) { }
        }
        throw last ?: IOException("Нет ответа")
    }

    fun friendly(e: Throwable): String = when (e) {
        is java.net.UnknownHostException -> "Нет интернета или источник недоступен"
        is java.net.SocketTimeoutException -> "Источник слишком долго отвечает"
        else -> e.message ?: e.javaClass.simpleName
    }
}

object Net {
    val sourceNames = listOf("Gutenberg", "Archive · RU", "Google · Free", "Open Library", "Викитека · RU")
    val sourceHints = listOf(
        "Общественное достояние · Project Gutenberg (EPUB / MOBI / TXT)",
        "Русские тексты Internet Archive без ограничений доступа",
        "Только бесплатные электронные книги Google Books",
        "Открытый доступ · Open Library / Internet Archive",
        "Русская Викитека: тексты общественного достояния (нужен запрос)"
    )
    /** Источники, у которых работает фильтр языка. */
    fun hasLang(src: Int) = src == 0 || src == 2 || src == 3

    private val netScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun search(q: String, lang: String, src: Int = 0, page: Int = 1): List<Remote> = when (src) {
        0 -> gutenberg(q, lang, page)
        1 -> archive(q, page)
        2 -> googleFree(q, lang, page)
        3 -> openLibrary(q, lang, page)
        else -> wikisource(q, page)
    }

    // ---------- Project Gutenberg: gutendex, при сбое — OPDS самого gutenberg.org ----------
    private fun gutenberg(q: String, lang: String, page: Int): List<Remote> {
        try { return gutendex(q, lang, page) } catch (e: Exception) {
            try { return gutenbergOpds(q, page) } catch (_: Exception) { throw e }
        }
    }

    private fun gutendex(q: String, lang: String, page: Int): List<Remote> {
        var u = "https://gutendex.com/books/?"
        if (q.isNotBlank()) u += "search=" + enc(q.trim()) + "&"
        if (lang.isNotEmpty()) u += "languages=$lang&"
        u += "page=$page"
        val res = JSONObject(Http.getText(u, readMs = 20000, retries = 1)).optJSONArray("results") ?: JSONArray()
        val out = ArrayList<Remote>()
        for (i in 0 until res.length()) {
            val o = res.getJSONObject(i)
            val f = o.getJSONObject("formats")
            val keys = f.keys().asSequence().toList()
            val k = keys.firstOrNull { it.startsWith("application/epub+zip") }?.let { it to "epub" }
                ?: keys.firstOrNull { it.startsWith("application/x-mobipocket") }?.let { it to "mobi" }
                ?: keys.firstOrNull { it.startsWith("text/plain") }?.let { it to "txt" }
                ?: continue
            val au = o.optJSONArray("authors")
            out.add(Remote("g" + o.getInt("id"), o.getString("title"),
                if (au != null && au.length() > 0) au.getJSONObject(0).optString("name") else "", f.getString(k.first), k.second))
        }
        return out
    }

    private fun gutenbergOpds(q: String, page: Int): List<Remote> {
        val start = (page - 1) * 25 + 1
        val u = "https://www.gutenberg.org/ebooks/search.opds/?" +
            (if (q.isBlank()) "sort_order=downloads" else "query=" + enc(q.trim())) + "&start_index=$start"
        val xml = Http.getText(u, readMs = 20000, retries = 1)
        val out = ArrayList<Remote>()
        Regex("(?s)<entry>(.*?)</entry>").findAll(xml).forEach { m ->
            val e = m.groupValues[1]
            val id = Regex("/ebooks/(\\d+)").find(e)?.groupValues?.get(1) ?: return@forEach
            val title = Regex("(?s)<title>(.*?)</title>").find(e)?.groupValues?.get(1)?.let { ent(it).trim() } ?: return@forEach
            val author = Regex("(?s)<content[^>]*>(.*?)</content>").find(e)?.groupValues?.get(1)?.let { ent(it).trim() }.orEmpty()
            out.add(Remote("g$id", title, author, "https://www.gutenberg.org/ebooks/$id.epub3.images", "epub"))
        }
        return out
    }

    // ---------- Internet Archive ----------
    private fun archive(q: String, page: Int): List<Remote> {
        val t = q.trim().replace(Regex("[\\\\\"():\\[\\]{}^~*?!/]"), " ").replace(Regex("\\s+"), " ").trim()
        // Раньше здесь были licenseurl:*creativecommons* — ведущие wildcard в advancedsearch не работают и давали 0 результатов.
        val query = (if (t.isEmpty()) "" else "($t) AND ") +
            "mediatype:texts AND language:(rus OR russian OR ru) AND -access-restricted-item:true AND -collection:(inlibrary OR printdisabled)"
        val u = "https://archive.org/advancedsearch.php?q=" + enc(query) +
            "&fl[]=identifier&fl[]=title&fl[]=creator&rows=50&page=$page&sort[]=downloads+desc&output=json"
        val d = JSONObject(Http.getText(u)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Remote>()
        for (i in 0 until d.length()) {
            val o = d.getJSONObject(i); val id = o.getString("identifier")
            val title = o.optJSONArray("title")?.optString(0) ?: o.optString("title", id)
            val creator = o.optJSONArray("creator")?.optString(0) ?: o.optString("creator", "")
            out.add(Remote("ia_" + id.replace(Regex("[^A-Za-z0-9]"), "_"), title.ifBlank { id }, creator, "ia:$id", "?"))
        }
        return out
    }

    // ---------- Google Books (только free-ebooks) ----------
    private fun googleFree(q: String, lang: String, page: Int): List<Remote> {
        val query = if (q.isBlank()) "subject:fiction" else q.trim()
        val u = "https://www.googleapis.com/books/v1/volumes?q=" + enc(query) +
            "&filter=free-ebooks&maxResults=40&startIndex=${(page - 1) * 40}&orderBy=relevance" +
            (if (lang.isNotEmpty()) "&langRestrict=$lang" else "")
        val items = JSONObject(Http.getText(u)).optJSONArray("items") ?: JSONArray()
        val out = ArrayList<Remote>()
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i); val info = o.optJSONObject("volumeInfo") ?: continue
            val access = o.optJSONObject("accessInfo") ?: continue
            fun link(k: String) = access.optJSONObject(k)?.optString("downloadLink").orEmpty().takeIf { it.isNotBlank() && it != "null" }
            val epub = link("epub"); val pdf = link("pdf")
            val url = epub ?: pdf ?: continue
            val authors = info.optJSONArray("authors")
            out.add(Remote("gb_" + o.optString("id"), info.optString("title", "Без названия"),
                if (authors != null && authors.length() > 0) authors.optString(0) else "", Http.secure(url), if (epub != null) "epub" else "pdf"))
        }
        return out
    }

    // ---------- Open Library ----------
    private fun openLibrary(q: String, lang: String, page: Int): List<Remote> {
        val query = if (q.isBlank()) "*" else q.trim()
        val u = "https://openlibrary.org/search.json?q=" + enc(query) +
            "&ebook_access=public&has_fulltext=true&fields=key,title,author_name,ia&limit=50&page=$page" +
            (if (lang == "ru") "&language=rus" else if (lang == "en") "&language=eng" else "")
        val docs = JSONObject(Http.getText(u)).optJSONArray("docs") ?: JSONArray()
        val out = ArrayList<Remote>()
        for (i in 0 until docs.length()) {
            val o = docs.getJSONObject(i)
            val ids = o.optJSONArray("ia") ?: continue
            if (ids.length() == 0) continue
            val ia = ids.optString(0)
            val authors = o.optJSONArray("author_name")
            out.add(Remote("ol_" + ia.replace(Regex("[^A-Za-z0-9]"), "_"), o.optString("title", "Без названия"),
                if (authors != null && authors.length() > 0) authors.optString(0) else "", "ia:$ia", "?"))
        }
        return out
    }

    // ---------- Русская Викитека: поиск + экспорт в EPUB через ws-export ----------
    private fun wikisource(q: String, page: Int): List<Remote> {
        if (q.isBlank()) throw IOException("Введи название или автора — Викитека ищет только по запросу")
        val u = "https://ru.wikisource.org/w/api.php?action=query&list=search&srnamespace=0&srlimit=40&sroffset=${(page - 1) * 40}" +
            "&format=json&utf8=1&srsearch=" + enc(q.trim())
        val arr = JSONObject(Http.getText(u)).optJSONObject("query")?.optJSONArray("search") ?: JSONArray()
        val out = ArrayList<Remote>()
        for (i in 0 until arr.length()) {
            val title = arr.getJSONObject(i).optString("title")
            if (title.isBlank() || title.contains('/')) continue   // подстраницы (главы) пропускаем — берём произведение целиком
            out.add(Remote("ws_" + (title.hashCode().toLong() and 0xffffffffL), title, "Викитека", "ws:$title", "epub"))
        }
        return out
    }

    /** Поиск сразу по всем каталогам параллельно: ждём не дольше 16 с, что успело — то и показываем. */
    suspend fun searchOpenSources(q: String, lang: String = "ru"): List<Remote> {
        val box = CopyOnWriteArrayList<Pair<Int, List<Remote>>>()
        val srcs = (0..4).filter { it != 4 || q.isNotBlank() }
        val jobs = srcs.map { s ->
            netScope.async {
                runCatching { search(q, if (s == 1 || s == 4) "ru" else lang, s, 1) }.getOrNull()?.let { box.add(s to it) }
            }
        }
        withTimeoutOrNull(16000) { jobs.forEach { it.join() } }
        jobs.forEach { it.cancel() }
        val out = LinkedHashMap<String, Remote>()
        box.sortedBy { it.first }.forEach { (_, l) -> l.forEach { out.putIfAbsent(it.id, it) } }
        return out.values.take(30).toList()
    }

    // ---------- Скачивание книги ----------
    private class IaFile(val name: String, val size: Long)

    private fun pickIa(files: List<IaFile>): IaFile? =
        files.firstOrNull { it.name.endsWith(".epub", true) }
            ?: files.firstOrNull { it.name.endsWith(".fb2", true) || it.name.endsWith(".fb2.zip", true) }
            ?: files.firstOrNull { it.name.endsWith("_djvu.txt", true) }
            ?: files.filter { it.name.endsWith(".pdf", true) }.minByOrNull { it.size }
            ?: files.firstOrNull { it.name.endsWith(".txt", true) }

    fun fetch(r: Remote, dir: File, onProgress: (Long, Long) -> Unit = { _, _ -> }): File {
        dir.mkdirs()
        var url = r.url
        var readMs = 60000
        if (url.startsWith("ia:")) {
            val id = url.drop(3)
            val fs = JSONObject(Http.getText("https://archive.org/metadata/$id")).optJSONArray("files") ?: JSONArray()
            val files = (0 until fs.length()).map { val o = fs.getJSONObject(it); IaFile(o.getString("name"), o.optString("size", "0").toLongOrNull() ?: 0L) }
            val n = pickIa(files)?.name ?: throw IOException("Файл недоступен для скачивания (возможно, только чтение онлайн)")
            url = "https://archive.org/download/$id/" + enc(n).replace("+", "%20")
        } else if (url.startsWith("ws:")) {
            url = "https://ws-export.wmcloud.org/?format=epub&lang=ru&page=" + enc(url.drop(3))
            readMs = 240000   // ws-export собирает EPUB на лету, это может занять до пары минут
        }
        val tmp = File(dir, "${r.id}.part")
        val c = Http.open(url, connectMs = 20000, readMs = readMs)
        val code = c.responseCode
        if (code !in 200..299) { c.disconnect(); throw IOException(if (code == 429) "Источник просит подождать (HTTP 429)" else "Источник ответил HTTP $code") }
        val total = c.contentLengthLong
        var done = 0L; var last = 0L
        c.inputStream.use { i ->
            tmp.outputStream().use { o ->
                val buf = ByteArray(128 * 1024)
                while (true) {
                    val n = i.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val now = SystemClock.elapsedRealtime()
                    if (now - last > 250) { last = now; onProgress(done, total) }
                }
            }
        }
        c.disconnect()
        val real = sniff(tmp)
        if (real == null) { tmp.delete(); throw IOException("Источник вернул не книгу (скорее всего, только чтение онлайн)") }
        val f = File(dir, "${r.id}.$real")
        f.delete()
        if (!tmp.renameTo(f)) { tmp.copyTo(f, overwrite = true); tmp.delete() }
        return f
    }

    /** Определяем настоящий формат по содержимому; HTML-заглушки (ошибки, «читать онлайн») отбрасываем. */
    fun sniff(f: File): String? {
        if (f.length() < 200) return null
        val head = ByteArray(4096)
        val n = f.inputStream().use { it.read(head) }
        if (n < 8) return null
        val s = String(head, 0, n, Charsets.ISO_8859_1)
        if (s.startsWith("%PDF")) return "pdf"
        if (s.startsWith("PK")) {
            return try {
                ZipFile(f).use { z ->
                    when {
                        z.getEntry("META-INF/container.xml") != null -> "epub"
                        z.getEntry("word/document.xml") != null -> "docx"
                        z.entries().asSequence().any { it.name.endsWith(".fb2", true) } -> "fb2zip"
                        else -> null
                    }
                }
            } catch (_: Exception) { null }
        }
        if (n >= 68 && s.substring(60, 68) == "BOOKMOBI") return "mobi"
        val low = s.lowercase()
        if (low.contains("<fictionbook")) return "fb2"
        if (low.startsWith("{\\rtf")) return "rtf"
        if (low.contains("<html") || low.contains("<!doctype html")) return null
        if (head.take(n).any { it.toInt() == 0 }) return null
        return "txt"
    }
}

/** Загрузки книг живут в AppScope: переключение вкладок их не прерывает. */
object BookDownloads {
    val progress = mutableStateMapOf<String, Float>()   // id -> 0..1, -1 = размер неизвестен

    fun start(ctx: Context, r: Remote) {
        if (progress.containsKey(r.id)) return
        val app = ctx.applicationContext
        progress[r.id] = -1f
        AppScope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    Net.fetch(r, File(app.filesDir, "books")) { d, t -> progress[r.id] = if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else -1f }
                }
                Store.add(Book(r.id, r.title, r.author, f.path, f.extension))
                Toast.makeText(app, "«${r.title.take(40)}» добавлена в библиотеку", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(app, "Не удалось скачать: ${Http.friendly(e)}", Toast.LENGTH_LONG).show()
            } finally {
                progress.remove(r.id)
            }
        }
    }
}
