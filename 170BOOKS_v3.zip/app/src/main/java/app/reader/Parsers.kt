package app.reader

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.zip.ZipFile

val SUPPORTED = setOf("epub", "fb2", "fb2zip", "mobi", "azw", "prc", "txt", "html", "htm", "xhtml", "rtf", "docx", "pdf")

fun extOf(name: String): String {
    val n = name.lowercase()
    return if (n.endsWith(".fb2.zip")) "fb2zip" else n.substringAfterLast('.', "")
}

data class Book(val id: String, val title: String, val author: String, val path: String, val ext: String, val pos: Int = 0, val status: String = "", val poff: Int = 0)
data class ReadingEvent(val time: Long, val pages: Int, val bookId: String)
data class Remote(val id: String, val title: String, val author: String, val url: String, val ext: String)

object Store {
    private lateinit var sp: SharedPreferences
    private lateinit var cacheRoot: File
    val books = mutableStateListOf<Book>()
    val completed = mutableStateListOf<String>()
    val events = mutableStateListOf<ReadingEvent>()
    private var sessionBook = ""
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val saver = Runnable { saveNow() }

    fun init(c: Context) {
        sp = c.getSharedPreferences("lib", 0)
        cacheRoot = File(c.cacheDir, "txt")
        val a = JSONArray(sp.getString("b", "[]"))
        val ca = JSONArray(sp.getString("completed", "[]"))
        for (i in 0 until ca.length()) completed.add(ca.getString(i))
        val ea = JSONArray(sp.getString("events", "[]"))
        for (i in 0 until ea.length()) {
            val o = ea.getJSONObject(i)
            events.add(ReadingEvent(o.getLong("time"), o.optInt("pages"), o.optString("bookId")))
        }
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val f = File(o.getString("path"))
            if (f.exists()) books.add(Book(o.getString("id"), o.getString("title"), o.getString("author"), o.getString("path"), o.getString("ext"),
                o.optInt("pos"), o.optString("status", ""), o.optInt("poff")))
        }
    }

    /** Запись откладывается: листание страниц не должно каждый раз сериализовать всю библиотеку. */
    private fun save() { handler.removeCallbacks(saver); handler.postDelayed(saver, 800) }
    fun flush() { handler.removeCallbacks(saver); saveNow() }

    private fun saveNow() {
        val bs = books.toList(); val cs = completed.toList(); val es = events.takeLast(5000)
        Thread {
            val a = JSONArray()
            bs.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("author", it.author).put("path", it.path).put("ext", it.ext).put("pos", it.pos).put("status", it.status).put("poff", it.poff)) }
            val ca = JSONArray(); cs.forEach { ca.put(it) }
            val ea = JSONArray(); es.forEach { ea.put(JSONObject().put("time", it.time).put("pages", it.pages).put("bookId", it.bookId)) }
            sp.edit().putString("b", a.toString()).putString("completed", ca.toString()).putString("events", ea.toString()).apply()
        }.start()
    }

    fun add(b: Book) { books.removeAll { it.id == b.id }; books.add(0, b); save() }
    fun startSession(id: String) {
        sessionBook = id
        events.add(ReadingEvent(System.currentTimeMillis(), 0, id)); save()
    }
    fun finishBook(id: String) {
        if (id in completed) return
        completed.add(id)
        val i = books.indexOfFirst { it.id == id }
        if (i >= 0) books[i] = books[i].copy(status = "DONE")
        save()
    }
    fun setStatus(id: String, status: String) {
        val i = books.indexOfFirst { it.id == id }
        if (i >= 0) {
            books[i] = books[i].copy(status = status)
            if (status == "DONE") { if (id !in completed) completed.add(id) } else completed.remove(id)
            save()
        }
    }
    fun dailyPages(): Int {
        val start = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        return events.filter { it.time >= start }.sumOf { it.pages }
    }
    fun averageSessionPages(): Int {
        val sessions = events.count { it.pages == 0 }
        val pages = events.sumOf { it.pages }
        return if (sessions == 0) 0 else pages / sessions
    }
    /** pos — номер абзаца, с которого начинается текущая страница; poff — смещение внутри абзаца. Для PDF pos — номер страницы. */
    fun setPos(id: String, pos: Int, poff: Int = 0) {
        val i = books.indexOfFirst { it.id == id }
        if (i >= 0 && (books[i].pos != pos || books[i].poff != poff)) {
            books[i] = books[i].copy(pos = pos, poff = poff); save()
        }
    }
    fun pageTurned(id: String, n: Int = 1) {
        if (sessionBook == id && n > 0) { events.add(ReadingEvent(System.currentTimeMillis(), n, id)); save() }
    }
    fun remove(b: Book) {
        File(b.path).delete(); File(cacheRoot, "${b.id}.v3").delete()
        books.remove(b); completed.remove(b.id); save()
    }
    fun cacheFile(id: String) = File(cacheRoot, "$id.v3")
}

// ---------- Парсеры ----------
fun ent(s: String) = Regex("&(#x?[0-9a-fA-F]+|[a-z]+);").replace(s) { m ->
    val v = m.groupValues[1]
    (when {
        v.startsWith("#x") -> v.drop(2).toIntOrNull(16)?.let { String(Character.toChars(it)) }
        v.startsWith("#") -> v.drop(1).toIntOrNull()?.let { String(Character.toChars(it)) }
        else -> mapOf("amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
            "mdash" to "—", "ndash" to "–", "laquo" to "«", "raquo" to "»", "hellip" to "…")[v]
    }) ?: m.value
}

private fun decode(b: ByteArray): String {
    val s = String(b, Charsets.UTF_8)
    return if ('\uFFFD' in s) String(b, charset("windows-1251")) else s
}

fun html2paras(h: String): List<String> {
    val t = h.replace(Regex("(?is)<(script|style|head)\\b.*?</\\1>"), "")
        .replace(Regex("(?i)</(p|div|h[1-6]|li|tr)>|<br\\s*/?>"), "\n")
        .replace(Regex("<[^>]+>"), "")
    return ent(t).lines().map { it.replace(Regex("\\s+"), " ").trim() }.filter { it.isNotEmpty() }
}

private fun attr(t: String, n: String) = Regex("\\b$n=[\"']([^\"']*)[\"']").find(t)?.groupValues?.get(1)

private fun fb2(ins: InputStream): List<String> {
    val p = XmlPullParserFactory.newInstance().newPullParser(); p.setInput(ins, null)
    val out = ArrayList<String>(); val sb = StringBuilder(); var skip = 0
    fun flush() { val t = sb.toString().replace(Regex("\\s+"), " ").trim(); if (t.isNotEmpty()) out.add(t); sb.clear() }
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        when (ev) {
            XmlPullParser.START_TAG -> if (p.name == "binary" || p.name == "description") skip++
            XmlPullParser.TEXT -> if (skip == 0) sb.append(p.text)
            XmlPullParser.END_TAG -> when (p.name) {
                "binary", "description" -> skip--
                "p", "v", "subtitle", "title", "text-author", "section", "empty-line" -> if (skip == 0) flush()
            }
        }
        ev = p.next()
    }
    flush(); return out
}

private fun epub(f: File): List<String> = ZipFile(f).use { z ->
    fun rd(n: String) = z.getEntry(n)?.let { String(z.getInputStream(it).readBytes(), Charsets.UTF_8) }
    val out = ArrayList<String>()
    try {
        val opf = Regex("full-path=\"([^\"]+)\"").find(rd("META-INF/container.xml") ?: "")?.groupValues?.get(1)
        val x = opf?.let { rd(it) }
        if (opf != null && x != null) {
            val dir = opf.substringBeforeLast('/', "")
            val man = HashMap<String, String>()
            Regex("<item\\b[^>]*>").findAll(x).forEach { m ->
                val id = attr(m.value, "id"); val h = attr(m.value, "href"); if (id != null && h != null) man[id] = h
            }
            Regex("<itemref\\b[^>]*>").findAll(x).forEach { m ->
                val h = attr(m.value, "idref")?.let { man[it] } ?: return@forEach
                val parts = ArrayList<String>()
                URLDecoder.decode(if (dir.isEmpty()) h else "$dir/$h", "UTF-8").substringBefore('#').split('/').forEach {
                    if (it == "..") parts.removeLastOrNull() else if (it != "." && it.isNotEmpty()) parts.add(it)
                }
                rd(parts.joinToString("/"))?.let { out += html2paras(it) }
            }
        }
    } catch (_: Exception) { }
    if (out.isEmpty()) {
        // Битый OPF: читаем все html/xhtml в порядке имён файлов.
        z.entries().asSequence().filter { val n = it.name.lowercase(); n.endsWith(".xhtml") || n.endsWith(".html") || n.endsWith(".htm") }
            .sortedBy { it.name }.forEach { e -> out += html2paras(String(z.getInputStream(e).readBytes(), Charsets.UTF_8)) }
    }
    out
}

private fun docx(f: File): List<String> = ZipFile(f).use { z ->
    val p = XmlPullParserFactory.newInstance().newPullParser()
    p.setInput(z.getInputStream(z.getEntry("word/document.xml")), null)
    val out = ArrayList<String>(); val sb = StringBuilder(); var inT = false
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        when (ev) {
            XmlPullParser.START_TAG -> if (p.name == "w:t") inT = true
            XmlPullParser.TEXT -> if (inT) sb.append(p.text)
            XmlPullParser.END_TAG -> if (p.name == "w:t") inT = false else if (p.name == "w:p") {
                val t = sb.toString().trim(); if (t.isNotEmpty()) out.add(t); sb.clear()
            }
        }
        ev = p.next()
    }
    out
}

private fun rtf(s: String): List<String> {
    val t = s.replace(Regex("\\\\'([0-9a-fA-F]{2})")) { String(byteArrayOf(it.groupValues[1].toInt(16).toByte()), charset("windows-1251")) }
        .replace(Regex("\\\\u(-?\\d+)\\??")) { String(Character.toChars(it.groupValues[1].toInt().let { n -> if (n < 0) n + 65536 else n })) }
        .replace(Regex("\\\\pard?\\b ?"), "\n")
        .replace(Regex("\\\\[a-zA-Z]+-?\\d* ?"), "").replace(Regex("[{}]"), "")
    return t.lines().map { it.trim() }.filter { it.isNotEmpty() }
}

private fun mobi(f: File): List<String> {
    val b = f.readBytes()
    fun u16(o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    fun u32(o: Int) = (u16(o) shl 16) or u16(o + 2)
    val n = u16(76)
    fun off(i: Int) = u32(78 + i * 8)
    val r0 = off(0)
    val comp = u16(r0)
    val count = u16(r0 + 8)
    if (comp == 17480) error("MOBI/KF8 со сжатием Huffman не поддерживается. Сконвертируйте в EPUB.")
    val utf = u32(r0 + 28) == 65001
    val flags = if (u32(r0 + 20) >= 228) u16(r0 + 242) else 0
    val out = java.io.ByteArrayOutputStream()
    for (i in 1..minOf(count, n - 1)) {
        val end = if (i + 1 < n) off(i + 1) else b.size
        val start = off(i)
        var size = end - start
        var fl = flags shr 1
        while (fl != 0) {
            if (fl and 1 == 1) {
                var v = 0; var sh = 0; var p = start + size - 1
                while (true) { val x = b[p].toInt() and 255; v = v or ((x and 127) shl sh); sh += 7; p--; if (x and 128 != 0) break }
                size -= v
            }
            fl = fl shr 1
        }
        if (flags and 1 == 1) size -= (b[start + size - 1].toInt() and 3) + 1
        if (comp == 1) { out.write(b, start, size); continue }
        var p = start; val lim = start + size
        var buf = ByteArray(size * 6 + 16); var bl = 0
        fun put(x: Int) { if (bl == buf.size) buf = buf.copyOf(bl * 2); buf[bl++] = x.toByte() }
        while (p < lim) {
            val c = b[p++].toInt() and 255
            when {
                c in 1..8 -> { for (k in 0 until c) put(b[p + k].toInt()); p += c }
                c < 128 -> put(c)
                c >= 192 -> { put(32); put(c xor 128) }
                else -> {
                    val c2 = (c shl 8) or (b[p++].toInt() and 255)
                    val d = (c2 shr 3) and 0x7FF; val l = (c2 and 7) + 3
                    for (k in 0 until l) put(buf[bl - d].toInt())
                }
            }
        }
        out.write(buf, 0, bl)
    }
    val bytes = out.toByteArray()
    return html2paras(if (utf) String(bytes, Charsets.UTF_8) else String(bytes, charset("windows-1252")))
}

/** TXT: склеиваем жёстко перенесённые строки в абзацы (Gutenberg, OCR из Archive). */
private fun txt2paras(raw: String): List<String> {
    val lines = raw.replace("\r\n", "\n").replace('\r', '\n').lines()
    val nonBlank = lines.count { it.isNotBlank() }
    val blocks = raw.replace("\r\n", "\n").split(Regex("\n[ \t]*\n+")).filter { it.isNotBlank() }
    return if (blocks.size >= maxOf(3, nonBlank / 12))
        blocks.map { it.replace(Regex("\\s+"), " ").trim() }.filter { it.isNotEmpty() }
    else lines.map { it.trim() }.filter { it.isNotEmpty() }
}

/** Слишком длинные «абзацы» режем по предложениям — иначе вёрстка одного куска на мегабайт текста тормозит. */
private fun splitLong(paras: List<String>, max: Int = 4500): List<String> {
    val out = ArrayList<String>(paras.size + 16)
    for (p in paras) {
        if (p.length <= max) { out.add(p); continue }
        var i = 0
        while (i < p.length) {
            if (p.length - i <= max) { out.add(p.substring(i).trim()); break }
            val lo = i + max / 2; val hi = i + max
            var cut = -1
            for (k in hi downTo lo) { val ch = p[k]; if ((ch == ' ' && k > 0 && p[k - 1] in ".!?…»\"") ) { cut = k; break } }
            if (cut < 0) cut = p.lastIndexOf(' ', hi).takeIf { it > lo } ?: hi
            out.add(p.substring(i, cut).trim())
            i = cut + 1
        }
    }
    return out.filter { it.isNotEmpty() }
}

object Parsers {
    fun load(f: File, ext: String): List<String> = when (ext) {
        "epub" -> epub(f)
        "fb2" -> f.inputStream().use { fb2(it) }
        "fb2zip" -> ZipFile(f).use { z -> fb2(z.getInputStream(z.entries().asSequence().first { it.name.endsWith(".fb2", true) })) }
        "docx" -> docx(f)
        "mobi", "azw", "prc" -> mobi(f)
        "html", "htm", "xhtml" -> html2paras(decode(f.readBytes()))
        "rtf" -> rtf(decode(f.readBytes()))
        else -> txt2paras(decode(f.readBytes()))
    }

    /** Разобранный текст кэшируется: повторное открытие книги не парсит файл заново. Результат одинаков при каждом вызове. */
    fun loadCached(b: Book): List<String> {
        val src = File(b.path)
        val cf = Store.cacheFile(b.id)
        val cached = runCatching { if (cf.isFile && cf.lastModified() >= src.lastModified()) cf.readLines().filter { it.isNotEmpty() } else null }.getOrNull()
        if (!cached.isNullOrEmpty()) return cached
        val paras = splitLong(load(src, b.ext).map { it.replace('\n', ' ').trim() }.filter { it.isNotEmpty() })
        if (paras.isNotEmpty()) runCatching { cf.parentFile?.mkdirs(); cf.writeText(paras.joinToString("\n")) }
        return paras
    }
}
