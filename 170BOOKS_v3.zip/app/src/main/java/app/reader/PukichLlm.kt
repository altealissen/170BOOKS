package app.reader

import android.content.Context
import java.io.File

/** Локальная Qwen2.5 (GGUF) через llama.cpp JNI. Генерация потоковая: текст приходит по мере готовности. */
object PukichLlm {
    @Volatile var cancelled = false
    @Volatile private var loadedPath: String? = null
    private val lock = Any()
    private var libOk: Boolean? = null

    private external fun nativeLoad(path: String, nThreads: Int, nCtx: Int): Boolean
    private external fun nativeBegin(prompt: ByteArray): Int
    private external fun nativeNext(): ByteArray?
    private external fun nativeFinish()
    private external fun nativeClose()

    private fun lib(): Boolean {
        if (libOk == null) libOk = runCatching { System.loadLibrary("pukich_llama") }.isSuccess
        return libOk == true
    }

    private fun prefs(c: Context) = c.getSharedPreferences("pukich", 0)
    fun selectedId(c: Context): String = prefs(c).getString("model", "q05") ?: "q05"
    fun select(c: Context, id: String) { prefs(c).edit().putString("model", id).apply() }

    fun installed(c: Context, spec: ModelSpec): Boolean = File(c.filesDir, spec.file).let { it.isFile && it.length() > 50_000_000L }
    fun anyInstalled(c: Context) = Models.all.any { installed(c, it) }

    /** Модель, которую реально используем: выбранная, если установлена, иначе любая установленная. */
    fun activeSpec(c: Context): ModelSpec? =
        Models.byId(selectedId(c))?.takeIf { installed(c, it) } ?: Models.all.firstOrNull { installed(c, it) }

    private fun ensureLoaded(c: Context, spec: ModelSpec) {
        check(lib()) { "Не загрузилась нативная библиотека llama.cpp (нужен arm64-устройство)." }
        val path = File(c.filesDir, spec.file).absolutePath
        if (loadedPath == path) return
        val cores = Runtime.getRuntime().availableProcessors()
        val threads = (cores / 2).coerceIn(2, 6)
        check(nativeLoad(path, threads, 4096)) { "Не хватило памяти, чтобы запустить модель. Закрой другие приложения или выбери модель поменьше." }
        loadedPath = path
    }

    /** Заранее загрузить модель в память, чтобы первый ответ не ждал. */
    fun preload(c: Context) {
        val spec = activeSpec(c) ?: return
        synchronized(lock) { runCatching { ensureLoaded(c, spec) } }
    }

    fun cancel() { cancelled = true }

    /** Блокирующий вызов — запускать на IO. onText получает накопленный ответ целиком. */
    fun generate(c: Context, prompt: String, maxTokens: Int, onText: (String) -> Unit): String {
        val spec = checkNotNull(activeSpec(c)) { "Сначала скачай модель в настройках." }
        synchronized(lock) {
            ensureLoaded(c, spec)
            cancelled = false
            val rc = nativeBegin(prompt.toByteArray(Charsets.UTF_8))
            check(rc == 0) {
                when (rc) {
                    2 -> "Диалог слишком длинный для модели — начни новый."
                    1 -> "Модель не загружена."
                    else -> "Модель не смогла обработать запрос."
                }
            }
            val sb = StringBuilder()
            try {
                var n = 0
                while (n < maxTokens && !cancelled) {
                    val bytes = nativeNext() ?: break
                    if (bytes.isNotEmpty()) { sb.append(String(bytes, Charsets.UTF_8)); onText(sb.toString()) }
                    n++
                }
            } finally {
                nativeFinish()
            }
            return sb.toString().trim()
        }
    }

    fun close() {
        synchronized(lock) {
            if (loadedPath != null && lib()) nativeClose()
            loadedPath = null
        }
    }

    fun remove(c: Context, spec: ModelSpec) {
        close()
        File(c.filesDir, spec.file).delete()
        File(c.filesDir, spec.file + ".part").delete()
        ModelDownloader.markChanged()
    }
}
