package app.reader

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/** Шрифт книги (Newspaper из assets/fonts, если положен; иначе системный serif). Ставится в MainActivity. */
var BookTypeface: Typeface = Typeface.SERIF

private const val LINE_MULT = 1.38f
private const val INDENT = "\u2003\u2002"

class ReaderColors(val bg: Color, val card: Color, val ink: Color)

@Composable
fun readerColors(): ReaderColors =
    if (ReaderSettings.eyeProtection) ReaderColors(Color(0xFFE6DBC0), Color(0xFFF3EAD2), Color(0xFF3F3629))
    else ReaderColors(BG, PANEL, FG)

/** Связка между верхней панелью (стрелки) и экраном страниц. */
class ReaderNav {
    var index by mutableIntStateOf(0)
    var count by mutableIntStateOf(0)
    var pageText: String = ""
    var turn: (Int) -> Unit = {}
    val canPrev get() = index > 0
    val canNext get() = index < count - 1
}

@Composable
private fun BarBtn(text: String, enabled: Boolean, color: Color, onClick: () -> Unit) {
    Box(Modifier.size(38.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick), Alignment.Center) {
        Text(text, color = if (enabled) color else color.copy(alpha = 0.25f), style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun MiniSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f).padding(end = 10.dp), style = mono(10))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun Reader(b: Book, onBack: () -> Unit) {
    LaunchedEffect(b.id) { Store.startSession(b.id) }
    DisposableEffect(b.id) { onDispose { Store.flush() } }
    val nav = remember(b.id) { ReaderNav() }
    val col = readerColors()
    var showNote by remember { mutableStateOf(false) }
    var showQuote by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    // Иконки статус-бара должны читаться и на светлой «бумаге», и на тёмном фоне
    val view = LocalView.current
    val lightBars = ReaderSettings.eyeProtection || ReaderSettings.themeId >= 3
    SideEffect {
        (view.context as? android.app.Activity)?.window?.let {
            val c = androidx.core.view.WindowCompat.getInsetsController(it, view)
            c.isAppearanceLightStatusBars = lightBars; c.isAppearanceLightNavigationBars = lightBars
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            (view.context as? android.app.Activity)?.window?.let {
                val c = androidx.core.view.WindowCompat.getInsetsController(it, view)
                val light = ReaderSettings.themeId >= 3
                c.isAppearanceLightStatusBars = light; c.isAppearanceLightNavigationBars = light
            }
        }
    }

    fun where(): String =
        if (nav.count > 0) "Стр. ${nav.index + 1}" else "Фрагмент ${(Store.books.firstOrNull { it.id == b.id }?.pos ?: 0) + 1}"

    Column(Modifier.fillMaxSize().background(col.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            BarBtn("←", true, col.ink, onBack)
            Text(b.title.uppercase(), Modifier.weight(1f).padding(horizontal = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, style = mono(11).copy(color = col.ink.copy(alpha = 0.8f)))
            if (nav.count > 0) {
                BarBtn("‹", nav.canPrev, col.ink) { nav.turn(-1) }
                BarBtn("›", nav.canNext, col.ink) { nav.turn(1) }
            }
            BarBtn("❝", true, ACCENT) { showQuote = true }
            BarBtn("✎", true, col.ink) { showNote = true }
            Box {
                BarBtn("Аа", true, col.ink) { showSettings = true }
                DropdownMenu(expanded = showSettings, onDismissRequest = { showSettings = false }, modifier = Modifier.background(PANEL)) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).widthIn(min = 270.dp, max = 330.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("РАЗМЕР ШРИФТА", Modifier.weight(1f), style = mono(10))
                            Text("A−", Modifier.clip(CircleShape).clickable { ReaderSettings.setFontSize(ReaderSettings.fontSize - 1) }.padding(horizontal = 14.dp, vertical = 8.dp), style = mono(14))
                            Text("${ReaderSettings.fontSize}", style = mono(12, 0.7f))
                            Text("A+", Modifier.clip(CircleShape).clickable { ReaderSettings.setFontSize(ReaderSettings.fontSize + 1) }.padding(horizontal = 14.dp, vertical = 8.dp), style = mono(14))
                        }
                        MiniSwitch("Режим страниц (иначе — прокрутка)", ReaderSettings.pageMode) { ReaderSettings.updatePageMode(it) }
                        MiniSwitch("Свайп вправо — вперёд", ReaderSettings.swipeNextRight) { ReaderSettings.updateSwipeNextRight(it) }
                        MiniSwitch("Разворот на большом экране", ReaderSettings.spread) { ReaderSettings.updateSpread(it) }
                        MiniSwitch("Защита глаз", ReaderSettings.eyeProtection) { ReaderSettings.updateEyeProtection(it) }
                    }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (b.ext == "pdf") PdfReader(b, nav, col) else TextReader(b, nav, col)
        }
    }
    if (showNote) EntryDialog("Новая заметка", "Запиши мысль, настроение или идею…", onDismiss = { showNote = false }) { body ->
        NotesStore.add(ReaderEntry(b.title, body, "Заметка", System.currentTimeMillis(), where())); showNote = false
    }
    if (showQuote) EntryDialog("Сохранить цитату", "Оставь в поле только нужный фрагмент…", initial = nav.pageText, onDismiss = { showQuote = false }) { body ->
        NotesStore.add(ReaderEntry(b.title, body, "Цитата", System.currentTimeMillis(), where())); showQuote = false
    }
}

// ===================== ТЕКСТОВЫЕ ФОРМАТЫ =====================

class PageSlice(val text: String, val para: Int, val off: Int)
class Paged(val pages: List<PageSlice>)

private fun makePaint(tf: Typeface, sizePx: Float, color: Int) =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = tf; textSize = sizePx; this.color = color }

private fun buildLayout(text: CharSequence, paint: TextPaint, wPx: Int): StaticLayout =
    StaticLayout.Builder.obtain(text, 0, text.length, paint, wPx)
        .setLineSpacing(0f, LINE_MULT)
        .setIncludePad(false)
        .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
        .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
        .build()

/**
 * Настоящая вёрстка: каждый абзац раскладывается StaticLayout-ом при реальной ширине и шрифте,
 * страница заполняется целыми строками до высоты области текста. Ничего не обрезается и не «уезжает».
 */
private fun paginate(paras: List<String>, wPx: Int, hPx: Int, sizePx: Float, tf: Typeface, check: () -> Unit): List<PageSlice> {
    val paint = makePaint(tf, sizePx, 0)
    val out = ArrayList<PageSlice>()
    val page = StringBuilder()
    var used = 0
    var pPara = 0; var pOff = 0; var started = false
    var fragPara = -1; var fragStart = 0; var fragEnd = 0; var fragText = ""

    fun closeFrag() {
        if (fragPara >= 0) {
            if (page.isNotEmpty()) page.append('\n')
            page.append(fragText, fragStart, fragEnd)
            fragPara = -1
        }
    }
    fun flush() {
        closeFrag()
        if (started) out.add(PageSlice(page.toString(), pPara, pOff))
        page.setLength(0); used = 0; started = false
    }

    for (pi in paras.indices) {
        if (pi % 48 == 0) check()
        val text = INDENT + paras[pi]
        val layout = buildLayout(text, paint, wPx)
        for (l in 0 until layout.lineCount) {
            val h = layout.getLineBottom(l) - layout.getLineTop(l)
            if (started && used + h > hPx) flush()
            if (!started) { started = true; pPara = pi; pOff = (layout.getLineStart(l) - INDENT.length).coerceAtLeast(0) }
            if (fragPara != pi) { closeFrag(); fragPara = pi; fragText = text; fragStart = layout.getLineStart(l) }
            fragEnd = layout.getLineEnd(l)
            used += h
        }
    }
    flush()
    return out
}

private fun pageIndexFor(pages: List<PageSlice>, a: Pair<Int, Int>): Int {
    var lo = 0; var hi = pages.size - 1; var ans = 0
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        val p = pages[mid]
        if (p.para < a.first || (p.para == a.first && p.off <= a.second)) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

@Composable
fun TextReader(b: Book, nav: ReaderNav, col: ReaderColors) {
    val st = produceState<Result<List<String>>?>(null, b.id) {
        value = withContext(Dispatchers.IO) { runCatching { Parsers.loadCached(b) } }
    }
    val start = remember(b.id) { Store.books.firstOrNull { it.id == b.id }?.let { it.pos to it.poff } ?: (0 to 0) }
    val r = st.value
    if (r == null) {
        SideEffect { nav.count = 0 }
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = ACCENT, strokeWidth = 2.dp)
                Text("Открываю книгу…", Modifier.padding(top = 12.dp), style = mono(10).copy(color = col.ink.copy(alpha = 0.6f)))
            }
        }
        return
    }
    val paras = r.getOrNull()
    if (paras.isNullOrEmpty()) {
        SideEffect { nav.count = 0 }
        Text("Не удалось открыть книгу: ${r.exceptionOrNull()?.message ?: "в файле нет текста"}", Modifier.padding(24.dp),
            style = mono(12).copy(color = col.ink.copy(alpha = 0.8f)))
        return
    }
    if (ReaderSettings.pageMode) PagedText(b, paras, nav, col, start) else ScrollText(b, paras, nav, col, start)
}

@Composable
private fun PageCard(slice: PageSlice?, number: Int, cardW: Dp, cardH: Dp, padH: Dp, padV: Dp, wPx: Int, sizePx: Float, col: ReaderColors) {
    val tf = BookTypeface
    val ink = col.ink.toArgb()
    val layout = remember(slice, wPx, sizePx, ink, tf) { slice?.let { buildLayout(it.text, makePaint(tf, sizePx, ink), wPx) } }
    val shape = RoundedCornerShape(10.dp)
    Box(Modifier.width(cardW).height(cardH).clip(shape).background(col.card).border(1.dp, col.ink.copy(alpha = 0.08f), shape)) {
        if (layout != null) Canvas(Modifier.fillMaxSize().padding(horizontal = padH, vertical = padV)) {
            drawIntoCanvas { c -> layout.draw(c.nativeCanvas) }
        }
        if (slice != null) Text("$number", Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp), style = mono(9).copy(color = col.ink.copy(alpha = 0.35f)))
    }
}

@Composable
private fun PagedText(b: Book, paras: List<String>, nav: ReaderNav, col: ReaderColors, start: Pair<Int, Int>) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val d = LocalDensity.current
        // Большой экран в альбомной ориентации — разворот из двух страниц; телефон — одна страница.
        val spread = ReaderSettings.spread && maxWidth >= 720.dp && maxWidth > maxHeight && maxHeight >= 420.dp
        val per = if (spread) 2 else 1
        val footer = 28.dp
        val gutter = 14.dp
        val outer = if (maxWidth >= 600.dp) 20.dp else 8.dp
        val cardH = maxHeight - footer - 6.dp
        val cardW = if (spread) (maxWidth - outer * 2 - gutter) / 2 else minOf(maxWidth - outer * 2, 700.dp)
        val padH = if (cardW >= 480.dp) 34.dp else 18.dp
        val padV = if (cardH >= 480.dp) 22.dp else 10.dp
        val wPx = with(d) { (cardW - padH * 2).roundToPx() }
        val hPx = with(d) { (cardH - padV * 2).roundToPx() } - 3
        val sizePx = with(d) { ReaderSettings.fontSize.sp.toPx() }
        val tf = BookTypeface

        // Якорь = (абзац, смещение). Он переживает смену шрифта/поворот экрана: страницы пересчитываются, место чтения — то же.
        var anchor by remember(b.id) { mutableStateOf(start) }

        val paged by produceState<Paged?>(null, paras, wPx, hPx, sizePx, tf) {
            value = null
            value = withContext(Dispatchers.Default) { Paged(paginate(paras, wPx, hPx, sizePx, tf) { ensureActive() }) }
        }
        val p = paged
        if (p == null || p.pages.isEmpty()) {
            SideEffect { nav.count = 0 }
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = ACCENT, strokeWidth = 2.dp)
                    Text("Верстаю страницы…", Modifier.padding(top = 12.dp), style = mono(10).copy(color = col.ink.copy(alpha = 0.6f)))
                }
            }
            return@BoxWithConstraints
        }

        key(p, per) {
            val total = p.pages.size
            val spreads = (total + per - 1) / per
            val initial = (pageIndexFor(p.pages, anchor) / per).coerceIn(0, (spreads - 1).coerceAtLeast(0))
            val pager = rememberPagerState(initialPage = initial, pageCount = { spreads })
            val scope = rememberCoroutineScope()

            SideEffect {
                nav.count = spreads
                nav.turn = { dlt -> scope.launch { pager.animateScrollToPage((pager.currentPage + dlt).coerceIn(0, spreads - 1)) } }
            }
            LaunchedEffect(pager, p) {
                var prev = initial
                snapshotFlow { pager.currentPage }.collect { sp ->
                    nav.index = sp
                    val pg = p.pages.getOrNull(sp * per)
                    if (pg != null) {
                        anchor = pg.para to pg.off
                        nav.pageText = if (per == 2) pg.text + (p.pages.getOrNull(sp * per + 1)?.let { "\n" + it.text } ?: "") else pg.text
                        Store.setPos(b.id, pg.para, pg.off)
                    }
                    if (sp > prev) Store.pageTurned(b.id, (sp - prev) * per)
                    prev = sp
                    if (spreads > 1 && sp >= spreads - 1) Store.finishBook(b.id)
                }
            }

            Column(Modifier.fillMaxSize()) {
                // Одна страница; листание — только свайпом (или стрелками сверху). Тапы по тексту ничего не листают.
                HorizontalPager(
                    state = pager,
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    reverseLayout = ReaderSettings.swipeNextRight,   // true: свайп вправо — вперёд, влево — назад
                    key = { it },
                    beyondBoundsPageCount = 1
                ) { sp ->
                    Box(Modifier.fillMaxSize().padding(top = 6.dp), Alignment.TopCenter) {
                        Row(horizontalArrangement = Arrangement.Center) {
                            val i0 = sp * per
                            PageCard(p.pages.getOrNull(i0), i0 + 1, cardW, cardH, padH, padV, wPx, sizePx, col)
                            if (spread) {
                                Spacer(Modifier.width(gutter))
                                PageCard(p.pages.getOrNull(i0 + 1), i0 + 2, cardW, cardH, padH, padV, wPx, sizePx, col)
                            }
                        }
                    }
                }
                val cur = pager.currentPage
                val first = cur * per + 1
                val last = minOf(total, cur * per + per)
                Box(Modifier.fillMaxWidth().height(footer), Alignment.Center) {
                    Text(
                        (if (per == 2 && last > first) "$first–$last" else "$first") + " / $total  ·  ${(last * 100 / total).coerceIn(1, 100)}%",
                        style = mono(10).copy(color = col.ink.copy(alpha = 0.5f))
                    )
                }
            }
        }
    }
}

@Composable
private fun ScrollText(b: Book, paras: List<String>, nav: ReaderNav, col: ReaderColors, start: Pair<Int, Int>) {
    SideEffect { nav.count = 0; nav.pageText = "" }
    val ls = rememberLazyListState(start.first.coerceIn(0, paras.lastIndex))
    LaunchedEffect(ls) {
        var prev = ls.firstVisibleItemIndex
        var acc = 0
        snapshotFlow { ls.firstVisibleItemIndex }.collect { i ->
            Store.setPos(b.id, i, 0)
            if (i > prev) { acc += i - prev; if (acc >= 8) { Store.pageTurned(b.id, acc / 8); acc %= 8 } }
            prev = i
            if (paras.size > 3 && i >= paras.lastIndex - 1) Store.finishBook(b.id)
        }
    }
    val fs = ReaderSettings.fontSize
    Box(Modifier.fillMaxSize(), Alignment.TopCenter) {
        LazyColumn(state = ls, modifier = Modifier.widthIn(max = 720.dp).fillMaxHeight(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(paras) { t ->
                Text(t, color = col.ink, style = TextStyle(fontFamily = LocalBookFont.current, fontSize = fs.sp, lineHeight = (fs * 1.45f).sp, textAlign = TextAlign.Justify))
            }
        }
    }
}

// ===================== PDF =====================

@Composable
private fun PdfPage(r: PdfRenderer, mu: Mutex, index: Int, wPx: Int, hPx: Int, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, index, wPx, hPx) {
        value = withContext(Dispatchers.IO) {
            mu.withLock {
                runCatching {
                    r.openPage(index).use { pg ->
                        val scale = minOf(wPx.toFloat() / pg.width, hPx.toFloat() / pg.height).coerceAtMost(3f)
                        val w = (pg.width * scale).toInt().coerceAtLeast(1)
                        val h = (pg.height * scale).toInt().coerceAtLeast(1)
                        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bm.eraseColor(android.graphics.Color.WHITE)
                        pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bm
                    }
                }.getOrNull()
            }
        }
    }
    val m = bmp
    if (m != null) Image(m.asImageBitmap(), null, modifier, contentScale = ContentScale.Fit)
    else Box(modifier.aspectRatio(0.7f))
}

@Composable
private fun PdfReader(b: Book, nav: ReaderNav, col: ReaderColors) {
    val start = remember(b.id) { Store.books.firstOrNull { it.id == b.id }?.pos ?: 0 }
    val pfd = remember(b.id) { runCatching { ParcelFileDescriptor.open(File(b.path), ParcelFileDescriptor.MODE_READ_ONLY) }.getOrNull() }
    val r = remember(b.id) { pfd?.let { runCatching { PdfRenderer(it) }.getOrNull() } }
    val mu = remember(b.id) { Mutex() }
    DisposableEffect(b.id) { onDispose { runCatching { r?.close() }; runCatching { pfd?.close() } } }
    if (r == null || r.pageCount == 0) {
        SideEffect { nav.count = 0 }
        Text("Не удалось открыть PDF (возможно, он защищён паролем).", Modifier.padding(24.dp), style = mono(12).copy(color = col.ink))
        return
    }
    val count = r.pageCount
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val d = LocalDensity.current
        val spread = ReaderSettings.spread && maxWidth >= 720.dp && maxWidth > maxHeight && maxHeight >= 420.dp
        val per = if (spread) 2 else 1
        if (ReaderSettings.pageMode) {
            val spreads = (count + per - 1) / per
            val wPx = with(d) { (maxWidth / per).roundToPx() }
            val hPx = with(d) { maxHeight.roundToPx() }
            key(per) {
                val pager = rememberPagerState(initialPage = (start / per).coerceIn(0, spreads - 1), pageCount = { spreads })
                val scope = rememberCoroutineScope()
                SideEffect {
                    nav.count = spreads; nav.pageText = ""
                    nav.turn = { dlt -> scope.launch { pager.animateScrollToPage((pager.currentPage + dlt).coerceIn(0, spreads - 1)) } }
                }
                LaunchedEffect(pager) {
                    var prev = pager.currentPage
                    snapshotFlow { pager.currentPage }.collect { sp ->
                        nav.index = sp
                        Store.setPos(b.id, sp * per, 0)
                        if (sp > prev) Store.pageTurned(b.id, (sp - prev) * per)
                        prev = sp
                        if (spreads > 1 && sp >= spreads - 1) Store.finishBook(b.id)
                    }
                }
                HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), reverseLayout = ReaderSettings.swipeNextRight,
                    key = { it }, beyondBoundsPageCount = 1) { sp ->
                    Row(Modifier.fillMaxSize().padding(6.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        PdfPage(r, mu, sp * per, wPx, hPx, Modifier.weight(1f).fillMaxHeight())
                        if (spread && sp * per + 1 < count) PdfPage(r, mu, sp * per + 1, wPx, hPx, Modifier.weight(1f).fillMaxHeight())
                    }
                }
            }
        } else {
            SideEffect { nav.count = 0; nav.pageText = "" }
            val ls = rememberLazyListState(start.coerceIn(0, count - 1))
            LaunchedEffect(ls) {
                snapshotFlow { ls.firstVisibleItemIndex }.collect {
                    Store.setPos(b.id, it, 0)
                    if (it >= count - 1) Store.finishBook(b.id)
                }
            }
            val wPx = with(d) { minOf(maxWidth, 900.dp).roundToPx() }
            Box(Modifier.fillMaxSize(), Alignment.TopCenter) {
                LazyColumn(state = ls, modifier = Modifier.widthIn(max = 900.dp).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(8.dp)) {
                    items(count) { i -> PdfPage(r, mu, i, wPx, 6000, Modifier.fillMaxWidth()) }
                }
            }
        }
    }
}
